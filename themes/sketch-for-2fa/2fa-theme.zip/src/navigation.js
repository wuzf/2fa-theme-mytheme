/** Exact SDK action IDs covered by their existing aggregate host flows. */
export const aggregateActions = {
  tools: [
    "tool:qr-decode",
    "tool:qr-generate",
    "tool:base32",
    "tool:timestamp",
    "tool:key-check",
    "tool:key-generate",
  ],
  "settings:sync": [
    "sync-provider:webdav",
    "sync-provider:s3",
    "sync-provider:onedrive",
    "sync-provider:gdrive",
  ],
};
/** Each group's entries in menu order. "*" marks where an action the theme
    does not know yet goes, so a new host action is never lost. Scanning opens
    the data group, About follows the theme settings and signing out closes
    the menu. Generating a code from a key is a tool, not an app entry. */
export const groupOrder = {
  data: ["scan-import", "account-add", "import", "export", "backup", "*"],
  tools: ["tools", ...aggregateActions.tools, "*", "quick-otp"],
  settings: [
    "settings:security",
    "settings:sync",
    ...aggregateActions["settings:sync"],
    "settings:preferences",
    "settings:custom-code",
    "*",
    "appearance",
    "settings:about",
  ],
  app: ["extension", "pwa-install", "*", "login", "logout"],
};
// An unknown action joins the group its family belongs to, else the app group.
function groupOf(actionId) {
  for (const [group, ids] of Object.entries(groupOrder))
    if (ids.includes(actionId)) return group;
  if (/^(settings|sync-provider):/.test(actionId)) return "settings";
  if (actionId.startsWith("tool:")) return "tools";
  return "app";
}
function rank(group, actionId) {
  const ids = groupOrder[group];
  const index = ids.indexOf(actionId);
  return index < 0 ? ids.indexOf("*") : index;
}
export function managementGroups(descriptors, snapshot = {}) {
  const statusActions = new Set([
    "hidden-accounts",
    "offline-queue",
    "offline-queue-status-retry",
    // Safe mode is offered by the host's error bar, not the menu.
    "recovery",
  ]);
  const allowed = descriptors.filter((item) => {
    if (
      item.requires &&
      !(Array.isArray(item.requires) && item.requires.length === 0)
    )
      return false;
    if (statusActions.has(item.actionId)) return false;
    if (item.actionId === "login")
      return snapshot.session?.state === "logged-out";
    if (item.actionId === "logout")
      return ["authenticated", "unconfirmed"].includes(snapshot.session?.state);
    if (item.actionId === "pwa-install")
      return snapshot.host?.installAvailable === true && item.enabled;
    return true;
  });
  const covered = new Set(
    Object.entries(aggregateActions).flatMap(([id, children]) =>
      allowed.some((item) => item.actionId === id && item.enabled)
        ? children
        : [],
    ),
  );
  const groups = { data: [], tools: [], settings: [], app: [] };
  for (const item of allowed) {
    if (covered.has(item.actionId)) continue;
    groups[groupOf(item.actionId)].push(item);
  }
  for (const [group, items] of Object.entries(groups))
    items.sort((a, b) => rank(group, a.actionId) - rank(group, b.actionId));
  return groups;
}
