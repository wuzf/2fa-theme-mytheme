/** Keep official dialogs and public pages in the same Y2K Window palette. */
export function hostAppearance(settings = {}, dark = false) {
  const pink = settings.accent === "pink";
  return {
    surface: dark ? "#252839" : "#f8f9fd",
    subtle: dark ? "#171824" : "#e8eaf2",
    hover: dark ? "#33374c" : "#e1e5f1",
    text: dark ? "#f1f3ff" : "#292b43",
    muted: dark ? "#b7bfd9" : "#626780",
    line: dark ? "#4a516c" : "#b5bbd0",
    stroke: dark ? "#8e98ba" : "#7c829a",
    accent: dark
      ? pink
        ? "#ffacd9"
        : "#9ccfff"
      : pink
        ? "#a52e76"
        : "#255ec2",
    accentHover: dark
      ? pink
        ? "#ffc8e6"
        : "#c1e2ff"
      : pink
        ? "#86215d"
        : "#17479b",
    accentText: dark ? "#171824" : "#ffffff",
    selected: dark
      ? pink
        ? "#482b45"
        : "#263b58"
      : pink
        ? "#f6e0ee"
        : "#ddeaff",
    danger: dark ? "#ffabc4" : "#a72b50",
    dangerBackground: dark ? "#49283c" : "#fde5ee",
    dangerFill: dark ? "#ffabc4" : "#a72b50",
    dangerFillHover: dark ? "#ffc9db" : "#86213f",
    dangerText: dark ? "#171824" : "#ffffff",
    warning: dark ? "#f8d497" : "#775015",
    warningBackground: dark ? "#443a2b" : "#fff0d5",
    success: dark ? "#a4e1d5" : "#23685e",
    successBackground: dark ? "#263e3c" : "#ddf3eb",
    radius: 18,
    controlRadius: 12,
    borderWidth: 1,
    shadow: {
      x: 0,
      y: 8,
      blur: 36,
      spread: 0,
      color: dark ? "#00000066" : "#3d46652e",
    },
    controlShadow: null,
    fontFamily: ["Trebuchet MS", "Segoe UI", "Microsoft YaHei", "sans-serif"],
  };
}
