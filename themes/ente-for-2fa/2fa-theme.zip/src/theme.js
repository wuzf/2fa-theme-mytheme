import { hostText, localText } from "./i18n.js";
import { hostAppearance } from "./hostAppearance.js";

let disclosureSequence = 0;

/** Complete frontend. The host SDK remains the only account/OTP/command authority. */
export function mount({ root, sdk, appearance = {}, signal }) {
  if (!root || !sdk || signal?.aborted) return { update() {}, unmount() {} };
  const document = root.ownerDocument;
  const window = document.defaultView;
  let live = true;
  let snapshot = sdk.getSnapshot();
  let currentAppearance = appearance;
  let lang = snapshot.preferences.resolvedLanguage || "en";
  let menuId = null;
  let unsubscribe = () => {};
  let lastStructure = "";
  let lastChrome = "";
  const stateNodes = new Map();
  const featureNodes = new Map();
  let activeManagementGroup = "data";
  const cards = new Map();
  const groups = new Map();
  let lastHostAppearance = "";
  let noticeTimer = null;
  let noticeGeneration = 0;
  let noticeSequence = 0;
  let noticeRoute = window.location.hash;
  const operationRows = new Map();
  const queueRows = new Map();
  const animations = new Map();
  const local = (key) => localText(lang, key);
  const t = (key, fallback, params) => hostText(sdk, key, fallback, params);
  const el = (tag, className = "", text) => {
    const node = document.createElement(tag);
    node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };
  function button(text, action, className = "ente-button", value) {
    const node = el("button", className, text);
    node.type = "button";
    node.dataset.action = action;
    if (value !== undefined) node.dataset.value = value;
    return node;
  }
  function labelSelect(key) {
    const label = el("label", "ente-select-field");
    const title = el("span");
    const select = el("select", "ente-input");
    select.dataset.setting = key;
    label.append(title, select);
    return { label, title, select };
  }
  function options(select, choices, value) {
    const signature = JSON.stringify(choices);
    if (select.dataset.options !== signature) {
      select.replaceChildren(
        ...choices.map(([id, label]) => {
          const option = el("option", "", label);
          option.value = id;
          return option;
        }),
      );
      select.dataset.options = signature;
    }
    if (select.value !== value) select.value = value;
  }
  const surface = el("div", "ente-theme");
  const skip = button("", "skip", "ente-skip-link");
  const header = el("header", "ente-topbar");
  const head = el("div", "ente-topbar-inner");
  const brand = el("div", "ente-brand");
  const mark = el("span", "ente-brand-mark");
  mark.setAttribute("aria-hidden", "true");
  const identity = el("div");
  const brandName = el("h1", "ente-brand-name ente-display", "2FA");
  identity.append(brandName);
  brand.append(mark, identity);
  const headerActions = el("nav", "ente-actions ente-topbar-actions");
  const add = button("", "add-menu", "ente-button is-primary");
  add.id = "ente-add-button";
  add.setAttribute("aria-haspopup", "menu");
  add.setAttribute("aria-expanded", "false");
  add.setAttribute("aria-controls", "ente-add-menu");
  // Like Ente's own button: the plus offers the ways to add an account.
  const addScrim = el("div", "ente-add-scrim");
  addScrim.hidden = true;
  const addMenu = el("div", "ente-add-menu");
  addMenu.id = "ente-add-menu";
  addMenu.hidden = true;
  addMenu.setAttribute("role", "menu");
  addMenu.setAttribute("aria-labelledby", add.id);
  const svgNS = "http://www.w3.org/2000/svg";
  const addIcons = {
    "scan-import":
      "M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5M8 8h3v3H8zM13 13h3v3h-3zM13 8h3M8 16h2",
    "account-add": "M3.5 6.5h17v11h-17zM7 10h1M11 10h1M15.5 10h1M7 14h10",
    import: "M12 4v11M7.5 10.5L12 15l4.5-4.5M4 15v4.5h16V15",
  };
  const addItems = new Map(
    Object.keys(addIcons).map((id) => {
      const item = button("", "host", "ente-add-item", id);
      item.setAttribute("role", "menuitem");
      const label = el("span", "ente-add-label");
      const badge = el("span", "ente-add-icon");
      const svg = document.createElementNS(svgNS, "svg");
      svg.setAttribute("viewBox", "0 0 24 24");
      svg.setAttribute("aria-hidden", "true");
      svg.setAttribute("focusable", "false");
      const path = document.createElementNS(svgNS, "path");
      path.setAttribute("d", addIcons[id]);
      svg.append(path);
      badge.append(svg);
      item.append(label, badge);
      addMenu.append(item);
      return [id, { item, label }];
    }),
  );
  const scheme = button("", "scheme", "ente-button is-quiet");
  const more = button("", "route", "ente-button is-quiet", "more");
  headerActions.append(addScrim, addMenu, add, more);
  const serviceNav = el("nav", "ente-service-nav");
  const serviceNavList = el("div", "ente-service-list");
  serviceNav.append(serviceNavList);
  const serviceNodes = new Map();
  header.append(head);
  const main = el("main", "ente-workspace");
  const notice = el("div", "ente-notice");
  notice.setAttribute("role", "status");
  notice.setAttribute("aria-live", "polite");
  notice.setAttribute("aria-atomic", "true");
  notice.hidden = true;
  const states = el("section", "ente-states");
  const operations = el("section", "ente-operation-region");
  const operationsTitle = el("h2", "ente-group-title");
  const queue = el("section", "ente-queue-region");
  const queueTitle = el("h2", "ente-group-title");
  const queueView = button("", "host", "ente-button", "offline-queue");
  const queueRetry = button(
    "",
    "host",
    "ente-button",
    "offline-queue-status-retry",
  );
  const accountsPage = el("section", "ente-account-page");
  accountsPage.tabIndex = -1;
  const accountTitle = el("h2", "ente-sr-only");
  const count = el("span", "ente-section-description");
  const toolbar = el("div", "ente-toolbar");
  const searchForm = el("form", "ente-search");
  searchForm.setAttribute("role", "search");
  searchForm.autocomplete = "off";
  const search = el("input");
  search.type = "search";
  search.name = "account-search";
  search.autocomplete = "off";
  search.setAttribute("autocapitalize", "none");
  search.setAttribute("autocorrect", "off");
  search.spellcheck = false;
  search.setAttribute("data-lpignore", "true");
  search.setAttribute("data-1p-ignore", "true");
  search.setAttribute("data-bwignore", "true");
  search.dataset.setting = "query";
  const clear = button("×", "clear", "ente-button is-icon is-quiet");
  searchForm.append(search, clear);
  searchForm.id = "ente-search-" + ++disclosureSequence;
  // The app bar keeps search behind an icon until it is opened or a query is set.
  let searchOpen = false;
  const searchToggle = button(
    "",
    "search-toggle",
    "ente-button is-quiet is-icon ente-search-toggle",
  );
  searchToggle.setAttribute("aria-controls", searchForm.id);
  const headerTools = el("div", "ente-header-tools");
  head.append(brand, searchForm, serviceNav, headerActions, headerTools);
  const modes = labelSelect("mode");
  const sorting = labelSelect("sort");
  const groupSort = labelSelect("groupSort");
  const controls = el("div", "ente-toolbar-controls");
  const services = labelSelect("service");
  services.label.classList.add("ente-service-filter");
  services.title.classList.add("ente-sr-only");
  const disclosure = el("div", "ente-display-disclosure");
  const displayToggle = button("", "display", "ente-button is-quiet");
  const displayPanel = el("div", "ente-display-panel");
  displayPanel.id = "ente-view-options-" + ++disclosureSequence;
  displayPanel.hidden = true;
  displayToggle.setAttribute("aria-expanded", "false");
  displayToggle.setAttribute("aria-controls", displayPanel.id);
  displayPanel.append(modes.label, sorting.label, groupSort.label);
  disclosure.append(displayToggle, displayPanel);
  controls.append(services.label);
  headerTools.append(disclosure, searchToggle);
  const pageHeading = el("p", "ente-page-heading ente-display");
  pageHeading.setAttribute("aria-hidden", "true");
  toolbar.append(pageHeading, controls, count);
  const empty = el("div", "ente-empty-state");
  const emptyTitle = el("h3");
  const emptyDescription = el("p");
  const emptyAction = button("", "refresh");
  empty.append(emptyTitle, emptyDescription, emptyAction);
  const accountList = el("div", "ente-groups");
  accountsPage.append(accountTitle, toolbar, empty, accountList);
  const morePage = el("section", "ente-subpage");
  morePage.tabIndex = -1;
  const moreBack = button("", "route", "ente-button", "accounts");
  const moreTitle = el("h2", "ente-section-title");
  moreTitle.tabIndex = -1;
  const managementHeading = el("div", "ente-management-heading");
  managementHeading.append(moreBack, moreTitle);
  const featureList = el("div", "ente-management-groups");
  // The sections of Ente Auth's own settings page, in its order.
  const managementSections = [
    "data",
    "security",
    "appearance",
    "general",
    "support",
  ];
  const managementGroups = new Map(
    managementSections.map((key) => {
      const section = el("section", "ente-management-group");
      const title = el("h3");
      const toggle = button("", "management-group", "ente-group-toggle", key);
      const panel = el("div", "ente-management-list");
      panel.id = "ente-management-" + ++disclosureSequence;
      toggle.setAttribute("aria-controls", panel.id);
      toggle.setAttribute(
        "aria-expanded",
        String(key === activeManagementGroup),
      );
      panel.hidden = key !== activeManagementGroup;
      title.append(toggle);
      section.append(title, panel);
      featureList.append(section);
      return [key, { section, toggle, panel }];
    }),
  );
  // About and signing out (or in) are rows of their own after the sections,
  // as in Ente Auth.
  const aboutRow = el(
    "section",
    "ente-management-group ente-management-row ente-management-about",
  );
  const sessionRow = el(
    "section",
    "ente-management-group ente-management-row ente-management-session",
  );
  const managementRows = new Map([
    ["about", aboutRow],
    ["session", sessionRow],
  ]);
  featureList.append(aboutRow, sessionRow);
  morePage.append(managementHeading, featureList);
  const footer = el("footer", "ente-footer");
  const credit = el("span", "", "Ente · MIT");
  const license = el("a", "", "Licenses · MIT");
  license.href = new URL("../licenses/NOTICE.txt", import.meta.url).href;
  // The 2FA version, a newer release and the project links, from the host.
  const about = el("div", "ente-footer-about");
  const aboutVersion = el("span", "ente-footer-version");
  const aboutUpdate = el("a", "ente-footer-update");
  const aboutLinks = [
    ["documentation", "pageDocumentation", "Documentation"],
    ["extension", "pageBrowserExtension", "Browser extension"],
    ["feedback", "pageFeedback", "Report an issue"],
    ["source", "aboutSourceCode", "Source code"],
  ].map(([key, labelKey, fallback]) => ({
    key,
    labelKey,
    fallback,
    node:
      key === "extension"
        ? button("", "host", "ente-footer-link", "extension")
        : el("a", "ente-footer-link"),
  }));
  for (const link of [aboutUpdate, ...aboutLinks.map((item) => item.node)])
    if (link.tagName === "A") {
      link.target = "_blank";
      link.rel = "noopener noreferrer";
    }
  about.append(
    aboutVersion,
    aboutUpdate,
    ...aboutLinks.map((item) => item.node),
  );
  about.hidden = true;
  footer.append(credit, license, about);
  // The notice opens inside the page: a new window in an installed app closes
  // the app when the user goes back.
  const licensePanel = el("section", "ente-license-panel");
  licensePanel.id = "ente-license-" + ++disclosureSequence;
  licensePanel.hidden = true;
  const licenseHead = el("div", "ente-license-head");
  const licenseTitle = el("h2", "ente-license-title", license.textContent);
  const licenseClose = el("button", "ente-button is-quiet ente-license-close");
  licenseClose.type = "button";
  licenseHead.append(licenseTitle, licenseClose);
  const licenseText = el("pre", "ente-license-text");
  licenseText.tabIndex = -1;
  licensePanel.append(licenseHead, licenseText);
  license.setAttribute("aria-expanded", "false");
  license.setAttribute("aria-controls", licensePanel.id);
  main.append(
    notice,
    states,
    operations,
    queue,
    accountsPage,
    morePage,
    footer,
    licensePanel,
  );
  surface.append(skip, header, main);
  root.append(surface);

  let licenseLoaded = false;
  let licenseLoading = false;
  function setLicenseOpen(open) {
    licensePanel.hidden = !open;
    license.setAttribute("aria-expanded", String(open));
    if (!open) {
      license.focus({ preventScroll: true });
      return;
    }
    licenseClose.textContent = t("close", "Close");
    if (!licenseLoaded && !licenseLoading) {
      licenseLoading = true;
      licenseText.textContent = local("waiting");
      Promise.resolve()
        .then(() => window.fetch(license.href))
        .then((response) => {
          if (!response.ok) throw new Error(String(response.status));
          return response.text();
        })
        .then(
          (text) => {
            licenseLoading = false;
            if (!live) return;
            licenseLoaded = true;
            licenseText.textContent = text;
            // The text makes the panel taller; centre it again so it stays clear of bottom bars.
            if (!licensePanel.hidden)
              licensePanel.scrollIntoView?.({ block: "center" });
          },
          () => {
            licenseLoading = false;
            if (live) licenseText.textContent = local("failed");
          },
        );
    }
    licenseText.focus({ preventScroll: true });
    // Centred, so fixed bottom bars and floating buttons cannot cover it.
    licensePanel.scrollIntoView?.({ block: "center" });
  }
  license.addEventListener("click", (event) => {
    if (
      event.button !== 0 ||
      event.metaKey ||
      event.ctrlKey ||
      event.shiftKey ||
      event.altKey
    )
      return;
    event.preventDefault();
    if (live) setLicenseOpen(licensePanel.hidden);
  });
  licenseClose.addEventListener("click", () => setLicenseOpen(false));
  licensePanel.addEventListener("keydown", (event) => {
    if (event.key !== "Escape" || event.isComposing) return;
    event.preventDefault();
    setLicenseOpen(false);
  });

  function currentAccount(id) {
    return snapshot.library.accounts.find((account) => account.ref.id === id);
  }
  function clearNotice() {
    noticeGeneration += 1;
    noticeSequence += 1;
    window.clearTimeout(noticeTimer);
    noticeTimer = null;
    notice.textContent = "";
    notice.hidden = true;
  }
  function say(message, { kind = "info" } = {}) {
    if (!live) return;
    if (!message) {
      clearNotice();
      return;
    }
    window.clearTimeout(noticeTimer);
    const sequence = ++noticeSequence;
    notice.textContent = message;
    notice.dataset.kind = kind;
    notice.hidden = false;
    noticeTimer = window.setTimeout(
      () => {
        if (!live || sequence !== noticeSequence) return;
        noticeTimer = null;
        notice.textContent = "";
        notice.hidden = true;
      },
      kind === "error" ? 8000 : 4000,
    );
  }
  function explain(reason) {
    if (reason === "authentication-required")
      return t("loginSubmitBtn", "Sign in");
    if (reason === "unavailable" || reason === "host-unavailable")
      return local("unavailable");
    const keys = {
      "write-busy-reclick": "coreHotpWriteBusy",
      offline: "coreHotpCopyOffline",
      "clipboard-failed": "copyFailed",
      "reservation-rejected": "coreHotpRejected",
      "operation-pending-account-changed": "coreHotpAccountChangedPending",
      "counter-limit": "coreHotpLimit",
      "reconciliation-failed": "coreHotpReconcileFailed",
    };
    if (keys[reason]) return t(keys[reason], local("failed"));
    return [
      "not-ready",
      "stale-target",
      "expired",
      "clock-changed",
      "account-changed",
    ].includes(reason)
      ? local("expired")
      : local("failed");
  }
  function observe(
    promise,
    kind = "command",
    operationId = null,
    copied = local("copied"),
  ) {
    const session = snapshot.epochs.session;
    const generation = noticeGeneration;
    const notify = (message, type) => {
      if (generation === noticeGeneration) say(message, { kind: type });
    };
    Promise.resolve(promise).then(
      (result) => {
        if (
          !live ||
          snapshot.epochs.session !== session ||
          ["mount-invalidated", "session-invalidated"].includes(result?.reason)
        )
          return;
        if (kind === "reconcile" && result?.status === "committed") {
          const operation = snapshot.host.operations?.find(
            (item) => item.operationId === operationId,
          );
          if (operation) {
            const facts = operationFacts(operation);
            notify(
              [facts.clipboard, facts.reservation, facts.attention]
                .filter(Boolean)
                .join(" · "),
              operationResolved(operation) ? "success" : "error",
            );
          }
        } else if (result?.clipboard) {
          if (result.reservation && result.reservation !== "not-attempted") {
            renderOperations();
            const facts = operationFacts(result);
            notify(
              [facts.clipboard, facts.reservation, facts.attention]
                .filter(Boolean)
                .join(" · "),
              operationResolved(result) ? "success" : "error",
            );
          } else {
            notify(
              result.clipboard === "copied" ? copied : explain(result.reason),
              result.clipboard === "copied" ? "success" : "error",
            );
          }
        } else if (
          ["rejected", "unknown", "not-started"].includes(result?.status)
        )
          notify(explain(result.reason), "error");
        else if (
          // The page itself shows a scheme change; a notice would only repeat it.
          !["host", "scheme"].includes(kind) &&
          ["committed", "loaded"].includes(result?.status)
        )
          notify(local("done"), "success");
      },
      () => {
        if (live && snapshot.epochs.session === session)
          notify(local("failed"), "error");
      },
    );
  }
  function operationResolved(operation) {
    // A confirmed reservation and a completed clipboard do not prove that the
    // local counter committed. Only a complete commit or a successful readback
    // can resolve that conflict, and a read cannot confirm an unknown POST.
    if (
      operation.status !== "settled" ||
      operation.clipboard !== "copied" ||
      operation.reservation !== "confirmed"
    )
      return false;
    if (
      operation.reason === "local-refresh-failed" &&
      operation.reconciliation !== "succeeded"
    )
      return false;
    return (
      (operation.localCommit === "committed" &&
        operation.recovery === "none" &&
        ["not-needed", "succeeded"].includes(operation.reconciliation)) ||
      (operation.reconciliation === "succeeded" &&
        operation.recovery === "reconciled")
    );
  }
  function operationFacts(operation) {
    const states = {
      pending: "coreHotpStatePending",
      confirmed: "coreHotpStateConfirmed",
      rejected: "coreHotpStateRejected",
      unknown: "coreHotpStateUnknown",
      copied: "coreHotpStateCopied",
      failed: "coreHotpStateFailed",
    };
    const clipboard = t(
      states[operation.clipboard] || "coreHotpStateUnknown",
      local("unknown"),
    );
    const reservation = t(
      states[operation.reservation] || "coreHotpStateUnknown",
      local("unknown"),
    );
    let attention = "";
    if (operation.reconciliation === "running") attention = local("waiting");
    else if (
      operation.reconciliation === "failed" ||
      operation.recovery === "retry-reconcile"
    )
      attention = t("coreHotpReconcileFailed", local("failed"));
    else if (
      operation.clipboard === "failed" &&
      operation.reservation === "confirmed"
    )
      attention = t("coreHotpCopyFailedAdvanced", local("failed"));
    else if (!operationResolved(operation))
      attention = t("coreHotpReconcile", local("waiting"));
    return {
      clipboard: t("coreHotpClipboardState", `Clipboard: ${clipboard}`, {
        state: clipboard,
      }),
      reservation: t(
        "coreHotpReservationState",
        `Reservation: ${reservation}`,
        { state: reservation },
      ),
      attention,
    };
  }
  function host(request, trigger) {
    closeMenu(false);
    // The session row is replaced when the session changes, so its dialogs
    // return to Manage, like the status rows.
    const returnFocus =
      states.contains(trigger) ||
      queue.contains(trigger) ||
      sessionRow.contains(trigger)
        ? more
        : trigger
            .closest?.(".ente-management-group")
            ?.querySelector(".ente-group-toggle") || trigger;
    const handle = sdk.host.open(request, { returnFocus });
    if (handle.status === "rejected")
      say(explain(handle.reason), { kind: "error" });
    else observe(handle.closed, "host");
  }
  function descriptorRequest(value) {
    const found = sdk.host
      .listActions()
      .find((item) => item.actionId === value);
    return found?.request || { kind: value };
  }
  function closeMenu(restoreFocus = true) {
    const card = cards.get(menuId);
    if (card) {
      card.menu.hidden = true;
      card.node.dataset.menuOpen = "false";
      card.trigger.setAttribute("aria-expanded", "false");
      if (restoreFocus && card.trigger.isConnected) card.trigger.focus();
    }
    menuId = null;
  }
  function openMenu(id, focus = false) {
    if (menuId === id) {
      closeMenu();
      return;
    }
    closeMenu(false);
    const card = cards.get(id);
    if (!card) return;
    menuId = id;
    card.menu.hidden = false;
    card.node.dataset.menuOpen = "true";
    card.trigger.setAttribute("aria-expanded", "true");
    if (focus) card.menu.firstElementChild?.focus();
  }
  function cancelAnimation(id) {
    animations.get(id)?.cancel();
    animations.delete(id);
  }
  // Shows a code in two halves ("475 074"). The gap is spacing, not text, so
  // the node's text stays the exact code.
  function setCode(node, value) {
    if (node.dataset.code === value) return;
    node.dataset.code = value;
    if (!/^\d{6,10}$/.test(value)) {
      node.textContent = value;
      return;
    }
    const half = Math.ceil(value.length / 2);
    node.replaceChildren(
      el("span", "ente-code-group", value.slice(0, half)),
      el("span", "ente-code-group", value.slice(half)),
    );
  }
  function copy(id, slot) {
    const target = sdk.otp.readCopyTarget(id, slot);
    if (target.status !== "ready") {
      say(explain(target.reason), { kind: "error" });
      return;
    }
    const card = cards.get(id);
    cancelAnimation(id);
    if (card)
      setCode(
        slot === "next" ? card.nextValue : card.value,
        target.target.value,
      );
    // Name the slot: the current and the next code are copied the same way.
    const account = currentAccount(id);
    const copied = t(
      slot === "next" ? "coreCopiedNextService" : "coreCopiedService",
      local("copied"),
      { name: account?.service.label || t("coreCode", "Code") },
    );
    // Same event stack: no await before the SDK starts the native clipboard.
    observe(sdk.otp.copy(target.target), "copy", null, copied);
  }
  function createCard(account) {
    const node = el("article", "ente-card");
    node.dataset.account = account.ref.id;
    const cardHeader = el("div", "ente-card-header");
    const icon = el("span", "ente-service-mark");
    icon.setAttribute("aria-hidden", "true");
    const names = el("div", "ente-account-identity");
    const service = el("h3", "ente-account-name");
    const accountLabel = el("p", "ente-account-address");
    names.append(service, accountLabel);
    const menuHolder = el("div", "ente-account-menu");
    const trigger = button("⋮", "menu", "ente-button is-icon");
    trigger.setAttribute("aria-expanded", "false");
    const menu = el("div", "ente-menu-popover");
    menu.hidden = true;
    const menuActions = ["qr", "uri", "link", "edit", "delete"].map((action) =>
      button(
        "",
        action,
        "ente-menu-item" + (action === "delete" ? " is-danger" : ""),
      ),
    );
    menu.append(...menuActions);
    menuHolder.append(trigger, menu);
    cardHeader.append(icon, names, menuHolder);
    const codes = el("div", "ente-codes");
    const codeLabel = el("div", "ente-otp-label ente-sr-only");
    codeLabel.id = "ente-code-details-" + ++disclosureSequence;
    const currentLabel = el("span");
    const badge = el("span", "ente-badge");
    codeLabel.append(currentLabel, badge);
    const hotpLabel = el("span", "ente-hotp-label", "HOTP");
    names.append(hotpLabel);
    const copyButton = button("", "copy", "ente-copy-code");
    copyButton.setAttribute("aria-describedby", codeLabel.id);
    const value = el("span", "ente-otp-value");
    const copyIcon = el("span", "ente-copy-symbol", "⧉");
    copyIcon.setAttribute("aria-hidden", "true");
    copyButton.append(value, copyIcon);
    const codeStatus = el("span", "ente-code-status");
    codeStatus.hidden = true;
    const next = button("", "next", "ente-otp-next");
    const nextLabel = el("span");
    const nextValue = el("span", "ente-next-value");
    next.append(nextLabel, nextValue);
    // HOTP cards show their counter where TOTP cards show the next code. The
    // badge already reads it to screen readers.
    const counter = el("span", "ente-counter");
    counter.setAttribute("aria-hidden", "true");
    codes.append(codeLabel, copyButton, codeStatus, next, counter);
    const timing = el("div", "ente-expiry");
    const timingLabel = el("div", "ente-expiry-label");
    const timingTitle = el("span");
    const remaining = el("strong");
    timingLabel.append(timingTitle, remaining);
    const progress = el("div", "ente-progress");
    progress.setAttribute("aria-hidden", "true");
    const fill = el("span", "ente-progress-fill");
    progress.append(fill);
    timing.append(timingLabel, progress);
    node.append(cardHeader, codes, timing);
    return {
      node,
      icon,
      service,
      accountLabel,
      trigger,
      menu,
      menuActions,
      currentLabel,
      hotpLabel,
      badge,
      copyButton,
      codeStatus,
      value,
      next,
      nextLabel,
      nextValue,
      counter,
      timing,
      timingTitle,
      remaining,
      progress,
      fill,
      account,
      previous: null,
    };
  }
  // Shows the service icon once it has loaded. The letter stays when there is
  // no icon or it cannot load (the editor preview does not allow it).
  function setServiceMark(
    node,
    account,
    letter = Array.from(account.service.label)[0] || "•",
  ) {
    const url = account.service.iconURL || "";
    if (node.dataset.letter === letter && node.dataset.icon === url) return;
    node.dataset.letter = letter;
    node.dataset.icon = url;
    node.classList.remove("has-icon");
    node.textContent = letter;
    if (!url) return;
    const image = node.ownerDocument.createElement("img");
    image.alt = "";
    image.decoding = "async";
    image.addEventListener(
      "load",
      () => {
        if (node.dataset.icon !== url) return;
        node.replaceChildren(image);
        node.classList.add("has-icon");
      },
      { once: true },
    );
    image.src = url;
  }
  function updateCard(card, account) {
    card.account = account;
    card.service.textContent = account.service.label;
    card.service.title = account.service.label;
    card.accountLabel.textContent = account.accountLabel;
    card.accountLabel.title = account.accountLabel;
    card.accountLabel.hidden = !account.accountLabel;
    setServiceMark(card.icon, account);
    card.trigger.setAttribute(
      "aria-label",
      t("cardMenuAriaLabel", local("more")) + " · " + account.service.label,
    );
    const labels = [
      ["cardMenuQRCode", "QR"],
      ["cardMenuCopyURI", "Copy URI"],
      ["cardMenuCopyLink", "Copy link"],
      ["cardMenuEdit", "Edit"],
      ["cardMenuDelete", "Delete"],
    ];
    card.menuActions.forEach((node, index) => {
      node.textContent = t(...labels[index]);
    });
    card.currentLabel.textContent = local("current");
    card.hotpLabel.hidden = account.type !== "HOTP";
    card.node.dataset.type = account.type;
    // Only counter-based accounts carry a badge; TOTP needs no metadata. HOTP
    // cards hide the timer row, so the badge names the counter.
    card.badge.textContent =
      account.type === "HOTP"
        ? `${account.type} · ${t("counterLabel", "Counter")} ${account.counter}`
        : "";
    card.badge.hidden = account.type !== "HOTP";
    const value = account.otp.current?.value || "···";
    if (card.previous !== null && card.previous !== value) {
      cancelAnimation(account.ref.id);
      const effect = snapshot.preferences.otpAnimation;
      if (
        !snapshot.preferences.reducedMotion &&
        !window.matchMedia?.("(prefers-reduced-motion: reduce)").matches &&
        card.value.animate &&
        effect !== "none"
      ) {
        const frames =
          effect === "flip"
            ? [{ transform: "rotateX(75deg)" }, { transform: "rotateX(0)" }]
            : effect === "spotlight"
              ? [
                  { background: "var(--ente-accent-soft)" },
                  { background: "transparent" },
                ]
              : [
                  { transform: "translateY(-5px)", opacity: 0.4 },
                  { transform: "translateY(0)", opacity: 1 },
                ];
        animations.set(
          account.ref.id,
          card.value.animate(frames, { duration: 180 }),
        );
      }
    }
    card.previous = value;
    setCode(card.value, value);
    card.value.dataset.digits = String(account.digits);
    card.copyButton.disabled =
      account.otp.current?.copyAvailability !== "ready";
    card.codeStatus.hidden = !card.copyButton.disabled;
    card.codeStatus.textContent =
      account.otp.current?.copyAvailability === "offline"
        ? local("offline")
        : account.otp.state === "error"
          ? local("failed")
          : local("waiting");
    card.copyButton.title = card.copyButton.disabled
      ? account.otp.current?.copyAvailability === "offline"
        ? local("offline")
        : local("waiting")
      : t("copyOtpBtnTitle", "Copy code");
    card.copyButton.setAttribute(
      "aria-label",
      `${t("copyOtpBtnAriaLabel", "Copy current code")} · ${account.service.label} ${account.accountLabel}`,
    );
    card.next.hidden = account.type === "HOTP";
    card.counter.hidden = account.type !== "HOTP";
    card.counter.textContent =
      account.type === "HOTP"
        ? `${t("counterLabel", "Counter").trim()} ${account.counter}`
        : "";
    card.next.disabled = account.otp.next?.copyAvailability !== "ready";
    card.nextLabel.textContent = local("next");
    setCode(card.nextValue, account.otp.next?.value || "···");
    card.next.setAttribute(
      "aria-label",
      `${t("copyNextOtpBtnTitle", "Copy next code")} · ${account.service.label}`,
    );
    card.progress.hidden = account.type === "HOTP";
    card.timingTitle.textContent =
      account.type === "HOTP"
        ? t("counterLabel", "Counter")
        : `${account.period}${local("seconds")}`;
  }
  function renderTime() {
    if (!live) return;
    const now = sdk.clock?.now();
    for (const card of cards.values()) {
      const account = card.account;
      if (account.type === "HOTP") {
        card.remaining.textContent = String(account.counter);
        continue;
      }
      const current = account.otp.current;
      const seconds =
        typeof now === "number" && current
          ? Math.max(0, Math.ceil((current.validUntil - now) / 1000))
          : null;
      card.remaining.textContent =
        seconds === null ? local("waiting") : `${seconds}${local("seconds")}`;
      card.timing.dataset.expiring = String(seconds !== null && seconds <= 5);
      // The countdown line turns orange for the last 40% of the period.
      card.timing.dataset.caution = String(
        seconds !== null && seconds <= account.period * 0.4,
      );
      card.fill.style.setProperty(
        "--ente-progress",
        `${seconds === null ? 0 : Math.min(100, (seconds / account.period) * 100)}%`,
      );
      if (seconds === 0) {
        card.copyButton.disabled = true;
        card.codeStatus.hidden = false;
        if (account.otp.current?.copyAvailability === "ready")
          card.codeStatus.textContent = local("waiting");
      }
    }
  }
  function syncChildren(parent, nodes) {
    nodes.forEach((node, index) => {
      if (parent.children[index] !== node)
        parent.insertBefore(node, parent.children[index] || null);
    });
    while (parent.children.length > nodes.length)
      parent.lastElementChild.remove();
  }
  function renderAccounts() {
    const view = snapshot.library.view;
    const ids = new Set(
      snapshot.library.accounts.map((account) => account.ref.id),
    );
    for (const [id, card] of cards)
      if (!ids.has(id)) {
        if (menuId === id) closeMenu(false);
        cancelAnimation(id);
        card.node.remove();
        cards.delete(id);
      }
    for (const account of snapshot.library.accounts) {
      let card = cards.get(account.ref.id);
      if (!card) {
        card = createCard(account);
        cards.set(account.ref.id, card);
      }
      if (
        card.account.ref.generation !== account.ref.generation &&
        menuId === account.ref.id
      )
        closeMenu(false);
      updateCard(card, account);
    }
    const sections =
      view.mode === "grouped" && view.groups.length
        ? view.groups
        : [{ groupId: "ente-flat", label: "", ids: view.resultIds }];
    const structure = JSON.stringify([
      view.mode,
      sections.map((group) => [group.groupId, group.label, group.ids]),
    ]);
    if (structure !== lastStructure) {
      const liveGroups = new Set();
      const sectionsDOM = sections.map((group) => {
        liveGroups.add(group.groupId);
        let section = groups.get(group.groupId);
        if (!section) {
          section = {
            node: el("section", "ente-group"),
            title: el("h3", "ente-group-title"),
            list: el("div", "ente-account-grid"),
          };
          section.node.append(section.title, section.list);
          groups.set(group.groupId, section);
        }
        section.size = sections.length === 1 ? Infinity : group.ids.length;
        section.title.textContent = group.label;
        section.title.hidden =
          !group.label || (sections.length === 1 && group.isOther);
        syncChildren(
          section.list,
          group.ids.map((id) => cards.get(id)?.node).filter(Boolean),
        );
        return section.node;
      });
      syncChildren(accountList, sectionsDOM);
      for (const id of groups.keys())
        if (!liveGroups.has(id)) groups.delete(id);
      lastStructure = structure;
      layoutGroups();
    }
    if (menuId && !cards.get(menuId)?.node.isConnected) closeMenu(false);
    count.textContent = t("searchFoundCount", `${view.found} / ${view.total}`, {
      found: view.found,
      total: view.total,
    });
    const filtered = Boolean(view.query || view.serviceFilter);
    count.classList.toggle("ente-sr-only", !filtered);
    const signedOut = snapshot.session.state === "logged-out";
    empty.hidden = view.found > 0 && !signedOut;
    accountList.hidden = signedOut;
    const loading = snapshot.library.state === "loading";
    const failure = snapshot.library.state === "error";
    emptyTitle.textContent = signedOut
      ? t("loginSubmitBtn", "Sign in")
      : loading
        ? t("loadingSecrets", local("waiting"))
        : failure
          ? local("failed")
          : filtered
            ? t("searchNoMatch", "No matching accounts")
            : t("emptyTitle", "No accounts yet");
    emptyDescription.textContent = signedOut
      ? ""
      : loading
        ? ""
        : filtered
          ? t("searchNoMatchDesc", "Try a different search")
          : t("emptyDesc", "Add an account to generate verification codes.");
    emptyAction.textContent = signedOut
      ? t("loginSubmitBtn", "Sign in")
      : failure || loading
        ? t("retry", "Retry")
        : filtered
          ? t("searchClearAriaLabel", "Clear search")
          : t("fabScanQR", "Scan QR code");
    emptyAction.dataset.action = signedOut
      ? "host"
      : failure || loading
        ? "refresh"
        : filtered
          ? "clear"
          : "host";
    emptyAction.dataset.value = signedOut ? "login" : "scan-import";
    const offersScan = !signedOut && !failure && !loading && !filtered;
    const scanAction = offersScan
      ? sdk.host.listActions().find((item) => item.actionId === "scan-import")
      : null;
    emptyAction.disabled = offersScan && !scanAction?.enabled;
    emptyAction.title = emptyAction.disabled
      ? explain(scanAction?.reason || "unavailable")
      : "";
    renderTime();
  }
  function preserveStatusFocus(node) {
    if (!snapshot.host.dialogOpen && node.contains(document.activeElement))
      more.focus({ preventScroll: true });
  }
  // Groups share the card columns, so a group with fewer accounts than a row
  // holds takes only that many columns and the next small group sits beside it.
  function layoutGroups() {
    if (accountList.hidden) return;
    const tracks = window
      .getComputedStyle(accountList)
      .gridTemplateColumns.split(" ")
      .filter(Boolean);
    const columns = tracks.every((track) => track.endsWith("px"))
      ? tracks.length
      : 0;
    for (const section of groups.values())
      section.node.style.gridColumn =
        columns && section.size < columns ? `span ${section.size}` : "";
  }
  // A mouse wheel cannot move a row without a scrollbar: over the chips, the
  // wheel scrolls them sideways until either end, then the page scrolls again.
  function onNavWheel(event) {
    if (event.ctrlKey || Math.abs(event.deltaX) >= Math.abs(event.deltaY))
      return;
    const max = serviceNav.scrollWidth - serviceNav.clientWidth;
    if (max <= 0) return;
    const step = event.deltaY * (event.deltaMode === 1 ? 16 : 1);
    const next = Math.min(max, Math.max(0, serviceNav.scrollLeft + step));
    if (Math.abs(next - serviceNav.scrollLeft) < 1) return;
    event.preventDefault();
    serviceNav.scrollLeft = next;
    updateNavFade();
  }
  // Fades mark the side where more chips are hidden.
  function updateNavFade() {
    const max = serviceNav.scrollWidth - serviceNav.clientWidth;
    serviceNav.dataset.fadeStart = String(serviceNav.scrollLeft > 1);
    serviceNav.dataset.fadeEnd = String(serviceNav.scrollLeft < max - 1);
  }
  function onLayoutResize() {
    layoutGroups();
    updateNavFade();
  }
  // Hosts before host.about have no version to show; the row stays hidden.
  function renderAbout() {
    const info = snapshot.host.about;
    about.hidden = !info;
    if (!info) return;
    aboutVersion.textContent = `2FA v${info.version}`;
    aboutUpdate.hidden = !(info.latestVersion && info.links.releases);
    if (!aboutUpdate.hidden) {
      aboutUpdate.href = info.links.releases;
      aboutUpdate.textContent = t(
        "versionUpdateAvailable",
        `New version available: v${info.latestVersion}`,
        { version: `v${info.latestVersion}` },
      );
    }
    const extension = sdk.host
      .listActions()
      .find((item) => item.actionId === "extension");
    for (const { key, labelKey, fallback, node } of aboutLinks) {
      node.textContent = t(labelKey, fallback);
      if (key === "extension") node.hidden = !extension?.enabled;
      else {
        node.hidden = !info.links[key];
        if (info.links[key]) node.href = info.links[key];
      }
    }
  }
  function renderStates() {
    const entries = [];
    const addState = (key, text, action, value) =>
      entries.push({ key, text, action, value });
    if (sdk.identity.mode === "preview")
      addState("preview", "Preview · Synthetic data / 预览 · 合成数据");
    if (snapshot.session.state !== "authenticated")
      addState("session", t("loginSubmitBtn", "Sign in"), "host", "login");
    if (!snapshot.connectivity.onlineHint)
      addState("offline", local("offline"));
    // Cached accounts show first on every load; name them only once the refresh is over,
    // and not beside a failed refresh, which already says so and offers a retry.
    if (
      snapshot.library.source === "local" &&
      !["refreshing", "error"].includes(snapshot.library.refreshState)
    )
      addState("local", local("local"));
    if (snapshot.library.refreshState === "error")
      addState("refresh-error", local("failed"), "refresh");
    if (
      // Only a clock that was never checked; a cached offset from an earlier check is fine.
      snapshot.clock.status === "local"
    )
      addState("clock", t("clockWarningText", local("clock")));
    if (snapshot.library.hidden.count)
      addState(
        "hidden",
        `${t("pageHiddenAccounts", "Hidden accounts")} · ${snapshot.library.hidden.count}`,
        "host",
        "hidden-accounts",
      );
    if (snapshot.host.updateAvailable || snapshot.host.versionMismatch)
      addState("update", t("pwaUpdateBtn", "Update"), "reload", "update");
    if (snapshot.host.offlineReady === false)
      addState("offline-ready", local("offlineNotReady"));
    const keys = new Set(entries.map((item) => item.key));
    for (const [key, node] of stateNodes)
      if (!keys.has(key)) preserveStatusFocus(node);
    syncChildren(
      states,
      entries.map(({ key, text, action, value }) => {
        let node = stateNodes.get(key);
        if (!node) {
          node = action
            ? button("", action, "ente-state ente-button", value)
            : el("p", "ente-state");
          node.dataset.state = key;
          stateNodes.set(key, node);
        }
        if (node.textContent !== text) node.textContent = text;
        return node;
      }),
    );
    for (const key of stateNodes.keys())
      if (!keys.has(key)) stateNodes.delete(key);
    states.hidden = entries.length === 0;
  }
  function setManagementGroup(key, focus = false) {
    activeManagementGroup = key;
    for (const [id, group] of managementGroups) {
      const open = key === id;
      if (
        !open &&
        !snapshot.host.dialogOpen &&
        group.panel.contains(document.activeElement)
      )
        (managementGroups.get(key)?.toggle || group.toggle).focus({
          preventScroll: true,
        });
      group.panel.hidden = !open;
      group.toggle.setAttribute("aria-expanded", String(open));
    }
    if (focus && !snapshot.host.dialogOpen)
      managementGroups.get(key)?.toggle.focus({ preventScroll: true });
  }
  function renderManagement() {
    const actions = sdk.host.listActions().filter((item) => {
      if (item.requires) return false;
      switch (item.actionId) {
        // Safe mode is offered by the host's error bar, not the menu.
        case "recovery":
        case "hidden-accounts":
        case "offline-queue":
        case "offline-queue-status-retry":
          return false;
        case "login":
          return snapshot.session.state === "logged-out";
        case "logout":
          return ["authenticated", "unconfirmed"].includes(
            snapshot.session.state,
          );
        case "pwa-install":
          return snapshot.host.installAvailable === true && item.enabled;
        default:
          return true;
      }
    });
    let firstReason = null;
    for (const [id, { item }] of addItems) {
      const action = actions.find((entry) => entry.actionId === id);
      item.hidden = !action;
      item.disabled = !action?.enabled;
      item.title = item.disabled
        ? explain(action?.reason || "unavailable")
        : "";
      firstReason ||= action && !action.enabled ? action.reason : null;
    }
    add.disabled = ![...addItems.values()].some(
      ({ item }) => !item.hidden && !item.disabled,
    );
    add.title = add.disabled ? explain(firstReason || "unavailable") : "";
    if (add.disabled) closeAddMenu(false);
    const signature = JSON.stringify([lang, actions]);
    for (const [key, group] of managementGroups)
      group.toggle.textContent = local(
        "group" + key[0].toUpperCase() + key.slice(1),
      );
    if (signature === lastChrome) return;
    const available = new Set(
      actions.filter((item) => item.enabled).map((item) => item.actionId),
    );
    const toolIds = new Set([
      "tool:qr-decode",
      "tool:qr-generate",
      "tool:base32",
      "tool:timestamp",
      "tool:key-check",
      "tool:key-generate",
    ]);
    const providerIds = new Set([
      "sync-provider:webdav",
      "sync-provider:s3",
      "sync-provider:onedrive",
      "sync-provider:gdrive",
    ]);
    // Each section lists its entries in this order. Scanning keeps its header
    // button and is also listed first with the other ways in. An action the
    // theme does not know goes to General, after the known ones.
    const order = {
      data: ["scan-import", "account-add", "import", "export", "backup"],
      security: ["settings:security", "settings:custom-code"],
      appearance: ["scheme", "appearance"],
      general: [
        "settings:preferences",
        "settings:sync",
        ...providerIds,
        "tools",
        ...toolIds,
        "quick-otp",
      ],
      support: ["extension", "pwa-install"],
      about: ["settings:about"],
      session: ["login", "logout"],
    };
    const sectionOf = (id) =>
      Object.keys(order).find((key) => order[key].includes(id)) || "general";
    const grouped = new Map(
      [...managementGroups.keys(), ...managementRows.keys()].map((key) => [
        key,
        [],
      ]),
    );
    grouped.get("appearance").push(["scheme", scheme]);
    const retained = new Set();
    for (const item of actions) {
      if (available.has("tools") && toolIds.has(item.actionId)) continue;
      if (available.has("settings:sync") && providerIds.has(item.actionId))
        continue;
      retained.add(item.actionId);
      const key = sectionOf(item.actionId);
      let row = featureNodes.get(item.actionId);
      if (!row) {
        const node = button("", "host", "ente-feature", item.actionId);
        const label = el("span");
        const reason = el("small", "ente-muted");
        node.append(label, reason);
        row = { node, label, reason };
        featureNodes.set(item.actionId, row);
      }
      const label =
        item.actionId === "appearance"
          ? local("appearance")
          : item.actionId === "recovery"
            ? t("appearanceUseDefault", "Use default interface")
            : item.actionId === "quick-otp"
              ? t("quickOtpTitle", "Generate verification code")
              : t(item.labelKey, local("unavailable"));
      if (row.label.textContent !== label) row.label.textContent = label;
      row.node.disabled = !item.enabled;
      const reason = item.enabled ? "" : explain(item.reason);
      if (row.reason.textContent !== reason) row.reason.textContent = reason;
      row.reason.hidden = item.enabled;
      grouped.get(key).push([item.actionId, row.node]);
    }
    let sessionFocused = false;
    for (const [key, row] of featureNodes)
      if (!retained.has(key)) {
        if (
          !snapshot.host.dialogOpen &&
          row.node.contains(document.activeElement)
        ) {
          // A session row that goes hands focus to the one that replaces it.
          if (sessionRow.contains(row.node)) sessionFocused = true;
          else
            (
              row.node
                .closest(".ente-management-group")
                ?.querySelector(".ente-group-toggle") || more
            ).focus({ preventScroll: true });
        }
        featureNodes.delete(key);
      }
    for (const [key, entries] of grouped) {
      const rank = (id) =>
        order[key].includes(id) ? order[key].indexOf(id) : order[key].length;
      entries.sort((a, b) => rank(a[0]) - rank(b[0]));
      const row = managementRows.get(key);
      const section = row || managementGroups.get(key).section;
      syncChildren(
        row || managementGroups.get(key).panel,
        entries.map(([, node]) => node),
      );
      // A section the host offers nothing for is left out.
      if (
        !entries.length &&
        !snapshot.host.dialogOpen &&
        section.contains(document.activeElement)
      )
        more.focus({ preventScroll: true });
      section.hidden = !entries.length;
    }
    if (sessionFocused)
      (sessionRow.querySelector(".ente-feature") || more).focus({
        preventScroll: true,
      });
    lastChrome = signature;
  }
  function renderOperations() {
    const records = (snapshot.host.operations || []).filter(
      (item) => item.type === "hotp" && !operationResolved(item),
    );
    operations.hidden = records.length === 0;
    operationsTitle.textContent = t(
      "coreHotpOperationTitle",
      "HOTP operation status",
    );
    const ids = new Set(records.map((operation) => operation.operationId));
    syncChildren(operations, [
      operationsTitle,
      ...records.map((operation) => {
        let row = operationRows.get(operation.operationId);
        if (!row) {
          row = {
            node: el("div", "ente-operation"),
            name: el("strong"),
            clipboard: el("span"),
            reservation: el("span"),
            attention: el("span"),
            reconcile: button(
              "",
              "reconcile",
              "ente-button",
              operation.operationId,
            ),
            recover: button("", "reload", "ente-button", "recovery"),
          };
          row.node.append(
            row.name,
            row.clipboard,
            row.reservation,
            row.attention,
            row.reconcile,
            row.recover,
          );
          operationRows.set(operation.operationId, row);
        }
        const account = currentAccount(String(operation.accountId));
        row.name.textContent = account?.service.label || "HOTP";
        const facts = operationFacts(operation);
        row.clipboard.textContent = facts.clipboard;
        row.reservation.textContent = facts.reservation;
        row.attention.textContent = facts.attention;
        row.attention.hidden = !facts.attention;
        row.reconcile.textContent = t(
          "coreHotpReconcile",
          "Check counter state",
        );
        row.reconcile.disabled = operation.reconciliation === "running";
        row.recover.textContent = t(
          "coreHotpRecoveryReload",
          "Recover in safe mode",
        );
        row.recover.hidden = operation.recovery !== "reload-required";
        return row.node;
      }),
    ]);
    for (const id of operationRows.keys())
      if (!ids.has(id)) operationRows.delete(id);
  }
  function renderQueue() {
    const records = snapshot.queue.operations || [];
    const hidden =
      records.length === 0 &&
      !snapshot.queue.unavailable &&
      !snapshot.queue.authRequired;
    if (hidden) preserveStatusFocus(queue);
    queue.hidden = hidden;
    queueTitle.textContent = local("queue");
    queueView.textContent = t("offlineQueueView", "View pending changes");
    queueRetry.textContent = t("restoreRefresh", "Refresh");
    if (!snapshot.queue.unavailable) preserveStatusFocus(queueRetry);
    queueRetry.hidden = !snapshot.queue.unavailable;
    const nodes = [queueTitle, queueView, queueRetry];
    const ids = new Set();
    records.forEach((item) => {
      const id = item.operationId || item.id;
      ids.add(id);
      let row = queueRows.get(id);
      if (!row) {
        row = {
          node: el("div", "ente-operation"),
          name: el("strong"),
          status: el("span"),
          actions: new Map(),
        };
        row.node.append(row.name, row.status);
        queueRows.set(id, row);
      }
      row.name.textContent = item.name || local("accounts");
      const status =
        item.status === "failed" || item.failureReason
          ? local("failed")
          : item.claimed || item.status === "sending"
            ? local("waiting")
            : local("queue");
      row.status.textContent = status;
      for (const [flag, kind, key, fallback] of [
        ["canEdit", "offline-queue-edit", "offlineQueueEditRetry", "Edit"],
        ["canRetry", "offline-queue-retry", "retry", "Retry"],
        [
          "canCancel",
          "offline-queue-cancel",
          "offlineQueueCancelChange",
          "Cancel",
        ],
      ]) {
        let action = row.actions.get(kind);
        if (!action) {
          action = button("", "queue", "ente-button", kind);
          row.actions.set(kind, action);
          row.node.append(action);
        }
        action.textContent = t(key, fallback);
        if (!item[flag]) preserveStatusFocus(action);
        action.hidden = !item[flag];
        action.dataset.operation = id;
        action.disabled = Boolean(item.claimed || snapshot.queue.busy);
      }
      nodes.push(row.node);
    });
    for (const [id, row] of queueRows)
      if (!ids.has(id)) preserveStatusFocus(row.node);
    syncChildren(queue, nodes);
    for (const id of queueRows.keys()) if (!ids.has(id)) queueRows.delete(id);
  }
  // Sidebar service list, like a list of conversations; the labelled select
  // in the toolbar stays the authoritative filter for assistive technology.
  function renderServiceNav() {
    const view = snapshot.library.view;
    serviceNav.setAttribute("aria-label", local("service"));
    serviceNav.hidden = view.services.length < 2 || accountsPage.hidden;
    const entries = [
      ["", local("all"), view.total],
      ...view.services.map((service) => [
        service.groupId,
        service.label,
        service.count,
      ]),
    ];
    const active = view.serviceFilter || "";
    const ids = new Set(entries.map(([id]) => id));
    for (const [id, row] of serviceNodes)
      if (!ids.has(id)) {
        if (row.node.contains(document.activeElement))
          serviceNodes.get("")?.node.focus({ preventScroll: true });
        serviceNodes.delete(id);
      }
    syncChildren(
      serviceNavList,
      entries.map(([id, label, total]) => {
        let row = serviceNodes.get(id);
        if (!row) {
          const node = button("", "service-nav", "ente-service-item", id);
          const name = el("span", "ente-service-item-name");
          const number = el("span", "ente-service-item-count");
          node.append(name, number);
          row = { node, name, number };
          serviceNodes.set(id, row);
        }
        if (row.name.textContent !== label) row.name.textContent = label;
        row.node.title = label;
        row.number.textContent = String(total ?? 0);
        row.node.setAttribute("aria-pressed", String(id === active));
        return row.node;
      }),
    );
    updateNavFade();
  }
  function renderChrome() {
    renderServiceNav();
    skip.textContent = local("skip");
    accountTitle.textContent = local("accounts");
    pageHeading.textContent =
      snapshot.library.view.services.find(
        (service) => service.groupId === snapshot.library.view.serviceFilter,
      )?.label || local("accounts");
    add.textContent = addMenu.hidden
      ? t("pageOpenActions", "Open actions")
      : t("close", "Close");
    for (const [id, { label }] of addItems)
      label.textContent = {
        "scan-import": t("fabScanQR", "Scan QR code"),
        "account-add": t("fabAddSecret", "Add manually"),
        import: t("fabImport", "Batch import"),
      }[id];
    scheme.textContent = t(
      snapshot.preferences.resolvedTheme === "dark"
        ? "themeLight"
        : "themeDark",
      snapshot.preferences.resolvedTheme === "dark" ? "Light" : "Dark",
    );
    more.textContent = local("manage");
    search.placeholder = t(
      "searchInputPlaceholder",
      "Search service or account",
    );
    search.setAttribute(
      "aria-label",
      t("searchInputAriaLabel", "Search accounts"),
    );
    clear.setAttribute("aria-label", t("searchClearAriaLabel", "Clear search"));
    const hasFilter = Boolean(
      snapshot.library.view.query || snapshot.library.view.serviceFilter,
    );
    if (document.activeElement !== search)
      search.value = snapshot.library.view.query;
    if (!hasFilter && document.activeElement === clear)
      search.focus({ preventScroll: true });
    clear.hidden = !hasFilter;
    const searchShown = searchVisible();
    surface.dataset.search = String(searchShown);
    searchToggle.setAttribute("aria-expanded", String(searchShown));
    searchToggle.setAttribute(
      "aria-label",
      t("searchInputAriaLabel", "Search accounts"),
    );
    searchToggle.title = searchToggle.getAttribute("aria-label");
    modes.title.textContent = t("viewModeLabel", "View");
    options(
      modes.select,
      [
        ["grouped", t("viewModeGrouped", "Grouped")],
        ["flat", t("viewModeFlat", "Flat")],
      ],
      snapshot.library.view.mode,
    );
    sorting.title.textContent = t(
      snapshot.library.view.mode === "flat"
        ? "sortModeFlatLabel"
        : "sortModeLabel",
      "Sort",
    );
    const sorts = [
      ["oldest-first", "sortOldestFirst", "Oldest first"],
      ["newest-first", "sortNewestFirst", "Newest first"],
      ["name-asc", "sortServiceNameAsc", "Service A–Z"],
      ["name-desc", "sortServiceNameDesc", "Service Z–A"],
      ["account-asc", "sortAccountNameAsc", "Account A–Z"],
      ["account-desc", "sortAccountNameDesc", "Account Z–A"],
    ];
    options(
      sorting.select,
      sorts
        .filter(
          ([key]) =>
            snapshot.library.view.mode === "flat" || !key.startsWith("name-"),
        )
        .map(([value, key, fallback]) => [value, t(key, fallback)]),
      snapshot.library.view.mode === "flat"
        ? snapshot.library.view.flatSort
        : snapshot.library.view.groupedItemSort,
    );
    groupSort.label.hidden = snapshot.library.view.mode !== "grouped";
    groupSort.title.textContent = t("groupSortLabel", "Group sort");
    options(
      groupSort.select,
      [
        ["name-asc", t("groupSortNameAsc", "Name A–Z")],
        ["name-desc", t("groupSortNameDesc", "Name Z–A")],
      ],
      snapshot.library.view.groupSort,
    );
    displayToggle.textContent = local("view");
    services.title.textContent = local("service");
    options(
      services.select,
      [
        ["", `${local("all")} (${snapshot.library.view.total})`],
        ...snapshot.library.view.services.map((service) => [
          service.groupId,
          `${service.label} (${service.count})`,
        ]),
      ],
      snapshot.library.view.serviceFilter || "",
    );
    services.select.title =
      services.select.selectedOptions[0]?.textContent || "";
    moreBack.textContent = local("back");
    moreTitle.textContent = local("manage");
    renderManagement();
  }
  function applyAppearance(next) {
    currentAppearance = next || {};
    const settings = currentAppearance.settings || {};
    surface.dataset.density =
      settings.density === "compact" ? "compact" : "comfortable";
    surface.dataset.nextCode = String(settings.showNextCode !== false);
  }
  function syncHostAppearance() {
    if (typeof sdk.host.setAppearance !== "function") return;
    const settings = currentAppearance.settings || {};
    const signature = JSON.stringify([
      snapshot.preferences.resolvedTheme === "dark",
    ]);
    if (signature === lastHostAppearance) return;
    lastHostAppearance = signature;
    sdk.host.setAppearance(
      hostAppearance(settings, snapshot.preferences.resolvedTheme === "dark"),
    );
  }
  function searchVisible() {
    return searchOpen || Boolean(snapshot.library.view.query);
  }
  function toggleSearch() {
    if (searchVisible()) {
      searchOpen = false;
      if (search.value || snapshot.library.view.query) {
        search.value = "";
        sdk.view.setQuery("");
      }
      render(snapshot);
      searchToggle.focus({ preventScroll: true });
    } else {
      searchOpen = true;
      render(snapshot);
      search.focus({ preventScroll: true });
    }
  }
  function closeDisplay(returnFocus = false) {
    if (displayPanel.hidden) return;
    displayPanel.hidden = true;
    displayToggle.setAttribute("aria-expanded", "false");
    if (returnFocus) displayToggle.focus();
  }
  function toggleDisplay() {
    if (!displayPanel.hidden) closeDisplay(true);
    else {
      closeMenu(false);
      displayPanel.hidden = false;
      displayToggle.setAttribute("aria-expanded", "true");
    }
  }
  function route(focus = false) {
    closeAddMenu(false);
    // Search and the service list sit in the sidebar but belong to the account page.
    const previousPage =
      [accountsPage, morePage].find((page) =>
        page.contains(document.activeElement),
      ) ||
      ([searchForm, serviceNav, headerTools].some((node) =>
        node.contains(document.activeElement),
      )
        ? accountsPage
        : null);
    if (focus || noticeRoute !== window.location.hash) {
      clearNotice();
      noticeRoute = window.location.hash;
    }
    const current =
      /^#\/theme\/ente\/(accounts|more|preferences)$/.exec(
        window.location.hash,
      )?.[1] || "accounts";
    if (current !== "accounts") closeDisplay(false);
    accountsPage.hidden = current !== "accounts";
    morePage.hidden = current === "accounts";
    more.setAttribute("aria-expanded", String(!morePage.hidden));
    searchForm.hidden = accountsPage.hidden;
    headerTools.hidden = accountsPage.hidden;
    renderServiceNav();
    // The old preferences address opens General, where the preferences are.
    if (current === "preferences") setManagementGroup("general");
    if (!snapshot.host.dialogOpen && (focus || previousPage?.hidden)) {
      const target =
        current === "accounts"
          ? focus || !searchVisible()
            ? accountsPage
            : search
          : moreTitle;
      target.focus({ preventScroll: true });
    }
  }
  function render(next) {
    if (!live) return;
    if (snapshot.epochs.session !== next.epochs.session) {
      closeMenu(false);
      closeDisplay(false);
      say("");
      cards.forEach((_, id) => cancelAnimation(id));
    }
    snapshot = next;
    lang = next.preferences.resolvedLanguage || "en";
    surface.lang = lang;
    surface.dataset.colorScheme =
      next.preferences.resolvedTheme === "dark" ? "dark" : "light";
    surface.dataset.reducedMotion = String(
      next.preferences.reducedMotion === true,
    );
    if (next.host.dialogOpen) {
      closeMenu(false);
      closeDisplay(false);
    }
    syncHostAppearance();
    renderChrome();
    renderAccounts();
    renderStates();
    renderOperations();
    renderQueue();
    renderAbout();
  }
  // The whole card copies its current code; its buttons and menu keep their own actions.
  function copyFromCard(event) {
    const node = event.target.closest?.("[data-account]");
    const card = node && cards.get(node.dataset.account);
    if (!live || !card || card.node !== node || !surface.contains(node)) return;
    if (card.menu?.contains(event.target)) return;
    if (event.target.closest("a, button, input, select, textarea, label"))
      return;
    if (String(window.getSelection?.() || "")) return;
    if (!card.copyButton.disabled) card.copyButton.click();
  }
  // The scan button can be dragged anywhere below the app bar, like the
  // default interface's button. Its place is remembered; without one it stays
  // in the bottom-right corner set by the stylesheet.
  const fabStorageKey = "2fa-theme:ente-for-2fa:fab-position";
  const fabMargin = 8;
  let fabDrag = null;
  let fabJustDragged = false;
  function clampFab(x, y) {
    const width = add.offsetWidth || 60;
    const height = add.offsetHeight || 60;
    const top = Math.max(
      fabMargin,
      header.getBoundingClientRect().bottom + fabMargin,
    );
    const maxX = Math.max(fabMargin, window.innerWidth - width - fabMargin);
    const maxY = Math.max(top, window.innerHeight - height - fabMargin);
    return {
      x: Math.round(Math.min(Math.max(x, fabMargin), maxX)),
      y: Math.round(Math.min(Math.max(y, top), maxY)),
    };
  }
  function placeFab(x, y) {
    const place = clampFab(x, y);
    add.style.left = place.x + "px";
    add.style.top = place.y + "px";
    add.style.right = "auto";
    add.style.bottom = "auto";
    return place;
  }
  function saveFab(place) {
    try {
      window.localStorage.setItem(fabStorageKey, JSON.stringify(place));
    } catch {
      // The position is a convenience; the button still works where it is.
    }
  }
  function restoreFab() {
    try {
      const saved = JSON.parse(window.localStorage.getItem(fabStorageKey));
      if (Number.isFinite(saved?.x) && Number.isFinite(saved?.y))
        placeFab(saved.x, saved.y);
    } catch {
      // A missing or unreadable position keeps the default corner.
    }
  }
  function onFabDown(event) {
    if (event.button !== 0 || add.disabled) return;
    const rect = add.getBoundingClientRect();
    fabDrag = {
      pointer: event.pointerId,
      x: event.clientX,
      y: event.clientY,
      left: rect.left,
      top: rect.top,
      moved: false,
    };
  }
  function onFabMove(event) {
    if (!fabDrag || event.pointerId !== fabDrag.pointer) return;
    const dx = event.clientX - fabDrag.x;
    const dy = event.clientY - fabDrag.y;
    if (!fabDrag.moved) {
      if (Math.hypot(dx, dy) < 5) return;
      fabDrag.moved = true;
      add.dataset.dragging = "true";
      closeAddMenu(false);
      try {
        add.setPointerCapture?.(event.pointerId);
      } catch {
        // Capture only keeps a fast drag on the button; moving works without it.
      }
    }
    event.preventDefault();
    fabDrag.place = placeFab(fabDrag.left + dx, fabDrag.top + dy);
  }
  function onFabUp(event) {
    if (!fabDrag || event.pointerId !== fabDrag.pointer) return;
    const { moved, place } = fabDrag;
    fabDrag = null;
    delete add.dataset.dragging;
    if (!moved) return;
    if (place) saveFab(place);
    // The click that ends a drag must not open the scanner.
    fabJustDragged = true;
    window.setTimeout(() => {
      fabJustDragged = false;
    }, 500);
  }
  function onFabResize() {
    if (!add.style.left) return;
    const rect = add.getBoundingClientRect();
    saveFab(placeFab(rect.left, rect.top));
    if (!addMenu.hidden) placeAddMenu();
  }
  // The ways in open away from the nearest screen edges, so the dragged
  // button may sit anywhere: above it in the lower half, labels on the side
  // with more room.
  function placeAddMenu() {
    const rect = add.getBoundingClientRect();
    const up = rect.top + rect.height / 2 > window.innerHeight / 2;
    const right = rect.left + rect.width / 2 > window.innerWidth / 2;
    const gap = 16;
    addMenu.dataset.vertical = up ? "up" : "down";
    addMenu.dataset.side = right ? "right" : "left";
    addMenu.style.setProperty(
      "--ente-add-y",
      Math.round(up ? window.innerHeight - rect.top + gap : rect.bottom + gap) +
        "px",
    );
    // Icons (52px) line up with the centre of the button.
    addMenu.style.setProperty(
      "--ente-add-x",
      Math.round(
        (right ? window.innerWidth - rect.right : rect.left) +
          (rect.width - 52) / 2,
      ) + "px",
    );
  }
  function openAddMenu(focus = false) {
    if (add.disabled) return;
    placeAddMenu();
    addMenu.hidden = false;
    addScrim.hidden = false;
    add.setAttribute("aria-expanded", "true");
    add.textContent = t("close", "Close");
    if (focus)
      [...addMenu.children]
        .find((item) => !item.hidden && !item.disabled)
        ?.focus();
  }
  function closeAddMenu(returnFocus = true) {
    if (addMenu.hidden) return;
    const focused = addMenu.contains(document.activeElement);
    addMenu.hidden = true;
    addScrim.hidden = true;
    add.setAttribute("aria-expanded", "false");
    add.textContent = t("pageOpenActions", "Open actions");
    if (returnFocus || focused) add.focus({ preventScroll: true });
  }
  function onClick(event) {
    if (fabJustDragged && add.contains(event.target)) {
      fabJustDragged = false;
      event.preventDefault();
      return;
    }
    const trigger = event.target.closest?.("[data-action]");
    if (!trigger) {
      copyFromCard(event);
      return;
    }
    if (!surface.contains(trigger) || trigger.disabled || !live) return;
    const action = trigger.dataset.action,
      value = trigger.dataset.value;
    const id = trigger.closest("[data-account]")?.dataset.account;
    if (action !== "menu" && !trigger.closest(".ente-menu-popover"))
      closeMenu(false);
    if (!disclosure.contains(trigger)) closeDisplay(false);
    if (action === "add-menu") {
      if (addMenu.hidden) openAddMenu(event.detail === 0);
      else closeAddMenu();
    } else if (addMenu.contains(trigger)) {
      // The dialog returns focus to the plus, which stays on screen.
      closeAddMenu(false);
      host(descriptorRequest(value), add);
    } else if (action === "management-group")
      setManagementGroup(activeManagementGroup === value ? null : value);
    else if (action === "display") toggleDisplay();
    else if (action === "search-toggle") toggleSearch();
    else if (action === "service-nav") {
      clearNotice();
      sdk.view.setServiceFilter(value || null);
    } else if (action === "host") host(descriptorRequest(value), trigger);
    else if (action === "queue")
      host({ kind: value, operationId: trigger.dataset.operation }, trigger);
    else if (["qr", "edit", "delete"].includes(action)) {
      const account = currentAccount(id);
      if (account)
        host(
          { kind: "account-" + action, account: account.ref },
          cards.get(id)?.trigger || trigger,
        );
    } else if (action === "uri" || action === "link") {
      const account = currentAccount(id);
      closeMenu();
      if (account)
        observe(
          action === "uri"
            ? sdk.accounts.copyURI(account.ref)
            : sdk.accounts.copyShareLink(account.ref),
          "copy",
        );
    } else if (action === "copy" || action === "next")
      copy(id, action === "next" ? "next" : "current");
    else if (action === "menu") openMenu(id);
    else if (action === "refresh") observe(sdk.accounts.refresh());
    else if (action === "clear") {
      clearNotice();
      search.value = "";
      sdk.view.setQuery("");
      sdk.view.setServiceFilter(null);
      search.focus();
    } else if (action === "scheme")
      observe(
        sdk.preferences.set({
          theme:
            snapshot.preferences.resolvedTheme === "dark" ? "light" : "dark",
        }),
        "scheme",
      );
    else if (action === "reconcile")
      observe(sdk.otp.reconcile(value), "reconcile", value);
    else if (action === "reload") observe(sdk.lifecycle.requestReload(value));
    else if (action === "route" || action === "skip") {
      // The menu button also closes the management page it opened.
      const page =
        action === "skip" || (trigger === more && !morePage.hidden)
          ? "accounts"
          : value;
      window.location.hash = "/theme/ente/" + page;
      route(true);
    }
  }
  // Right-click or long-press on a card opens its menu, as in the
  // authenticator app; links, fields and selected text keep the browser menu.
  function onContextMenu(event) {
    const node = event.target.closest?.("[data-account]");
    const card = node && cards.get(node.dataset.account);
    if (!live || !card || card.node !== node || snapshot.host.dialogOpen)
      return;
    if (event.target.closest("a, input, select, textarea")) return;
    if (String(window.getSelection?.() || "")) return;
    event.preventDefault();
    closeDisplay(false);
    if (menuId !== node.dataset.account) openMenu(node.dataset.account, true);
  }
  function onSearchSubmit(event) {
    event.preventDefault();
  }
  function onInput(event) {
    if (event.target !== search) return;
    // Erasing the query while typing keeps the search open.
    searchOpen = true;
    if (!event.isComposing) sdk.view.setQuery(search.value);
  }
  function onCompositionEnd(event) {
    if (event.target === search) sdk.view.setQuery(search.value);
  }
  function onChange(event) {
    const key = event.target.dataset.setting,
      value = event.target.value;
    if (key === "service") sdk.view.setServiceFilter(value || null);
    else if (key === "mode") sdk.view.setMode(value);
    else if (key === "sort")
      sdk.view.setSort({
        [snapshot.library.view.mode === "flat"
          ? "flatSort"
          : "groupedItemSort"]: value,
      });
    else if (key === "groupSort") sdk.view.setSort({ groupSort: value });
  }
  function onKey(event) {
    if (
      snapshot.host.dialogOpen ||
      event.isComposing ||
      event.altKey ||
      event.ctrlKey ||
      event.metaKey
    )
      return;
    const trigger = event.target;
    if (!addMenu.hidden && (trigger === add || addMenu.contains(trigger))) {
      if (event.key === "Escape") {
        event.preventDefault();
        closeAddMenu();
        return;
      }
      if (["ArrowUp", "ArrowDown"].includes(event.key)) {
        event.preventDefault();
        // The list is drawn bottom-up when it opens above the button.
        const items = [...addMenu.children].filter(
          (item) => !item.hidden && !item.disabled,
        );
        const step =
          (event.key === "ArrowDown" ? 1 : -1) *
          (addMenu.dataset.vertical === "up" ? -1 : 1);
        const at = items.indexOf(trigger);
        items[
          at < 0
            ? step > 0
              ? 0
              : items.length - 1
            : (at + step + items.length) % items.length
        ]?.focus();
        return;
      }
    }
    if (
      trigger.dataset.action === "management-group" &&
      ["Enter", " "].includes(event.key)
    ) {
      event.preventDefault();
      if (!event.repeat)
        setManagementGroup(
          activeManagementGroup === trigger.dataset.value
            ? null
            : trigger.dataset.value,
        );
      return;
    }
    if (event.key === "Escape" && trigger.closest(".ente-management-list")) {
      event.preventDefault();
      const key = activeManagementGroup;
      setManagementGroup(null);
      managementGroups.get(key)?.toggle.focus({ preventScroll: true });
      return;
    }
    if (trigger === displayToggle && ["Enter", " "].includes(event.key)) {
      event.preventDefault();
      if (!event.repeat) toggleDisplay();
      return;
    }
    if (event.key === "Escape" && !displayPanel.hidden) {
      event.preventDefault();
      closeDisplay(true);
      return;
    }
    if (event.key === "Escape" && trigger === search && searchVisible()) {
      event.preventDefault();
      toggleSearch();
      return;
    }
    if (event.key === "Escape" && menuId) {
      event.preventDefault();
      closeMenu();
      return;
    }
    if (
      trigger.dataset.action === "menu" &&
      ["ArrowDown", "ArrowUp"].includes(event.key)
    ) {
      event.preventDefault();
      openMenu(trigger.closest("[data-account]").dataset.account, true);
      return;
    }
    const menu = trigger.closest(".ente-menu-popover");
    if (menu && ["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)) {
      event.preventDefault();
      const items = [...menu.querySelectorAll("button:not(:disabled)")];
      const index = items.indexOf(trigger);
      const target =
        event.key === "Home"
          ? 0
          : event.key === "End"
            ? items.length - 1
            : (index + (event.key === "ArrowDown" ? 1 : -1) + items.length) %
              items.length;
      items[target]?.focus();
      return;
    }
    if (
      trigger.dataset.action !== "copy" ||
      ![
        "ArrowUp",
        "ArrowDown",
        "ArrowLeft",
        "ArrowRight",
        "Home",
        "End",
      ].includes(event.key)
    )
      return;
    const items = [
      ...accountList.querySelectorAll('[data-action="copy"]'),
    ].filter((item) => !item.disabled);
    if (!items.length) return;
    event.preventDefault();
    if (event.key === "Home" || event.key === "End") {
      items[event.key === "Home" ? 0 : items.length - 1].focus();
      return;
    }
    const current = trigger.getBoundingClientRect();
    const x = current.left + current.width / 2,
      y = current.top + current.height / 2;
    const horizontal = ["ArrowLeft", "ArrowRight"].includes(event.key);
    const sign = ["ArrowLeft", "ArrowUp"].includes(event.key) ? -1 : 1;
    const candidates = items
      .filter((item) => item !== trigger)
      .map((item) => {
        const rect = item.getBoundingClientRect();
        const dx = rect.left + rect.width / 2 - x,
          dy = rect.top + rect.height / 2 - y;
        return {
          item,
          forward: sign * (horizontal ? dx : dy),
          cross: Math.abs(horizontal ? dy : dx),
        };
      })
      .filter((item) => item.forward > 1)
      .sort((a, b) => a.cross * 4 + a.forward - (b.cross * 4 + b.forward));
    candidates[0]?.item.focus();
  }
  function outside(event) {
    if (!disclosure.contains(event.target))
      closeDisplay(displayPanel.contains(document.activeElement));
    if (menuId && !cards.get(menuId)?.node.contains(event.target))
      closeMenu(false);
    if (!addMenu.contains(event.target) && !add.contains(event.target))
      closeAddMenu(false);
  }
  function focusOutside(event) {
    if (!disclosure.contains(event.target)) closeDisplay(false);
    if (!addMenu.contains(event.target) && event.target !== add)
      closeAddMenu(false);
  }
  function hashChange() {
    route(false);
  }
  surface.addEventListener("click", onClick);
  surface.addEventListener("contextmenu", onContextMenu);
  add.addEventListener("pointerdown", onFabDown);
  add.addEventListener("pointermove", onFabMove);
  add.addEventListener("pointerup", onFabUp);
  add.addEventListener("pointercancel", onFabUp);
  window.addEventListener("resize", onFabResize);
  window.addEventListener("resize", onLayoutResize);
  serviceNav.addEventListener("wheel", onNavWheel, { passive: false });
  serviceNav.addEventListener("scroll", updateNavFade, { passive: true });
  searchForm.addEventListener("submit", onSearchSubmit);
  surface.addEventListener("input", onInput);
  surface.addEventListener("compositionend", onCompositionEnd);
  surface.addEventListener("change", onChange);
  surface.addEventListener("keydown", onKey);
  document.addEventListener("pointerdown", outside);
  document.addEventListener("focusin", focusOutside);
  window.addEventListener("hashchange", hashChange);
  applyAppearance(appearance);
  route();
  unsubscribe = sdk.subscribe(render);
  restoreFab();
  const timer = window.setInterval(renderTime, 250);
  function unmount() {
    if (!live) return;
    clearNotice();
    live = false;
    unsubscribe();
    window.clearInterval(timer);
    cards.forEach((_, id) => cancelAnimation(id));
    surface.removeEventListener("click", onClick);
    surface.removeEventListener("contextmenu", onContextMenu);
    add.removeEventListener("pointerdown", onFabDown);
    add.removeEventListener("pointermove", onFabMove);
    add.removeEventListener("pointerup", onFabUp);
    add.removeEventListener("pointercancel", onFabUp);
    window.removeEventListener("resize", onFabResize);
    window.removeEventListener("resize", onLayoutResize);
    serviceNav.removeEventListener("wheel", onNavWheel);
    serviceNav.removeEventListener("scroll", updateNavFade);
    searchForm.removeEventListener("submit", onSearchSubmit);
    surface.removeEventListener("input", onInput);
    surface.removeEventListener("compositionend", onCompositionEnd);
    surface.removeEventListener("change", onChange);
    surface.removeEventListener("keydown", onKey);
    document.removeEventListener("pointerdown", outside);
    document.removeEventListener("focusin", focusOutside);
    window.removeEventListener("hashchange", hashChange);
    signal?.removeEventListener("abort", unmount);
    surface.remove();
    cards.clear();
    groups.clear();
    stateNodes.clear();
    featureNodes.clear();
  }
  signal?.addEventListener("abort", unmount, { once: true });
  return {
    update(nextAppearance) {
      if (!live) return;
      applyAppearance(nextAppearance);
      render(snapshot);
    },
    unmount,
  };
}
