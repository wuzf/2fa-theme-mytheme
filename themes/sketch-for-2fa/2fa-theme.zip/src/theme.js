import { createHostAppearanceSync } from "./hostAppearance.js";
import { hostText, localText } from "./i18n.js";
import { managementGroups } from "./navigation.js";

/** Complete frontend. The host SDK remains the only account/OTP/command authority. */
export function mount({ root, sdk, appearance = {}, signal }) {
  if (!root || !sdk || signal?.aborted) return { update() {}, unmount() {} };
  const document = root.ownerDocument;
  const window = document.defaultView;
  let live = true;
  let snapshot = sdk.getSnapshot();
  let currentAppearance = appearance;
  let lang = snapshot.preferences.resolvedLanguage || "en";
  let menuId = null;
  let unsubscribe = () => {};
  let lastStructure = "";
  let lastChrome = "";
  let noticeTimer = null;
  let noticeGeneration = 0;
  let noticeSequence = 0;
  let renderedRoute = null;
  const cards = new Map();
  const groups = new Map();
  const featureButtons = new Map();
  const stateNodes = new Map();
  const operationRows = new Map();
  const queueRows = new Map();
  const animations = new Map();
  const local = (key) => localText(lang, key);
  const t = (key, fallback, params) => hostText(sdk, key, fallback, params);
  const el = (tag, className = "", text) => {
    const node = document.createElement(tag);
    node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };
  function button(text, action, className = "sketch-button", value) {
    const node = el("button", className, text);
    node.type = "button";
    node.dataset.action = action;
    if (value !== undefined) node.dataset.value = value;
    return node;
  }
  function labelSelect(key) {
    const label = el("label", "sketch-select-field");
    const title = el("span");
    const select = el("select", "sketch-input");
    select.dataset.setting = key;
    label.append(title, select);
    return { label, title, select };
  }
  function options(select, choices, value) {
    const signature = JSON.stringify(choices);
    if (select.dataset.options !== signature) {
      select.replaceChildren(
        ...choices.map(([id, label]) => {
          const option = el("option", "", label);
          option.value = id;
          return option;
        }),
      );
      select.dataset.options = signature;
    }
    select.value = value;
  }
  const surface = el("div", "sketch-theme");
  const hostAppearance = createHostAppearanceSync(sdk, surface);
  const skip = button("", "skip", "sketch-skip-link");
  const header = el("header", "sketch-topbar");
  const head = el("div", "sketch-topbar-inner");
  const brand = el("div", "sketch-brand");
  const mark = el("span", "sketch-brand-mark sketch-display", "2");
  mark.setAttribute("aria-hidden", "true");
  const identity = el("div");
  const brandName = el("h1", "sketch-brand-name sketch-display", "2FA");
  identity.append(brandName);
  brand.append(mark, identity);
  const headerActions = el("nav", "sketch-actions sketch-topbar-actions");
  const scheme = button("", "scheme");
  const more = button("", "route", "sketch-button", "more");
  headerActions.append(more);
  head.append(brand, headerActions);
  header.append(head);
  const main = el("main", "sketch-workspace");
  const notice = el("div", "sketch-notice");
  notice.setAttribute("role", "status");
  notice.setAttribute("aria-live", "polite");
  notice.setAttribute("aria-atomic", "true");
  notice.hidden = true;
  const states = el("section", "sketch-states");
  const operations = el("section", "sketch-operation-region");
  const operationsTitle = el("h2", "sketch-group-title");
  const queue = el("section", "sketch-queue-region");
  const queueTitle = el("h2", "sketch-group-title");
  const queueView = button("", "host", "sketch-button", "offline-queue");
  const queueLogin = button("", "host", "sketch-button", "login");
  const queueRetry = button(
    "",
    "host",
    "sketch-button",
    "offline-queue-status-retry",
  );
  const accountsPage = el("section", "sketch-account-page");
  accountsPage.tabIndex = -1;
  const count = el("span", "sketch-section-description");
  const toolbar = el("div", "sketch-toolbar");
  const searchForm = el("form", "sketch-search");
  searchForm.setAttribute("role", "search");
  searchForm.autocomplete = "off";
  const search = el("input");
  search.type = "search";
  search.name = "account-search";
  search.autocomplete = "off";
  search.setAttribute("autocapitalize", "none");
  search.setAttribute("autocorrect", "off");
  search.spellcheck = false;
  search.setAttribute("data-lpignore", "true");
  search.setAttribute("data-1p-ignore", "true");
  search.setAttribute("data-bwignore", "true");
  search.dataset.setting = "query";
  const clear = button("×", "clear", "sketch-button is-icon");
  searchForm.append(search, clear);
  const modes = labelSelect("mode");
  const sorting = labelSelect("sort");
  const groupSort = labelSelect("groupSort");
  const services = labelSelect("service");
  services.label.classList.add("sketch-service-filter");
  const view = el("div", "sketch-view-disclosure");
  const viewButton = button("", "view");
  const viewPanel = el("div", "sketch-view-panel");
  viewPanel.id = "sketch-view-" + Math.random().toString(36).slice(2);
  viewButton.setAttribute("aria-controls", viewPanel.id);
  viewButton.setAttribute("aria-expanded", "false");
  viewPanel.hidden = true;
  viewPanel.append(modes.label, sorting.label, groupSort.label);
  view.append(viewButton, viewPanel);
  toolbar.append(searchForm, services.label, view);
  const empty = el("div", "sketch-empty-state");
  const emptyTitle = el("h3");
  const emptyDescription = el("p");
  const emptyAction = button("", "refresh");
  empty.append(emptyTitle, emptyDescription, emptyAction);
  const accountList = el("div", "sketch-groups");
  const overview = el("div", "sketch-overview");
  const accountStatLabel = el("span");
  const accountStatValue = el("span");
  accountStatValue.dataset.stat = "accounts";
  const serviceStatLabel = el("span");
  const serviceStatValue = el("span");
  serviceStatValue.dataset.stat = "services";
  overview.append(
    accountStatLabel,
    accountStatValue,
    serviceStatLabel,
    serviceStatValue,
  );
  const summary = el("div", "sketch-list-summary");
  summary.append(count, overview);
  accountsPage.append(toolbar, summary, empty, accountList);
  const morePage = el("section", "sketch-subpage");
  morePage.tabIndex = -1;
  const moreBack = button("", "route", "sketch-button", "accounts");
  const moreTitle = el("h2", "sketch-section-title");
  const featureList = el("div", "sketch-management");
  const management = new Map(
    ["data", "tools", "settings", "app"].map((key) => {
      const section = el("section", "sketch-management-group");
      section.dataset.group = key;
      const title = el("h3");
      const toggle = button("", "management", "sketch-management-toggle", key);
      const list = el("div", "sketch-management-list");
      list.id = viewPanel.id + "-" + key;
      toggle.setAttribute("aria-controls", list.id);
      toggle.setAttribute("aria-expanded", String(key === "data"));
      list.hidden = key !== "data";
      title.append(toggle);
      section.append(title, list);
      featureList.append(section);
      return [key, { section, toggle, list }];
    }),
  );
  const moreHeading = el("div", "sketch-subpage-heading");
  moreHeading.append(moreBack, moreTitle);
  morePage.append(moreHeading, featureList);
  const preferencesPage = el("section", "sketch-subpage");
  preferencesPage.tabIndex = -1;
  const prefBack = button("", "route", "sketch-button", "accounts");
  const prefTitle = el("h2", "sketch-section-title");
  const hostPreferences = button("", "preferences", "sketch-button");
  const preferencesHeading = el("div", "sketch-subpage-heading");
  preferencesHeading.append(prefBack, prefTitle);
  preferencesPage.append(preferencesHeading, hostPreferences);
  const footer = el("footer", "sketch-footer");
  const credit = el("span", "", "Sketch · MIT");
  const license = el("a", "", "Licenses · MIT / Fonts · OFL");
  license.href = new URL("../licenses/NOTICE.txt", import.meta.url).href;
  // The 2FA version, a newer release and the project links, from the host.
  const about = el("div", "sketch-footer-about");
  const aboutVersion = el("span", "sketch-footer-version");
  const aboutUpdate = el("a", "sketch-footer-update");
  const aboutLinks = [
    ["documentation", "pageDocumentation", "Documentation"],
    ["extension", "pageBrowserExtension", "Browser extension"],
    ["feedback", "pageFeedback", "Report an issue"],
    ["source", "aboutSourceCode", "Source code"],
  ].map(([key, labelKey, fallback]) => ({
    key,
    labelKey,
    fallback,
    node:
      key === "extension"
        ? button("", "host", "sketch-footer-link", "extension")
        : el("a", "sketch-footer-link"),
  }));
  for (const link of [aboutUpdate, ...aboutLinks.map((item) => item.node)])
    if (link.tagName === "A") {
      link.target = "_blank";
      link.rel = "noopener noreferrer";
    }
  // On phones the links form their own two-column block under the version.
  const aboutLinkList = el("div", "sketch-footer-links");
  aboutLinkList.append(...aboutLinks.map((item) => item.node));
  about.append(aboutVersion, aboutUpdate, aboutLinkList);
  about.hidden = true;
  footer.append(credit, license, about);
  // The notice opens in the page: a new window would leave an installed PWA.
  const licensePanel = el("section", "sketch-license");
  licensePanel.id = "sketch-license-" + Math.random().toString(36).slice(2);
  licensePanel.hidden = true;
  const licenseHead = el("div", "sketch-license-head");
  const licenseTitle = el("h2", "sketch-license-title", license.textContent);
  licenseTitle.id = licensePanel.id + "-title";
  licenseTitle.tabIndex = -1;
  const licenseClose = button("", "license-close", "sketch-button");
  const licenseText = el("pre", "sketch-license-text");
  licenseHead.append(licenseTitle, licenseClose);
  licensePanel.append(licenseHead, licenseText);
  licensePanel.setAttribute("aria-labelledby", licenseTitle.id);
  license.setAttribute("aria-controls", licensePanel.id);
  license.setAttribute("aria-expanded", "false");
  let licenseState = "idle";
  main.append(
    notice,
    states,
    operations,
    queue,
    accountsPage,
    morePage,
    preferencesPage,
    footer,
    licensePanel,
  );
  surface.append(skip, header, main);
  root.append(surface);

  function closeView(restoreFocus = false) {
    viewPanel.hidden = true;
    viewButton.setAttribute("aria-expanded", "false");
    if (restoreFocus) viewButton.focus({ preventScroll: true });
  }
  function openManagement(key, focus = false) {
    for (const [id, group] of management) {
      const expanded = id === key;
      group.list.hidden = !expanded;
      group.toggle.setAttribute("aria-expanded", String(expanded));
    }
    if (focus) management.get(key)?.toggle.focus({ preventScroll: true });
  }

  function currentAccount(id) {
    return snapshot.library.accounts.find((account) => account.ref.id === id);
  }
  function clearNotice() {
    noticeGeneration++;
    noticeSequence++;
    if (noticeTimer !== null) window.clearTimeout(noticeTimer);
    noticeTimer = null;
    notice.textContent = "";
    notice.hidden = true;
  }
  function say(message, { kind = "info" } = {}) {
    if (!live) return;
    if (!message) return clearNotice();
    if (noticeTimer !== null) window.clearTimeout(noticeTimer);
    const sequence = ++noticeSequence;
    notice.dataset.kind = kind;
    notice.textContent = message;
    notice.hidden = false;
    noticeTimer = window.setTimeout(
      () => {
        if (!live || sequence !== noticeSequence) return;
        noticeTimer = null;
        notice.textContent = "";
        notice.hidden = true;
      },
      kind === "error" ? 8000 : 4000,
    );
  }
  function explain(reason) {
    if (reason === "authentication-required")
      return t("loginSubmitBtn", "Sign in");
    if (reason === "unavailable" || reason === "host-unavailable")
      return local("unavailable");
    const keys = {
      "write-busy-reclick": "coreHotpWriteBusy",
      offline: "coreHotpCopyOffline",
      "clipboard-failed": "copyFailed",
      "reservation-rejected": "coreHotpRejected",
      "operation-pending-account-changed": "coreHotpAccountChangedPending",
      "counter-limit": "coreHotpLimit",
      "reconciliation-failed": "coreHotpReconcileFailed",
    };
    if (keys[reason]) return t(keys[reason], local("failed"));
    return [
      "not-ready",
      "stale-target",
      "expired",
      "clock-changed",
      "account-changed",
    ].includes(reason)
      ? local("expired")
      : local("failed");
  }
  function observe(
    promise,
    kind = "command",
    operationId = null,
    copied = local("copied"),
  ) {
    const session = snapshot.epochs.session;
    const generation = noticeGeneration;
    const notify = (message, options) => {
      if (generation === noticeGeneration) say(message, options);
    };
    Promise.resolve(promise).then(
      (result) => {
        if (
          !live ||
          snapshot.epochs.session !== session ||
          ["mount-invalidated", "session-invalidated"].includes(result?.reason)
        )
          return;
        if (kind === "reconcile" && result?.status === "committed") {
          const operation = snapshot.host.operations?.find(
            (item) => item.operationId === operationId,
          );
          if (operation) {
            const facts = operationFacts(operation);
            notify(
              [facts.clipboard, facts.reservation, facts.attention]
                .filter(Boolean)
                .join(" · "),
              { kind: operationResolved(operation) ? "success" : "error" },
            );
          }
        } else if (result?.clipboard) {
          if (result.reservation && result.reservation !== "not-attempted") {
            renderOperations();
            const facts = operationFacts(result);
            notify(
              [facts.clipboard, facts.reservation, facts.attention]
                .filter(Boolean)
                .join(" · "),
              { kind: operationResolved(result) ? "success" : "error" },
            );
          } else {
            notify(
              result.clipboard === "copied" ? copied : explain(result.reason),
              { kind: result.clipboard === "copied" ? "success" : "error" },
            );
          }
        } else if (
          ["rejected", "unknown", "not-started"].includes(result?.status)
        )
          notify(explain(result.reason), { kind: "error" });
        else if (
          // The page itself shows a scheme change; a notice would only repeat it.
          !["host", "scheme"].includes(kind) &&
          ["committed", "loaded"].includes(result?.status)
        )
          notify(local("done"), { kind: "success" });
      },
      () => {
        if (live && snapshot.epochs.session === session)
          notify(local("failed"), { kind: "error" });
      },
    );
  }
  function operationResolved(operation) {
    // A confirmed reservation and a completed clipboard do not prove that the
    // local counter committed. Only a complete commit or a successful readback
    // can resolve that conflict, and a read cannot confirm an unknown POST.
    if (
      operation.status !== "settled" ||
      operation.clipboard !== "copied" ||
      operation.reservation !== "confirmed"
    )
      return false;
    if (
      operation.reason === "local-refresh-failed" &&
      operation.reconciliation !== "succeeded"
    )
      return false;
    return (
      (operation.localCommit === "committed" &&
        operation.recovery === "none" &&
        ["not-needed", "succeeded"].includes(operation.reconciliation)) ||
      (operation.reconciliation === "succeeded" &&
        operation.recovery === "reconciled")
    );
  }
  function operationFacts(operation) {
    const states = {
      pending: "coreHotpStatePending",
      confirmed: "coreHotpStateConfirmed",
      rejected: "coreHotpStateRejected",
      unknown: "coreHotpStateUnknown",
      copied: "coreHotpStateCopied",
      failed: "coreHotpStateFailed",
    };
    const clipboard = t(
      states[operation.clipboard] || "coreHotpStateUnknown",
      local("unknown"),
    );
    const reservation = t(
      states[operation.reservation] || "coreHotpStateUnknown",
      local("unknown"),
    );
    let attention = "";
    if (operation.reconciliation === "running") attention = local("waiting");
    else if (
      operation.reconciliation === "failed" ||
      operation.recovery === "retry-reconcile"
    )
      attention = t("coreHotpReconcileFailed", local("failed"));
    else if (
      operation.clipboard === "failed" &&
      operation.reservation === "confirmed"
    )
      attention = t("coreHotpCopyFailedAdvanced", local("failed"));
    else if (!operationResolved(operation))
      attention = t("coreHotpReconcile", local("waiting"));
    return {
      clipboard: t("coreHotpClipboardState", `Clipboard: ${clipboard}`, {
        state: clipboard,
      }),
      reservation: t(
        "coreHotpReservationState",
        `Reservation: ${reservation}`,
        { state: reservation },
      ),
      attention,
    };
  }
  function host(request, trigger) {
    closeMenu(false);
    const returnFocus =
      states.contains(trigger) || queue.contains(trigger) ? more : trigger;
    const handle = sdk.host.open(request, { returnFocus });
    if (handle.status === "rejected")
      say(explain(handle.reason), { kind: "error" });
    else observe(handle.closed, "host");
  }
  function descriptorRequest(value) {
    const found = sdk.host
      .listActions()
      .find((item) => item.actionId === value);
    return found?.request || { kind: value };
  }
  function closeMenu(restoreFocus = true) {
    const card = cards.get(menuId);
    if (card) {
      card.menu.hidden = true;
      card.node.dataset.menuOpen = "false";
      card.trigger.setAttribute("aria-expanded", "false");
      if (restoreFocus && card.trigger.isConnected) card.trigger.focus();
    }
    menuId = null;
  }
  function openMenu(id, focus = false) {
    if (menuId === id) {
      closeMenu();
      return;
    }
    closeMenu(false);
    const card = cards.get(id);
    if (!card) return;
    menuId = id;
    card.menu.hidden = false;
    card.node.dataset.menuOpen = "true";
    card.trigger.setAttribute("aria-expanded", "true");
    if (focus) card.menu.firstElementChild?.focus();
  }
  function cancelAnimation(id) {
    animations.get(id)?.cancel();
    animations.delete(id);
  }
  function copy(id, slot) {
    const target = sdk.otp.readCopyTarget(id, slot);
    if (target.status !== "ready") {
      say(explain(target.reason), { kind: "error" });
      return;
    }
    const card = cards.get(id);
    cancelAnimation(id);
    if (card)
      (slot === "next" ? card.nextValue : card.value).textContent =
        target.target.value;
    // Name the slot: the current and the next code are copied the same way.
    const account = currentAccount(id);
    const copied = t(
      slot === "next" ? "coreCopiedNextService" : "coreCopiedService",
      local("copied"),
      { name: account?.service.label || t("coreCode", "Code") },
    );
    // Same event stack: no await before the SDK starts the native clipboard.
    observe(sdk.otp.copy(target.target), "copy", null, copied);
  }
  function createCard(account) {
    const node = el("article", "sketch-card");
    node.dataset.account = account.ref.id;
    node.dataset.accountId = account.ref.id;
    // Each note keeps its own paper and strip of tape: shape, colour and
    // placement come from the account id, so they look random but never change
    // between renders.
    let seed = 2166136261;
    for (const char of account.ref.id)
      seed = Math.imul(seed ^ char.charCodeAt(0), 16777619) >>> 0;
    node.dataset.tape = String(seed % 6);
    node.dataset.tapeSpot = String((seed >>> 8) % 5);
    node.dataset.paper = String((seed >>> 16) % 6);
    const cardHeader = el("div", "sketch-card-header");
    const icon = el("span", "sketch-service-mark");
    icon.setAttribute("aria-hidden", "true");
    const names = el("div", "sketch-account-identity");
    const service = el("h3", "sketch-account-name");
    const accountLabel = el("p", "sketch-account-address");
    names.append(service, accountLabel);
    const menuHolder = el("div", "sketch-account-menu");
    const trigger = button("⋮", "menu", "sketch-button is-icon");
    trigger.setAttribute("aria-expanded", "false");
    const menu = el("div", "sketch-menu-popover sketch-menu");
    menu.hidden = true;
    const menuActions = ["qr", "uri", "link", "edit", "delete"].map((action) =>
      button(
        "",
        action,
        "sketch-menu-item" + (action === "delete" ? " is-danger" : ""),
      ),
    );
    menu.append(...menuActions);
    menuHolder.append(trigger, menu);
    cardHeader.append(icon, names, menuHolder);
    const codes = el("div", "sketch-codes");
    const codeLabel = el("div", "sketch-otp-label");
    const currentLabel = el("span", "sketch-current-label");
    const badge = el("span", "sketch-badge");
    codeLabel.append(currentLabel, badge);
    const copyButton = button("", "copy", "sketch-copy-code");
    const value = el("span", "sketch-otp-value");
    const copyIcon = el("span", "sketch-copy-symbol", "⧉");
    copyIcon.setAttribute("aria-hidden", "true");
    copyButton.append(value, copyIcon);
    const next = button("", "next", "sketch-otp-next");
    const nextValue = el("span", "sketch-next-value");
    next.append(nextValue);
    codes.append(codeLabel, copyButton, next);
    const timing = el("div", "sketch-expiry");
    const timingLabel = el("div", "sketch-expiry-label");
    const timingTitle = el("span");
    const remaining = el("strong");
    timingLabel.append(timingTitle, remaining);
    const progress = el("div", "sketch-progress");
    progress.setAttribute("aria-hidden", "true");
    const fill = el("span", "sketch-progress-fill");
    progress.append(fill);
    timing.append(timingLabel, progress);
    node.append(cardHeader, codes, timing);
    return {
      node,
      icon,
      service,
      accountLabel,
      trigger,
      menu,
      menuActions,
      currentLabel,
      codeLabel,
      badge,
      copyButton,
      value,
      next,
      nextValue,
      timing,
      timingTitle,
      remaining,
      progress,
      fill,
      account,
      previous: null,
    };
  }
  // Shows the service icon once it has loaded. The letter stays when there is
  // no icon or it cannot load (the editor preview does not allow it).
  function setServiceMark(
    node,
    account,
    letter = Array.from(account.service.label)[0] || "•",
  ) {
    const url = account.service.iconURL || "";
    if (node.dataset.letter === letter && node.dataset.icon === url) return;
    node.dataset.letter = letter;
    node.dataset.icon = url;
    node.classList.remove("has-icon");
    node.textContent = letter;
    if (!url) return;
    const image = node.ownerDocument.createElement("img");
    image.alt = "";
    image.decoding = "async";
    image.addEventListener(
      "load",
      () => {
        if (node.dataset.icon !== url) return;
        node.replaceChildren(image);
        node.classList.add("has-icon");
      },
      { once: true },
    );
    image.src = url;
  }
  function updateCard(card, account) {
    card.account = account;
    card.service.textContent = account.service.label;
    card.service.title = account.service.label;
    card.accountLabel.textContent = account.accountLabel;
    card.accountLabel.title = account.accountLabel;
    card.accountLabel.hidden = !account.accountLabel;
    setServiceMark(card.icon, account);
    card.trigger.setAttribute(
      "aria-label",
      t("cardMenuAriaLabel", local("more")) + " · " + account.service.label,
    );
    const labels = [
      ["cardMenuQRCode", "QR"],
      ["cardMenuCopyURI", "Copy URI"],
      ["cardMenuCopyLink", "Copy link"],
      ["cardMenuEdit", "Edit"],
      ["cardMenuDelete", "Delete"],
    ];
    card.menuActions.forEach((node, index) => {
      node.textContent = t(...labels[index]);
    });
    card.currentLabel.textContent = local("current");
    // Only counter-based accounts carry a badge; TOTP needs no metadata.
    card.badge.textContent = account.type === "HOTP" ? account.type : "";
    card.codeLabel.hidden = account.type !== "HOTP";
    // TOTP needs no type, period, digits or algorithm; HOTP names its counter.
    if (account.type === "HOTP")
      card.node.setAttribute(
        "aria-description",
        `${account.type}, ${t("counterLabel", "Counter")} ${account.counter}`,
      );
    else card.node.removeAttribute("aria-description");
    const value = account.otp.current?.value || "···";
    if (card.previous !== null && card.previous !== value) {
      cancelAnimation(account.ref.id);
      const effect = snapshot.preferences.otpAnimation;
      if (
        !snapshot.preferences.reducedMotion &&
        !window.matchMedia?.("(prefers-reduced-motion: reduce)").matches &&
        card.value.animate &&
        effect !== "none"
      ) {
        const frames =
          effect === "flip"
            ? [{ transform: "rotateX(75deg)" }, { transform: "rotateX(0)" }]
            : effect === "spotlight"
              ? [
                  { background: "var(--sketch-accent-soft)" },
                  { background: "transparent" },
                ]
              : [
                  { transform: "translateY(-5px)", opacity: 0.4 },
                  { transform: "translateY(0)", opacity: 1 },
                ];
        animations.set(
          account.ref.id,
          card.value.animate(frames, { duration: 180 }),
        );
      }
    }
    card.previous = value;
    card.value.textContent = value;
    card.value.dataset.digits = String(account.digits);
    card.copyButton.disabled =
      account.otp.current?.copyAvailability !== "ready";
    card.copyButton.title = card.copyButton.disabled
      ? account.otp.current?.copyAvailability === "offline"
        ? local("offline")
        : local("waiting")
      : t("copyOtpBtnTitle", "Copy code");
    card.copyButton.setAttribute(
      "aria-label",
      `${t("copyOtpBtnAriaLabel", "Copy current code")} · ${account.service.label} ${account.accountLabel}`,
    );
    card.next.hidden = account.type === "HOTP";
    card.next.disabled = account.otp.next?.copyAvailability !== "ready";
    card.nextValue.textContent = account.otp.next?.value || "···";
    card.next.setAttribute(
      "aria-label",
      `${t("copyNextOtpBtnTitle", "Copy next code")} · ${account.service.label}`,
    );
    card.next.title = t("copyNextOtpBtnTitle", "Copy next code");
    card.progress.hidden = account.type === "HOTP";
    card.timingTitle.textContent =
      account.type === "HOTP"
        ? t("counterLabel", "Counter")
        : `${account.period}${local("seconds")}`;
  }
  function renderTime() {
    if (!live) return;
    const now = sdk.clock?.now();
    for (const card of cards.values()) {
      const account = card.account;
      if (account.type === "HOTP") {
        card.remaining.textContent = String(account.counter);
        continue;
      }
      const current = account.otp.current;
      const seconds =
        typeof now === "number" && current
          ? Math.max(0, Math.ceil((current.validUntil - now) / 1000))
          : null;
      card.remaining.textContent =
        seconds === null ? local("waiting") : `${seconds}${local("seconds")}`;
      card.timing.dataset.expiring = String(seconds !== null && seconds <= 5);
      card.fill.style.setProperty(
        "--sketch-progress",
        `${seconds === null ? 0 : Math.min(100, (seconds / account.period) * 100)}%`,
      );
      if (seconds === 0) card.copyButton.disabled = true;
    }
  }
  function syncChildren(parent, nodes) {
    const focused = parent.contains(document.activeElement)
      ? document.activeElement
      : null;
    const keep = new Set(nodes);
    for (const child of [...parent.children])
      if (!keep.has(child)) child.remove();
    nodes.forEach((node, index) => {
      if (parent.children[index] !== node)
        parent.insertBefore(node, parent.children[index] || null);
    });
    while (parent.children.length > nodes.length)
      parent.lastElementChild.remove();
    if (focused?.isConnected && document.activeElement !== focused)
      focused.focus({ preventScroll: true });
  }
  function renderAccounts() {
    const view = snapshot.library.view;
    const ids = new Set(
      snapshot.library.accounts.map((account) => account.ref.id),
    );
    for (const [id, card] of cards)
      if (!ids.has(id)) {
        if (menuId === id) closeMenu(false);
        cancelAnimation(id);
        card.node.remove();
        cards.delete(id);
      }
    for (const account of snapshot.library.accounts) {
      let card = cards.get(account.ref.id);
      if (!card) {
        card = createCard(account);
        cards.set(account.ref.id, card);
      }
      if (
        card.account.ref.generation !== account.ref.generation &&
        menuId === account.ref.id
      )
        closeMenu(false);
      updateCard(card, account);
    }
    const sections =
      view.mode === "grouped" && view.groups.length
        ? view.groups
        : [{ groupId: "sketch-flat", label: "", ids: view.resultIds }];
    const structure = JSON.stringify([
      view.mode,
      sections.map((group) => [group.groupId, group.label, group.ids]),
    ]);
    if (structure !== lastStructure) {
      const liveGroups = new Set();
      const sectionsDOM = sections.map((group) => {
        liveGroups.add(group.groupId);
        let section = groups.get(group.groupId);
        if (!section) {
          section = {
            node: el("section", "sketch-group"),
            title: el("h3", "sketch-group-title"),
            list: el("div"),
          };
          section.node.append(section.title, section.list);
          groups.set(group.groupId, section);
        }
        section.title.textContent = group.label;
        section.title.hidden =
          !group.label || (sections.length === 1 && group.isOther);
        section.list.className = "sketch-account-grid";
        syncChildren(
          section.list,
          group.ids.map((id) => cards.get(id)?.node).filter(Boolean),
        );
        return section.node;
      });
      syncChildren(accountList, sectionsDOM);
      for (const id of groups.keys())
        if (!liveGroups.has(id)) groups.delete(id);
      lastStructure = structure;
    }
    if (menuId && !cards.get(menuId)?.node.isConnected) closeMenu(false);
    const countsKnown =
      snapshot.session.state === "authenticated" &&
      snapshot.library.state === "ready" &&
      Number.isFinite(view.total) &&
      Number.isFinite(view.found);
    count.textContent = countsKnown
      ? t("searchFoundCount", `${view.found} / ${view.total}`, {
          found: view.found,
          total: view.total,
        })
      : local("unknown");
    accountStatLabel.textContent = local("accounts");
    serviceStatLabel.textContent = local("services");
    accountStatValue.textContent = countsKnown ? String(view.total) : "—";
    serviceStatValue.textContent =
      countsKnown && Array.isArray(view.services)
        ? String(view.services.length)
        : "—";
    overview.dataset.countsKnown = String(countsKnown);
    const filtered = Boolean(view.query || view.serviceFilter);
    count.hidden = !filtered;
    overview.hidden =
      currentAppearance.settings?.showOverview === false || filtered;
    summary.hidden = count.hidden && overview.hidden;
    const signedOut = snapshot.session.state === "logged-out";
    empty.hidden =
      (Number.isFinite(view.found)
        ? view.found > 0
        : view.resultIds.length > 0) && !signedOut;
    accountList.hidden = signedOut;
    const loading =
      !["ready", "error"].includes(snapshot.library.state) ||
      (snapshot.library.state === "ready" && !countsKnown);
    const failure = snapshot.library.state === "error";
    emptyTitle.textContent = signedOut
      ? t("loginSubmitBtn", "Sign in")
      : loading
        ? t("loadingSecrets", local("waiting"))
        : failure
          ? local("failed")
          : filtered
            ? t("searchNoMatch", "No matching accounts")
            : t("emptyTitle", "No accounts yet");
    emptyDescription.textContent =
      signedOut || loading
        ? ""
        : filtered
          ? t("searchNoMatchDesc", "Try a different search")
          : t("emptyDesc", "Add an account to generate verification codes.");
    emptyAction.textContent = signedOut
      ? t("loginSubmitBtn", "Sign in")
      : failure || loading
        ? t("retry", "Retry")
        : filtered
          ? t("searchClearAriaLabel", "Clear search")
          : t("emptyAddBtn", "Add account");
    emptyAction.dataset.action = signedOut
      ? "host"
      : failure || loading
        ? "refresh"
        : filtered
          ? "clear"
          : "host";
    emptyAction.dataset.value = signedOut ? "login" : "account-add";
    renderTime();
  }
  function statePill(text, action, value) {
    return action
      ? button(text, action, "sketch-state sketch-button", value)
      : el("p", "sketch-state", text);
  }
  function renderStates() {
    const focused = document.activeElement;
    const ownedFocus = states.contains(focused);
    const children = [];
    if (sdk.identity.mode === "preview")
      children.push(statePill(local("preview")));
    if (snapshot.session.state !== "authenticated")
      children.push(statePill(t("loginSubmitBtn", "Sign in"), "host", "login"));
    if (snapshot.connectivity.onlineHint === false)
      children.push(statePill(local("offline")));
    // Cached accounts show first on every load; name them only once the refresh is over,
    // and not beside a failed refresh, which already says so and offers a retry.
    if (
      snapshot.library.source === "local" &&
      !["refreshing", "error"].includes(snapshot.library.refreshState)
    )
      children.push(statePill(local("local")));
    if (snapshot.library.refreshState === "error")
      children.push(statePill(local("failed"), "refresh"));
    if (
      // Only a clock that was never checked; a cached offset from an earlier check is fine.
      snapshot.clock.status === "local"
    )
      children.push(statePill(t("clockWarningText", local("clock"))));
    if (snapshot.library.hidden.count)
      children.push(
        statePill(
          `${t("pageHiddenAccounts", "Hidden accounts")} · ${snapshot.library.hidden.count}`,
          "host",
          "hidden-accounts",
        ),
      );
    if (snapshot.host.updateAvailable || snapshot.host.versionMismatch)
      children.push(statePill(t("pwaUpdateBtn", "Update"), "reload", "update"));
    if (snapshot.host.offlineReady === false)
      children.push(statePill(local("offlinePending")));
    const keys = new Set();
    const nodes = children.map((candidate) => {
      const key = candidate.dataset.action
        ? JSON.stringify([candidate.dataset.action, candidate.dataset.value])
        : "text:" + candidate.textContent;
      keys.add(key);
      if (!stateNodes.has(key)) stateNodes.set(key, candidate);
      else if (stateNodes.get(key).textContent !== candidate.textContent)
        stateNodes.get(key).textContent = candidate.textContent;
      return stateNodes.get(key);
    });
    if (
      ownedFocus &&
      !snapshot.host.dialogOpen &&
      !nodes.some((node) => node.contains(focused))
    )
      more.focus({ preventScroll: true });
    syncChildren(states, nodes);
    for (const key of stateNodes.keys())
      if (!keys.has(key)) stateNodes.delete(key);
    states.hidden = children.length === 0;
  }
  function renderOperations() {
    const records = (snapshot.host.operations || []).filter(
      (item) => item.type === "hotp" && !operationResolved(item),
    );
    operations.hidden = records.length === 0;
    operationsTitle.textContent = t(
      "coreHotpOperationTitle",
      "HOTP operation status",
    );
    const ids = new Set(records.map((operation) => operation.operationId));
    syncChildren(operations, [
      operationsTitle,
      ...records.map((operation) => {
        let row = operationRows.get(operation.operationId);
        if (!row) {
          row = {
            node: el("div", "sketch-operation"),
            name: el("strong"),
            clipboard: el("span"),
            reservation: el("span"),
            attention: el("span"),
            reconcile: button(
              "",
              "reconcile",
              "sketch-button",
              operation.operationId,
            ),
            recover: button("", "reload", "sketch-button", "recovery"),
          };
          row.node.append(
            row.name,
            row.clipboard,
            row.reservation,
            row.attention,
            row.reconcile,
            row.recover,
          );
          operationRows.set(operation.operationId, row);
        }
        const account = currentAccount(String(operation.accountId));
        row.name.textContent = account?.service.label || "HOTP";
        const facts = operationFacts(operation);
        row.clipboard.textContent = facts.clipboard;
        row.reservation.textContent = facts.reservation;
        row.attention.textContent = facts.attention;
        row.attention.hidden = !facts.attention;
        row.reconcile.textContent = t(
          "coreHotpReconcile",
          "Check counter state",
        );
        row.reconcile.disabled = operation.reconciliation === "running";
        row.recover.textContent = t(
          "coreHotpRecoveryReload",
          "Recover in safe mode",
        );
        row.recover.hidden = operation.recovery !== "reload-required";
        return row.node;
      }),
    ]);
    for (const id of operationRows.keys())
      if (!ids.has(id)) operationRows.delete(id);
  }
  function renderQueue() {
    const focused = document.activeElement;
    const ownedFocus = queue.contains(focused);
    const records = snapshot.queue.operations || [];
    queue.hidden =
      records.length === 0 &&
      !snapshot.queue.unavailable &&
      !snapshot.queue.authRequired;
    queueTitle.textContent = local("queue");
    queueView.textContent = t("offlineQueueView", "View pending changes");
    queueRetry.textContent = t("restoreRefresh", "Refresh");
    queueRetry.hidden = !snapshot.queue.unavailable;
    queueLogin.textContent = t("loginSubmitBtn", "Sign in");
    queueLogin.hidden = !snapshot.queue.authRequired;
    const nodes = [queueTitle, queueView, queueRetry, queueLogin];
    const ids = new Set();
    records.forEach((item) => {
      const id = item.operationId || item.id;
      ids.add(id);
      let row = queueRows.get(id);
      if (!row) {
        row = {
          node: el("div", "sketch-operation"),
          name: el("strong"),
          status: el("span"),
          actions: new Map(),
        };
        row.node.append(row.name, row.status);
        queueRows.set(id, row);
      }
      row.name.textContent = item.name || local("accounts");
      const status =
        item.status === "failed" || item.failureReason
          ? local("failed")
          : item.claimed || item.status === "sending"
            ? local("waiting")
            : local("queue");
      row.status.textContent = status;
      for (const [flag, kind, key, fallback] of [
        ["canEdit", "offline-queue-edit", "offlineQueueEditRetry", "Edit"],
        ["canRetry", "offline-queue-retry", "retry", "Retry"],
        [
          "canCancel",
          "offline-queue-cancel",
          "offlineQueueCancelChange",
          "Cancel",
        ],
      ]) {
        let action = row.actions.get(kind);
        if (!action) {
          action = button("", "queue", "sketch-button", kind);
          row.actions.set(kind, action);
          row.node.append(action);
        }
        action.textContent = t(key, fallback);
        action.hidden = !item[flag];
        action.dataset.operation = id;
        action.disabled = Boolean(item.claimed || snapshot.queue.busy);
      }
      nodes.push(row.node);
    });
    syncChildren(queue, nodes);
    for (const id of queueRows.keys()) if (!ids.has(id)) queueRows.delete(id);
    if (
      ownedFocus &&
      !snapshot.host.dialogOpen &&
      (queue.hidden || !focused.isConnected || focused.closest("[hidden]"))
    )
      more.focus({ preventScroll: true });
  }
  function renderChrome() {
    skip.textContent = local("skip");
    accountsPage.setAttribute("aria-label", local("accounts"));
    scheme.textContent = t(
      snapshot.preferences.resolvedTheme === "dark"
        ? "themeLight"
        : "themeDark",
      snapshot.preferences.resolvedTheme === "dark" ? "Light" : "Dark",
    );
    more.textContent = local("manage");
    viewButton.textContent = local("view");
    licenseClose.textContent = t("close", "Close");
    search.placeholder = t(
      "searchInputPlaceholder",
      "Search service or account",
    );
    search.setAttribute(
      "aria-label",
      t("searchInputAriaLabel", "Search accounts"),
    );
    clear.setAttribute("aria-label", t("searchClearAriaLabel", "Clear search"));
    if (document.activeElement !== search)
      search.value = snapshot.library.view.query;
    syncClear();
    modes.title.textContent = t("viewModeLabel", "View");
    options(
      modes.select,
      [
        ["grouped", t("viewModeGrouped", "Grouped")],
        ["flat", t("viewModeFlat", "Flat")],
      ],
      snapshot.library.view.mode,
    );
    sorting.title.textContent = t(
      snapshot.library.view.mode === "flat"
        ? "sortModeFlatLabel"
        : "sortModeLabel",
      "Sort",
    );
    const sorts = [
      ["oldest-first", "sortOldestFirst", "Oldest first"],
      ["newest-first", "sortNewestFirst", "Newest first"],
      ["name-asc", "sortServiceNameAsc", "Service A–Z"],
      ["name-desc", "sortServiceNameDesc", "Service Z–A"],
      ["account-asc", "sortAccountNameAsc", "Account A–Z"],
      ["account-desc", "sortAccountNameDesc", "Account Z–A"],
    ];
    options(
      sorting.select,
      sorts
        .filter(
          ([key]) =>
            snapshot.library.view.mode === "flat" || !key.startsWith("name-"),
        )
        .map(([value, key, fallback]) => [value, t(key, fallback)]),
      snapshot.library.view.mode === "flat"
        ? snapshot.library.view.flatSort
        : snapshot.library.view.groupedItemSort,
    );
    groupSort.label.hidden = snapshot.library.view.mode !== "grouped";
    groupSort.title.textContent = t("groupSortLabel", "Group sort");
    options(
      groupSort.select,
      [
        ["name-asc", t("groupSortNameAsc", "Name A–Z")],
        ["name-desc", t("groupSortNameDesc", "Name Z–A")],
      ],
      snapshot.library.view.groupSort,
    );
    services.title.textContent = local("services");
    options(
      services.select,
      [
        [
          "",
          local("all") +
            (snapshot.library.state === "ready" &&
            snapshot.session.state === "authenticated" &&
            Number.isFinite(snapshot.library.view.total)
              ? " (" + snapshot.library.view.total + ")"
              : ""),
        ],
        ...snapshot.library.view.services.map((service) => [
          service.groupId,
          service.label + " (" + service.count + ")",
        ]),
      ],
      snapshot.library.view.serviceFilter || "",
    );
    prefBack.textContent = moreBack.textContent = local("back");
    prefTitle.textContent = local("preferences");
    moreTitle.textContent = local("manage");
    hostPreferences.textContent = t(
      "settingsTabPreferences",
      local("preferences"),
    );
    const actions = sdk.host.listActions();
    const grouped = managementGroups(actions, snapshot);
    const signature = JSON.stringify([lang, grouped]);
    if (signature !== lastChrome) {
      const focused = document.activeElement;
      const focusedGroup = focused?.closest?.(".sketch-management-group");
      const alive = new Set();
      for (const [key, items] of Object.entries(grouped)) {
        const group = management.get(key);
        group.toggle.textContent = local(
          "manage" + key[0].toUpperCase() + key.slice(1),
        );
        const nodes = items.map((item) => {
          alive.add(item.actionId);
          let action = featureButtons.get(item.actionId);
          if (!action) {
            action = button(
              "",
              "host",
              "sketch-button sketch-feature",
              item.actionId,
            );
            featureButtons.set(item.actionId, action);
          }
          action.textContent =
            item.actionId === "appearance"
              ? local("appearance")
              : item.actionId === "quick-otp"
                ? t("quickOtpTitle", "Generate verification code")
                : t(item.labelKey, item.actionId);
          action.disabled = !item.enabled;
          if (!item.enabled)
            action.append(el("small", "sketch-muted", explain(item.reason)));
          return action;
        });
        // The colour scheme opens the settings, as in the other themes.
        if (key === "settings") nodes.unshift(scheme);
        syncChildren(group.list, nodes);
      }
      for (const [id, node] of featureButtons)
        if (!alive.has(id)) {
          node.remove();
          featureButtons.delete(id);
        }
      if (
        focusedGroup?.isConnected &&
        !snapshot.host.dialogOpen &&
        (!focused.isConnected || focused.closest("[hidden]"))
      )
        focusedGroup
          .querySelector(".sketch-management-toggle")
          .focus({ preventScroll: true });
      lastChrome = signature;
    }
  }
  function applyAppearance(next) {
    currentAppearance = next || {};
    const settings = currentAppearance.settings || {};
    surface.dataset.density =
      settings.density === "compact" ? "compact" : "comfortable";
    surface.dataset.accent = ["ballpoint", "redpencil", "greenink"].includes(
      settings.accent,
    )
      ? settings.accent
      : "ballpoint";
    surface.dataset.handwriting = String(settings.handwriting !== false);
    surface.dataset.paperPattern =
      settings.paperPattern === "plain" ? "plain" : "grid";
    overview.hidden = settings.showOverview === false;
  }
  function route(focus = false) {
    const previousPage = [accountsPage, morePage, preferencesPage].find(
      (page) => page.contains(document.activeElement),
    );
    closeView();
    const routeHash = window.location.hash;
    if (focus || renderedRoute !== routeHash) clearNotice();
    renderedRoute = routeHash;
    const current =
      /^#\/theme\/sketch\/(accounts|more|preferences)$/.exec(
        window.location.hash,
      )?.[1] || "accounts";
    accountsPage.hidden = current !== "accounts";
    morePage.hidden = current !== "more";
    more.setAttribute("aria-expanded", String(!morePage.hidden));
    preferencesPage.hidden = current !== "preferences";
    if (!snapshot.host.dialogOpen && (focus || previousPage?.hidden))
      ({
        accounts: focus ? accountsPage : search,
        more: moreBack,
        preferences: prefBack,
      })[current].focus({ preventScroll: true });
  }
  function render(next) {
    if (!live) return;
    if (snapshot.epochs.session !== next.epochs.session) {
      closeMenu(false);
      say("");
      cards.forEach((_, id) => cancelAnimation(id));
    }
    snapshot = next;
    lang = next.preferences.resolvedLanguage || "en";
    surface.lang = lang;
    surface.dataset.colorScheme =
      next.preferences.resolvedTheme === "dark" ? "dark" : "light";
    surface.dataset.reducedMotion = String(
      next.preferences.reducedMotion === true,
    );
    hostAppearance.update();
    if (next.host.dialogOpen) closeMenu(false);
    renderChrome();
    renderAccounts();
    renderStates();
    renderOperations();
    renderQueue();
    renderAbout();
  }
  // Hosts before host.about have no version to show; the row stays hidden.
  function renderAbout() {
    const info = snapshot.host.about;
    about.hidden = !info;
    if (!info) return;
    aboutVersion.textContent = `2FA v${info.version}`;
    aboutUpdate.hidden = !(info.latestVersion && info.links?.releases);
    if (!aboutUpdate.hidden) {
      aboutUpdate.href = info.links.releases;
      aboutUpdate.textContent = t(
        "versionUpdateAvailable",
        `New version available: v${info.latestVersion}`,
        { version: `v${info.latestVersion}` },
      );
    }
    const extension = sdk.host
      .listActions()
      .find((item) => item.actionId === "extension");
    for (const { key, labelKey, fallback, node } of aboutLinks) {
      node.textContent = t(labelKey, fallback);
      if (key === "extension") node.hidden = !extension?.enabled;
      else {
        node.hidden = !info.links?.[key];
        if (!node.hidden) node.href = info.links[key];
      }
    }
  }
  // The whole card copies its current code; its buttons and menu keep their own actions.
  function loadLicense() {
    licenseState = "loading";
    licenseText.textContent = local("waiting");
    Promise.resolve()
      .then(() => window.fetch(license.href))
      .then((response) => {
        if (!response.ok) throw new Error(String(response.status));
        return response.text();
      })
      .then(
        (text) => {
          if (!live) return;
          licenseState = "ready";
          licenseText.textContent = text;
          // The text makes the panel taller; centre it again so it stays clear of bottom bars.
          if (!licensePanel.hidden)
            licensePanel.scrollIntoView?.({ block: "center" });
        },
        () => {
          if (!live) return;
          // A later open tries again.
          licenseState = "idle";
          licenseText.textContent = local("failed");
        },
      );
  }
  function setLicense(open) {
    licensePanel.hidden = !open;
    license.setAttribute("aria-expanded", String(open));
    if (!open) {
      license.focus({ preventScroll: true });
      return;
    }
    if (licenseState === "idle") loadLicense();
    licenseTitle.focus({ preventScroll: true });
    // Centred, so fixed bottom bars and floating buttons cannot cover it.
    licensePanel.scrollIntoView?.({ block: "center" });
  }
  function onLicenseClick(event) {
    if (
      !live ||
      event.button !== 0 ||
      event.ctrlKey ||
      event.metaKey ||
      event.shiftKey ||
      event.altKey
    )
      return;
    event.preventDefault();
    setLicense(licensePanel.hidden);
  }
  function copyFromCard(event) {
    const node = event.target.closest?.("[data-account]");
    const card = node && cards.get(node.dataset.account);
    if (!live || !card || card.node !== node || !surface.contains(node)) return;
    if (card.menu?.contains(event.target)) return;
    if (event.target.closest("a, button, input, select, textarea, label"))
      return;
    if (String(window.getSelection?.() || "")) return;
    if (!card.copyButton.disabled) card.copyButton.click();
  }
  function onClick(event) {
    const trigger = event.target.closest?.("[data-action]");
    if (!trigger) {
      copyFromCard(event);
      return;
    }
    if (!surface.contains(trigger) || trigger.disabled || !live) return;
    const action = trigger.dataset.action,
      value = trigger.dataset.value;
    const id = trigger.closest("[data-account]")?.dataset.account;
    if (action !== "menu" && !trigger.closest(".sketch-menu-popover"))
      closeMenu(false);
    if (action === "license-close") setLicense(false);
    else if (action === "view") {
      const open = viewPanel.hidden;
      viewPanel.hidden = !open;
      viewButton.setAttribute("aria-expanded", String(open));
    } else if (action === "management") {
      openManagement(management.get(value).list.hidden ? value : null);
    } else if (action === "preferences") {
      window.location.hash = "/theme/sketch/more";
      route(false);
      openManagement("settings", true);
      featureButtons
        .get("settings:preferences")
        ?.focus({ preventScroll: true });
    } else if (action === "host") host(descriptorRequest(value), trigger);
    else if (action === "queue")
      host({ kind: value, operationId: trigger.dataset.operation }, trigger);
    else if (["qr", "edit", "delete"].includes(action)) {
      const account = currentAccount(id);
      if (account)
        host(
          { kind: "account-" + action, account: account.ref },
          cards.get(id)?.trigger || trigger,
        );
    } else if (action === "uri" || action === "link") {
      const account = currentAccount(id);
      closeMenu();
      if (account)
        observe(
          action === "uri"
            ? sdk.accounts.copyURI(account.ref)
            : sdk.accounts.copyShareLink(account.ref),
          "copy",
        );
    } else if (action === "copy" || action === "next")
      copy(id, action === "next" ? "next" : "current");
    else if (action === "menu") openMenu(id);
    else if (action === "refresh") observe(sdk.accounts.refresh());
    else if (action === "clear") {
      clearNotice();
      search.value = "";
      sdk.view.setQuery("");
      sdk.view.setServiceFilter(null);
      search.focus();
      syncClear();
    } else if (action === "filter") sdk.view.setServiceFilter(value || null);
    else if (action === "scheme")
      observe(
        sdk.preferences.set({
          theme:
            snapshot.preferences.resolvedTheme === "dark" ? "light" : "dark",
        }),
        "scheme",
      );
    else if (action === "reconcile")
      observe(sdk.otp.reconcile(value), "reconcile", value);
    else if (action === "reload") observe(sdk.lifecycle.requestReload(value));
    else if (action === "route" || action === "skip") {
      // The menu button also closes the management page it opened.
      const page =
        action === "skip" || (trigger === more && !morePage.hidden)
          ? "accounts"
          : value;
      window.location.hash = "/theme/sketch/" + page;
      route(true);
    }
  }
  function onSearchSubmit(event) {
    event.preventDefault();
  }
  // The clear action is shown only while the search has text to clear.
  function syncClear() {
    clear.hidden = !search.value;
  }
  function onInput(event) {
    if (event.target === search) syncClear();
    if (event.target === search && !event.isComposing)
      sdk.view.setQuery(search.value);
  }
  function onCompositionEnd(event) {
    if (event.target === search) sdk.view.setQuery(search.value);
  }
  function onChange(event) {
    const key = event.target.dataset.setting,
      value = event.target.value;
    if (key === "mode") sdk.view.setMode(value);
    else if (key === "sort")
      sdk.view.setSort({
        [snapshot.library.view.mode === "flat"
          ? "flatSort"
          : "groupedItemSort"]: value,
      });
    else if (key === "groupSort") sdk.view.setSort({ groupSort: value });
    else if (key === "service") sdk.view.setServiceFilter(value || null);
  }
  function onKey(event) {
    if (
      snapshot.host.dialogOpen ||
      event.isComposing ||
      event.altKey ||
      event.ctrlKey ||
      event.metaKey
    )
      return;
    const trigger = event.target;
    if (event.key === "Escape" && licensePanel.contains(trigger)) {
      event.preventDefault();
      setLicense(false);
      return;
    }
    if (event.key === "Escape" && !viewPanel.hidden) {
      event.preventDefault();
      closeView(true);
      return;
    }
    const group = trigger.closest(".sketch-management-group");
    if (
      event.key === "Escape" &&
      group &&
      !management.get(group.dataset.group).list.hidden
    ) {
      event.preventDefault();
      openManagement(null);
      management.get(group.dataset.group).toggle.focus({ preventScroll: true });
      return;
    }
    if (event.key === "Escape" && menuId) {
      event.preventDefault();
      closeMenu();
      return;
    }
    if (
      trigger.dataset.action === "menu" &&
      ["ArrowDown", "ArrowUp"].includes(event.key)
    ) {
      event.preventDefault();
      openMenu(trigger.closest("[data-account]").dataset.account, true);
      return;
    }
    const menu = trigger.closest(".sketch-menu-popover");
    if (menu && ["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)) {
      event.preventDefault();
      const items = [...menu.querySelectorAll("button:not(:disabled)")];
      const index = items.indexOf(trigger);
      const target =
        event.key === "Home"
          ? 0
          : event.key === "End"
            ? items.length - 1
            : (index + (event.key === "ArrowDown" ? 1 : -1) + items.length) %
              items.length;
      items[target]?.focus();
      return;
    }
    if (
      trigger.dataset.action !== "copy" ||
      ![
        "ArrowUp",
        "ArrowDown",
        "ArrowLeft",
        "ArrowRight",
        "Home",
        "End",
      ].includes(event.key)
    )
      return;
    const items = [
      ...accountList.querySelectorAll('[data-action="copy"]'),
    ].filter((item) => !item.disabled);
    if (!items.length) return;
    event.preventDefault();
    if (event.key === "Home" || event.key === "End") {
      items[event.key === "Home" ? 0 : items.length - 1].focus();
      return;
    }
    const current = trigger.getBoundingClientRect();
    const x = current.left + current.width / 2,
      y = current.top + current.height / 2;
    const horizontal = ["ArrowLeft", "ArrowRight"].includes(event.key);
    const sign = ["ArrowLeft", "ArrowUp"].includes(event.key) ? -1 : 1;
    const candidates = items
      .filter((item) => item !== trigger)
      .map((item) => {
        const rect = item.getBoundingClientRect();
        const dx = rect.left + rect.width / 2 - x,
          dy = rect.top + rect.height / 2 - y;
        return {
          item,
          forward: sign * (horizontal ? dx : dy),
          cross: Math.abs(horizontal ? dy : dx),
        };
      })
      .filter((item) => item.forward > 1)
      .sort((a, b) => a.cross * 4 + a.forward - (b.cross * 4 + b.forward));
    candidates[0]?.item.focus();
  }
  function outside(event) {
    if (!view.contains(event.target)) closeView();
    if (menuId && !cards.get(menuId)?.node.contains(event.target))
      closeMenu(false);
  }
  function focusOutside(event) {
    if (!view.contains(event.target)) closeView();
  }
  function hashChange() {
    route(false);
  }
  surface.addEventListener("click", onClick);
  license.addEventListener("click", onLicenseClick);
  searchForm.addEventListener("submit", onSearchSubmit);
  surface.addEventListener("input", onInput);
  surface.addEventListener("compositionend", onCompositionEnd);
  surface.addEventListener("change", onChange);
  surface.addEventListener("keydown", onKey);
  document.addEventListener("pointerdown", outside);
  document.addEventListener("focusin", focusOutside);
  window.addEventListener("hashchange", hashChange);
  applyAppearance(appearance);
  route();
  unsubscribe = sdk.subscribe(render);
  const timer = window.setInterval(renderTime, 250);
  function unmount() {
    if (!live) return;
    live = false;
    clearNotice();
    unsubscribe();
    hostAppearance.clear();
    window.clearInterval(timer);
    cards.forEach((_, id) => cancelAnimation(id));
    surface.removeEventListener("click", onClick);
    license.removeEventListener("click", onLicenseClick);
    searchForm.removeEventListener("submit", onSearchSubmit);
    surface.removeEventListener("input", onInput);
    surface.removeEventListener("compositionend", onCompositionEnd);
    surface.removeEventListener("change", onChange);
    surface.removeEventListener("keydown", onKey);
    document.removeEventListener("pointerdown", outside);
    document.removeEventListener("focusin", focusOutside);
    window.removeEventListener("hashchange", hashChange);
    signal?.removeEventListener("abort", unmount);
    surface.remove();
    cards.clear();
    groups.clear();
  }
  signal?.addEventListener("abort", unmount, { once: true });
  return {
    update(nextAppearance) {
      if (!live) return;
      applyAppearance(nextAppearance);
      render(snapshot);
    },
    unmount,
  };
}
