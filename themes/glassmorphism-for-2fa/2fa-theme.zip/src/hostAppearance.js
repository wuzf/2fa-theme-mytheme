/** The host uses opaque surfaces for dialogs and public pages. */
export function hostAppearance(settings = {}, dark = false) {
  const palette = ["lagoon", "lavender", "rose"].includes(settings.palette)
    ? settings.palette
    : "lagoon";
  const accents = {
    lagoon: dark
      ? ["#99dbf6", "#bfeaff", "#2b4c60"]
      : ["#176b9b", "#12597f", "#d8eff3"],
    lavender: dark
      ? ["#d2bfff", "#e4d7ff", "#433d63"]
      : ["#6950a2", "#553d8b", "#ede4fa"],
    rose: dark
      ? ["#ffc0d7", "#ffdaea", "#5c3a50"]
      : ["#a0426a", "#883356", "#f8e2ea"],
  };
  const [accent, accentHover, selected] = accents[palette];
  return {
    surface: dark ? "#1d3046" : "#f7fbff",
    subtle: dark ? "#16273b" : "#edf4f9",
    hover: dark ? "#2a425b" : "#e5eff7",
    text: dark ? "#eef5ff" : "#17324d",
    muted: dark ? "#b3c5d7" : "#51677c",
    line: dark ? "#465c74" : "#c8d8e6",
    stroke: dark ? "#809bb5" : "#627f98",
    accent,
    accentHover,
    accentText: dark ? "#122b3e" : "#ffffff",
    selected,
    danger: dark ? "#ffa7bb" : "#b33149",
    dangerBackground: dark ? "#492c40" : "#ffedf0",
    dangerFill: dark ? "#ffa7bb" : "#b33149",
    dangerFillHover: dark ? "#ffc7d4" : "#97263b",
    dangerText: dark ? "#122b3e" : "#ffffff",
    warning: dark ? "#f2cf8c" : "#8a5a13",
    warningBackground: dark ? "#413923" : "#fff1d9",
    success: dark ? "#90dec6" : "#24705c",
    successBackground: dark ? "#214a43" : "#e0f3ec",
    radius: 20,
    controlRadius: 12,
    borderWidth: 1,
    shadow: {
      x: 0,
      y: 8,
      blur: 48,
      spread: 0,
      color: dark ? "#06111d40" : "#28517530",
    },
    controlShadow: { x: 0, y: 2, blur: 6, spread: 0, color: "#28517512" },
    fontFamily: [
      "Segoe UI Variable",
      "Segoe UI",
      "PingFang SC",
      "Microsoft YaHei",
      "sans-serif",
    ],
  };
}
