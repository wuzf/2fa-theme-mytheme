/** The management menu, laid out like a Start menu: pinned entries, the
    programs, the control panel, then a bottom bar for the extension,
    installing and the session. */
export const toolIds = [
  "tool:qr-decode",
  "tool:qr-generate",
  "tool:base32",
  "tool:timestamp",
  "tool:key-check",
  "tool:key-generate",
];
export const providerIds = [
  "sync-provider:webdav",
  "sync-provider:s3",
  "sync-provider:onedrive",
  "sync-provider:gdrive",
];
/** Each section's entries in menu order. "*" marks where an action the theme
    does not know yet goes, so a new host action is never lost: like "All
    Programs", the programs take anything else. About follows the theme
    settings and signing out closes the bar. "scheme" is the theme's own
    light/dark switch. "application" is the bottom bar. */
export const groupOrder = {
  data: ["scan-import", "account-add"],
  tools: ["import", "export", "backup", "tools", ...toolIds, "quick-otp", "*"],
  settings: [
    "scheme",
    "settings:security",
    "settings:sync",
    ...providerIds,
    "settings:preferences",
    "settings:custom-code",
    "*",
    "appearance",
    "settings:about",
  ],
  application: ["extension", "pwa-install", "login", "logout"],
};
/** An unknown action joins the section its family belongs to, else the
    programs: the bottom bar keeps its fixed shape. */
export function groupOf(actionId) {
  for (const [group, ids] of Object.entries(groupOrder))
    if (ids.includes(actionId)) return group;
  if (/^(settings|sync-provider):/.test(actionId)) return "settings";
  return "tools";
}
export function menuRank(group, actionId) {
  const ids = groupOrder[group];
  const index = ids.indexOf(actionId);
  return index < 0 ? ids.indexOf("*") : index;
}
