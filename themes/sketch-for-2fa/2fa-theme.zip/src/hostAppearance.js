// Host accents also color text: dialogs use the dark pen ink on light paper
// and the pale ink on dark paper. No layout queries run on OTP publications.
const palettes = {
  light: {
    panel: "#ffffff",
    canvas: "#f3f6f9",
    ink: "#252a31",
    muted: "#55606d",
    track: "#e6edf3",
    line: "#cfdbe6",
    shade: "#c3d0de",
    red: "#b02a22",
    rose: "#f6dcda",
    amber: "#7d5300",
    sticky: "#fbe68c",
    green: "#2a6b4c",
    mint: "#d5ebdf",
    onAccent: "#ffffff",
    accents: {
      ballpoint: ["#2447a6", "#e2e9fa"],
      redpencil: ["#a3302a", "#f8e2df"],
      greenink: ["#23664a", "#ddefe6"],
    },
  },
  dark: {
    panel: "#22272e",
    canvas: "#191d22",
    ink: "#e4e9ef",
    muted: "#a8b2be",
    track: "#2b3139",
    line: "#343c47",
    shade: "#3b4552",
    red: "#ff978c",
    rose: "#4b2b2c",
    amber: "#f2c45c",
    sticky: "#5b5023",
    green: "#8fd4b2",
    mint: "#233d31",
    onAccent: "#10141b",
    accents: {
      ballpoint: ["#b6caff", "#263352"],
      redpencil: ["#ffbcb5", "#4a2a29"],
      greenink: ["#a6e0c5", "#213d31"],
    },
  },
};
const systemFonts = [
  "ui-sans-serif",
  "system-ui",
  "-apple-system",
  "PingFang SC",
  "Microsoft YaHei",
  "sans-serif",
];

export function hostAppearanceTokens(
  colorScheme = "light",
  accentName = "ballpoint",
  handwriting = true,
) {
  const colors = palettes[colorScheme === "dark" ? "dark" : "light"];
  const [accent, selected] =
    colors.accents[accentName] || colors.accents.ballpoint;
  return {
    surface: colors.panel,
    subtle: colors.canvas,
    hover: colors.track,
    text: colors.ink,
    muted: colors.muted,
    line: colors.line,
    stroke: colors.ink,
    accent,
    accentHover: accent,
    accentText: colors.onAccent,
    selected,
    danger: colors.red,
    dangerBackground: colors.rose,
    dangerFill: colors.red,
    dangerFillHover: colors.red,
    dangerText: colors.panel,
    warning: colors.amber,
    warningBackground: colors.sticky,
    success: colors.green,
    successBackground: colors.mint,
    radius: 10,
    controlRadius: 7,
    borderWidth: 2,
    shadow: { x: 3, y: 4, blur: 0, spread: 0, color: colors.shade },
    controlShadow: { x: 0, y: 2, blur: 0, spread: 0, color: colors.shade },
    fontFamily: !handwriting
      ? [...systemFonts]
      : ["sketch-shantell", "sketch-kai", ...systemFonts],
  };
}

export function createHostAppearanceSync(sdk, surface) {
  let signature = "";
  return {
    update() {
      if (typeof sdk.host?.setAppearance !== "function") return;
      const {
        colorScheme,
        accent: selectedAccent,
        handwriting,
      } = surface.dataset;
      const nextSignature = JSON.stringify([
        colorScheme,
        selectedAccent,
        handwriting,
      ]);
      if (nextSignature === signature) return;
      signature = nextSignature;
      sdk.host.setAppearance(
        hostAppearanceTokens(
          colorScheme,
          selectedAccent,
          handwriting !== "false",
        ),
      );
    },
    clear() {
      if (!signature) return;
      signature = "";
      if (typeof sdk.host?.setAppearance === "function")
        sdk.host.setAppearance(null);
    },
  };
}
