import { createHostAppearanceSync } from "./hostAppearance.js";
import { chapterNumber, hostText, localText } from "./i18n.js";
import { managementActions } from "./navigation.js";

/** Complete frontend. The host SDK remains the only account/OTP/command authority. */
export function mount({ root, sdk, appearance = {}, signal }) {
  if (!root || !sdk || signal?.aborted) return { update() {}, unmount() {} };
  const document = root.ownerDocument;
  const window = document.defaultView;
  let live = true;
  let snapshot = sdk.getSnapshot();
  let currentAppearance = appearance;
  let lang = snapshot.preferences.resolvedLanguage || "en";
  let menuId = null;
  let unsubscribe = () => {};
  let lastStructure = "";
  let noticeTimer = null;
  let noticeGeneration = 0;
  let noticeSequence = 0;
  let renderedRoute = null;
  const cards = new Map();
  const groups = new Map();
  const stateNodes = new Map();
  const actionNodes = new Map();
  const operationRows = new Map();
  const queueRows = new Map();
  const animations = new Map();
  const local = (key) => localText(lang, key);
  const t = (key, fallback, params) => hostText(sdk, key, fallback, params);
  const el = (tag, className = "", text) => {
    const node = document.createElement(tag);
    node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };
  function button(text, action, className = "journal-button", value) {
    const node = el("button", className, text);
    node.type = "button";
    node.dataset.action = action;
    if (value !== undefined) node.dataset.value = value;
    return node;
  }
  function labelSelect(key) {
    const label = el("label", "journal-select-field");
    const title = el("span");
    const select = el("select", "journal-input");
    select.dataset.setting = key;
    label.append(title, select);
    return { label, title, select };
  }
  function options(select, choices, value) {
    const signature = JSON.stringify(choices);
    if (select.dataset.options !== signature) {
      select.replaceChildren(
        ...choices.map(([id, label]) => {
          const option = el("option", "", label);
          option.value = id;
          return option;
        }),
      );
      select.dataset.options = signature;
    }
    select.value = value;
  }
  const surface = el("div", "journal-theme");
  const hostAppearance = createHostAppearanceSync(sdk, surface);
  const workbook = el("div", "journal-workbook");
  const skip = button("", "skip", "journal-skip-link");
  const header = el("header", "journal-topbar");
  const head = el("div", "journal-topbar-inner");
  const brand = el("div", "journal-brand");
  const mark = el("span", "journal-brand-mark journal-display", "2");
  mark.setAttribute("aria-hidden", "true");
  const identity = el("div");
  const brandName = el("h1", "journal-brand-name journal-display", "2FA");
  identity.append(brandName);
  brand.append(mark, identity);
  const headerActions = el("nav", "journal-actions journal-topbar-actions");
  const scheme = button("", "scheme");
  const more = button("", "route", "journal-button", "more");
  headerActions.append(more);
  head.append(brand, headerActions);
  header.append(head);
  const main = el("main", "journal-workspace");
  const notice = el("div", "journal-notice");
  notice.setAttribute("role", "status");
  notice.setAttribute("aria-live", "polite");
  notice.setAttribute("aria-atomic", "true");
  notice.hidden = true;
  const states = el("section", "journal-states");
  const operations = el("section", "journal-operation-region");
  const operationsTitle = el("h2", "journal-group-title");
  const queue = el("section", "journal-queue-region");
  const queueTitle = el("h2", "journal-group-title");
  const queueView = button("", "host", "journal-button", "offline-queue");
  const queueRetry = button(
    "",
    "host",
    "journal-button",
    "offline-queue-status-retry",
  );
  const accountsPage = el("section", "journal-account-page");
  const overview = el("section", "journal-overview");
  const summary = el("div", "journal-tallies");
  const accountNote = el("div", "journal-tally journal-tally-accounts");
  const overviewAccountsLabel = el("p");
  const overviewAccounts = el("strong", "journal-overview-count");
  const overviewCaption = el("p", "journal-overview-caption");
  accountNote.append(overviewAccountsLabel, overviewAccounts, overviewCaption);
  const serviceNote = el("div", "journal-tally journal-tally-services");
  const overviewServicesLabel = el("p");
  const overviewServices = el("strong", "journal-overview-count");
  serviceNote.append(overviewServicesLabel, overviewServices);
  summary.append(accountNote, serviceNote);
  overview.append(summary);
  accountsPage.tabIndex = -1;
  const heading = el("div", "journal-section-heading");
  const accountTitle = el("h2", "journal-section-title");
  const count = el("span", "journal-section-description");
  heading.append(accountTitle, count, overview);
  const toolbar = el("div", "journal-toolbar");
  const searchForm = el("form", "journal-search");
  searchForm.setAttribute("role", "search");
  searchForm.autocomplete = "off";
  const search = el("input");
  search.type = "search";
  search.name = "account-search";
  search.autocomplete = "off";
  search.setAttribute("autocapitalize", "none");
  search.setAttribute("autocorrect", "off");
  search.spellcheck = false;
  search.setAttribute("data-lpignore", "true");
  search.setAttribute("data-1p-ignore", "true");
  search.setAttribute("data-bwignore", "true");
  search.dataset.setting = "query";
  const clear = button("×", "clear", "journal-button is-icon");
  searchForm.append(search, clear);
  const modes = labelSelect("mode");
  const sorting = labelSelect("sort");
  const groupSort = labelSelect("groupSort");
  const viewOptions = el("details", "journal-view-options");
  const viewSummary = el("summary", "journal-options-summary");
  const viewFields = el("div", "journal-toolbar-fields");
  viewFields.append(modes.label, sorting.label, groupSort.label);
  viewOptions.append(viewSummary, viewFields);
  const services = labelSelect("service");
  services.label.classList.add("journal-services");
  const viewId = "journal-view-" + window.crypto.randomUUID();
  viewFields.id = viewId;
  viewSummary.setAttribute("aria-controls", viewId);
  viewSummary.setAttribute("aria-expanded", "false");
  toolbar.append(searchForm, services.label, viewOptions);
  function closeView(restoreFocus = false) {
    viewOptions.open = false;
    viewSummary.setAttribute("aria-expanded", "false");
    if (restoreFocus) viewSummary.focus({ preventScroll: true });
  }
  function viewToggled() {
    viewSummary.setAttribute("aria-expanded", String(viewOptions.open));
  }
  viewOptions.addEventListener("toggle", viewToggled);
  const indexNav = el("nav", "journal-index");
  const indexTitle = el("h2", "journal-index-title");
  const indexList = el("ul", "journal-index-list");
  indexNav.append(indexTitle, indexList);
  const indexAll = button("", "filter", "journal-index-tab", "");
  const indexTabs = new Map();
  const indexItem = (node) => {
    const item = el("li");
    item.append(node);
    return item;
  };
  const indexAllItem = indexItem(indexAll);
  const empty = el("div", "journal-empty-state");
  const emptyTitle = el("h3");
  const emptyDescription = el("p");
  const emptyAction = button("", "refresh");
  empty.append(emptyTitle, emptyDescription, emptyAction);
  const accountList = el("div", "journal-groups");
  const leftPage = el("div", "journal-page journal-page-index");
  leftPage.append(heading, toolbar, indexNav);
  const rightPage = el("div", "journal-page journal-page-entries");
  rightPage.append(empty, accountList);
  accountsPage.append(leftPage, rightPage);
  const morePage = el("section", "journal-subpage");
  morePage.tabIndex = -1;
  const moreBack = button("", "route", "journal-button", "accounts");
  const moreTitle = el("h2", "journal-section-title");
  moreTitle.tabIndex = -1;
  // Manage reads like the contents page of the notebook: numbered chapters
  // whose entries run along a dotted leader.
  const featureList = el("div", "journal-management");
  const managementGroups = Object.fromEntries(
    ["data", "tools", "settings", "application"].map((key) => {
      const panel = el("details", "journal-management-group");
      panel.dataset.group = key;
      const title = el("summary");
      const number = el("span", "journal-chapter-number");
      const name = el("span", "journal-chapter-title");
      title.append(number, name);
      const body = el("div", "journal-management-list");
      panel.append(title, body);
      featureList.append(panel);
      return [key, { panel, title, number, name, body }];
    }),
  );
  function managementToggled(event) {
    const target = event.target;
    if (!target.matches?.(".journal-management-group") || !target.open) return;
    for (const { panel } of Object.values(managementGroups))
      if (panel !== target) panel.open = false;
  }
  featureList.addEventListener("toggle", managementToggled, true);
  morePage.append(moreBack, moreTitle, featureList);
  const preferencesPage = el("section", "journal-subpage");
  preferencesPage.tabIndex = -1;
  const prefBack = button("", "route", "journal-button", "accounts");
  const prefTitle = el("h2", "journal-section-title");
  prefTitle.tabIndex = -1;
  const preferencesActions = el("div", "journal-legacy-preferences");
  const hostPreferences = button(
    "",
    "host",
    "journal-button journal-feature",
    "settings:preferences",
  );
  preferencesPage.append(prefBack, prefTitle, preferencesActions);
  const footer = el("footer", "journal-footer");
  const credit = el("span", "", "Journal · MIT");
  const license = el("a", "", "Licenses · MIT / Fonts · OFL");
  license.href = new URL("../licenses/NOTICE.txt", import.meta.url).href;
  // The 2FA version, a newer release and the project links, from the host.
  const about = el("div", "journal-footer-about");
  const aboutVersion = el("span", "journal-footer-version");
  const aboutUpdate = el("a", "journal-footer-update");
  const aboutLinks = [
    ["documentation", "pageDocumentation", "Documentation"],
    ["extension", "pageBrowserExtension", "Browser extension"],
    ["feedback", "pageFeedback", "Report an issue"],
    ["source", "aboutSourceCode", "Source code"],
  ].map(([key, labelKey, fallback]) => ({
    key,
    labelKey,
    fallback,
    node:
      key === "extension"
        ? button("", "host", "journal-footer-link", "extension")
        : el("a", "journal-footer-link"),
  }));
  for (const link of [aboutUpdate, ...aboutLinks.map((item) => item.node)])
    if (link.tagName === "A") {
      link.target = "_blank";
      link.rel = "noopener noreferrer";
    }
  // The links are grouped so a narrow screen can set them in two columns.
  const aboutLinkList = el("div", "journal-footer-links");
  aboutLinkList.append(...aboutLinks.map((item) => item.node));
  about.append(aboutVersion, aboutUpdate, aboutLinkList);
  about.hidden = true;
  footer.append(credit, license, about);
  // The notice opens inside the page: a new window in an installed app closes
  // the app when the user goes back.
  const licensePanel = el("section", "journal-license-panel");
  licensePanel.id = "journal-license-" + window.crypto.randomUUID();
  licensePanel.hidden = true;
  const licenseHead = el("div", "journal-license-head");
  const licenseTitle = el("h2", "journal-license-title", license.textContent);
  const licenseClose = el("button", "journal-button journal-license-close");
  licenseClose.type = "button";
  licenseHead.append(licenseTitle, licenseClose);
  const licenseText = el("pre", "journal-license-text");
  licenseText.tabIndex = -1;
  licensePanel.append(licenseHead, licenseText);
  license.setAttribute("aria-expanded", "false");
  license.setAttribute("aria-controls", licensePanel.id);
  main.append(
    notice,
    states,
    operations,
    queue,
    accountsPage,
    morePage,
    preferencesPage,
    footer,
    licensePanel,
  );
  workbook.append(header, main);
  surface.append(skip, workbook);
  root.append(surface);

  let licenseLoaded = false;
  let licenseLoading = false;
  function setLicenseOpen(open) {
    licensePanel.hidden = !open;
    license.setAttribute("aria-expanded", String(open));
    if (!open) {
      license.focus({ preventScroll: true });
      return;
    }
    licenseClose.textContent = t("close", "Close");
    if (!licenseLoaded && !licenseLoading) {
      licenseLoading = true;
      licenseText.textContent = local("waiting");
      Promise.resolve()
        .then(() => window.fetch(license.href))
        .then((response) => {
          if (!response.ok) throw new Error(String(response.status));
          return response.text();
        })
        .then(
          (text) => {
            licenseLoading = false;
            if (!live) return;
            licenseLoaded = true;
            licenseText.textContent = text;
            // The text makes the panel taller; centre it again so it stays clear of bottom bars.
            if (!licensePanel.hidden)
              licensePanel.scrollIntoView?.({ block: "center" });
          },
          () => {
            licenseLoading = false;
            if (live) licenseText.textContent = local("failed");
          },
        );
    }
    licenseText.focus({ preventScroll: true });
    // Centred, so fixed bottom bars and floating buttons cannot cover it.
    licensePanel.scrollIntoView?.({ block: "center" });
  }
  license.addEventListener("click", (event) => {
    if (
      event.button !== 0 ||
      event.metaKey ||
      event.ctrlKey ||
      event.shiftKey ||
      event.altKey
    )
      return;
    event.preventDefault();
    if (live) setLicenseOpen(licensePanel.hidden);
  });
  licenseClose.addEventListener("click", () => setLicenseOpen(false));
  licensePanel.addEventListener("keydown", (event) => {
    if (event.key !== "Escape" || event.isComposing) return;
    event.preventDefault();
    setLicenseOpen(false);
  });

  function currentAccount(id) {
    return snapshot.library.accounts.find((account) => account.ref.id === id);
  }
  function clearNotice() {
    noticeGeneration++;
    noticeSequence++;
    if (noticeTimer !== null) window.clearTimeout(noticeTimer);
    noticeTimer = null;
    notice.textContent = "";
    notice.hidden = true;
  }
  function say(message, { kind = "info" } = {}) {
    if (!live) return;
    if (!message) return clearNotice();
    if (noticeTimer !== null) window.clearTimeout(noticeTimer);
    const sequence = ++noticeSequence;
    notice.dataset.kind = kind;
    notice.textContent = message;
    notice.hidden = false;
    noticeTimer = window.setTimeout(
      () => {
        if (!live || sequence !== noticeSequence) return;
        noticeTimer = null;
        notice.textContent = "";
        notice.hidden = true;
      },
      kind === "error" ? 8000 : 4000,
    );
  }
  function explain(reason) {
    if (reason === "authentication-required")
      return t("loginSubmitBtn", "Sign in");
    if (reason === "unavailable" || reason === "host-unavailable")
      return local("unavailable");
    const keys = {
      "write-busy-reclick": "coreHotpWriteBusy",
      offline: "coreHotpCopyOffline",
      "clipboard-failed": "copyFailed",
      "reservation-rejected": "coreHotpRejected",
      "operation-pending-account-changed": "coreHotpAccountChangedPending",
      "counter-limit": "coreHotpLimit",
      "reconciliation-failed": "coreHotpReconcileFailed",
    };
    if (keys[reason]) return t(keys[reason], local("failed"));
    return [
      "not-ready",
      "stale-target",
      "expired",
      "clock-changed",
      "account-changed",
    ].includes(reason)
      ? local("expired")
      : local("failed");
  }
  function observe(
    promise,
    kind = "command",
    operationId = null,
    copied = local("copied"),
  ) {
    const session = snapshot.epochs.session;
    const generation = noticeGeneration;
    const notify = (message, options) => {
      if (generation === noticeGeneration) say(message, options);
    };
    Promise.resolve(promise).then(
      (result) => {
        if (
          !live ||
          snapshot.epochs.session !== session ||
          ["mount-invalidated", "session-invalidated"].includes(result?.reason)
        )
          return;
        if (kind === "reconcile" && result?.status === "committed") {
          const operation = snapshot.host.operations?.find(
            (item) => item.operationId === operationId,
          );
          if (operation) {
            const facts = operationFacts(operation);
            notify(
              [facts.clipboard, facts.reservation, facts.attention]
                .filter(Boolean)
                .join(" · "),
              { kind: operationResolved(operation) ? "success" : "error" },
            );
          }
        } else if (result?.clipboard) {
          if (result.reservation && result.reservation !== "not-attempted") {
            renderOperations();
            const facts = operationFacts(result);
            notify(
              [facts.clipboard, facts.reservation, facts.attention]
                .filter(Boolean)
                .join(" · "),
              { kind: operationResolved(result) ? "success" : "error" },
            );
          } else {
            notify(
              result.clipboard === "copied" ? copied : explain(result.reason),
              { kind: result.clipboard === "copied" ? "success" : "error" },
            );
          }
        } else if (
          ["rejected", "unknown", "not-started"].includes(result?.status)
        )
          notify(explain(result.reason), { kind: "error" });
        else if (
          // The page itself shows a scheme change; a notice would only repeat it.
          !["host", "scheme"].includes(kind) &&
          ["committed", "loaded"].includes(result?.status)
        )
          notify(local("done"), { kind: "success" });
      },
      () => {
        if (live && snapshot.epochs.session === session)
          notify(local("failed"), { kind: "error" });
      },
    );
  }
  function operationResolved(operation) {
    // A confirmed reservation and a completed clipboard do not prove that the
    // local counter committed. Only a complete commit or a successful readback
    // can resolve that conflict, and a read cannot confirm an unknown POST.
    if (
      operation.status !== "settled" ||
      operation.clipboard !== "copied" ||
      operation.reservation !== "confirmed"
    )
      return false;
    if (
      operation.reason === "local-refresh-failed" &&
      operation.reconciliation !== "succeeded"
    )
      return false;
    return (
      (operation.localCommit === "committed" &&
        operation.recovery === "none" &&
        ["not-needed", "succeeded"].includes(operation.reconciliation)) ||
      (operation.reconciliation === "succeeded" &&
        operation.recovery === "reconciled")
    );
  }
  function operationFacts(operation) {
    const states = {
      pending: "coreHotpStatePending",
      confirmed: "coreHotpStateConfirmed",
      rejected: "coreHotpStateRejected",
      unknown: "coreHotpStateUnknown",
      copied: "coreHotpStateCopied",
      failed: "coreHotpStateFailed",
    };
    const clipboard = t(
      states[operation.clipboard] || "coreHotpStateUnknown",
      local("unknown"),
    );
    const reservation = t(
      states[operation.reservation] || "coreHotpStateUnknown",
      local("unknown"),
    );
    let attention = "";
    if (operation.reconciliation === "running") attention = local("waiting");
    else if (
      operation.reconciliation === "failed" ||
      operation.recovery === "retry-reconcile"
    )
      attention = t("coreHotpReconcileFailed", local("failed"));
    else if (
      operation.clipboard === "failed" &&
      operation.reservation === "confirmed"
    )
      attention = t("coreHotpCopyFailedAdvanced", local("failed"));
    else if (!operationResolved(operation))
      attention = t("coreHotpReconcile", local("waiting"));
    return {
      clipboard: t("coreHotpClipboardState", `Clipboard: ${clipboard}`, {
        state: clipboard,
      }),
      reservation: t(
        "coreHotpReservationState",
        `Reservation: ${reservation}`,
        { state: reservation },
      ),
      attention,
    };
  }
  function host(request, trigger) {
    closeMenu(false);
    const returnFocus = trigger.closest?.(
      ".journal-states, .journal-queue-region",
    )
      ? more
      : trigger;
    const handle = sdk.host.open(request, { returnFocus });
    if (handle.status === "rejected")
      say(explain(handle.reason), { kind: "error" });
    else observe(handle.closed, "host");
  }
  function descriptorRequest(value) {
    const found = sdk.host
      .listActions()
      .find((item) => item.actionId === value);
    return found?.request || { kind: value };
  }
  function closeMenu(restoreFocus = true) {
    const card = cards.get(menuId);
    if (card) {
      card.menu.hidden = true;
      card.node.dataset.menuOpen = "false";
      card.trigger.setAttribute("aria-expanded", "false");
      if (restoreFocus && card.trigger.isConnected) card.trigger.focus();
    }
    menuId = null;
  }
  function openMenu(id, focus = false) {
    if (menuId === id) {
      closeMenu();
      return;
    }
    closeMenu(false);
    const card = cards.get(id);
    if (!card) return;
    menuId = id;
    card.menu.hidden = false;
    card.node.dataset.menuOpen = "true";
    card.trigger.setAttribute("aria-expanded", "true");
    if (focus) card.menu.firstElementChild?.focus();
  }
  function cancelAnimation(id) {
    animations.get(id)?.cancel();
    animations.delete(id);
  }
  function copy(id, slot) {
    const target = sdk.otp.readCopyTarget(id, slot);
    if (target.status !== "ready") {
      say(explain(target.reason), { kind: "error" });
      return;
    }
    const card = cards.get(id);
    cancelAnimation(id);
    if (card)
      (slot === "next" ? card.nextValue : card.value).textContent =
        target.target.value;
    // Name the slot: the current and the next code are copied the same way.
    const account = currentAccount(id);
    const copied = t(
      slot === "next" ? "coreCopiedNextService" : "coreCopiedService",
      local("copied"),
      { name: account?.service.label || t("coreCode", "Code") },
    );
    // Same event stack: no await before the SDK starts the native clipboard.
    observe(sdk.otp.copy(target.target), "copy", null, copied);
  }
  function createCard(account) {
    const node = el("article", "journal-card");
    node.dataset.account = account.ref.id;
    node.dataset.accountId = account.ref.id;
    const cardHeader = el("div", "journal-card-header");
    const icon = el("span", "journal-service-mark");
    icon.setAttribute("aria-hidden", "true");
    const names = el("div", "journal-account-identity");
    const service = el("h3", "journal-account-name");
    const accountLabel = el("p", "journal-account-address");
    names.append(service, accountLabel);
    const menuHolder = el("div", "journal-account-menu");
    const trigger = button("⋮", "menu", "journal-button is-icon");
    trigger.setAttribute("aria-expanded", "false");
    const menu = el("div", "journal-menu-popover journal-menu");
    menu.hidden = true;
    const menuActions = ["qr", "uri", "link", "edit", "delete"].map((action) =>
      button(
        "",
        action,
        "journal-menu-item" + (action === "delete" ? " is-danger" : ""),
      ),
    );
    menu.append(...menuActions);
    menuHolder.append(trigger, menu);
    cardHeader.append(icon, names, menuHolder);
    const codes = el("div", "journal-codes");
    const codeLabel = el("div", "journal-otp-label");
    const currentLabel = el("span");
    // Only counter-based accounts carry a badge; TOTP needs no metadata.
    const badge = el("span", "journal-badge");
    codeLabel.append(currentLabel);
    const copyButton = button("", "copy", "journal-copy-code");
    const value = el("span", "journal-otp-value");
    const copyIcon = el("span", "journal-copy-symbol", "⧉");
    copyIcon.setAttribute("aria-hidden", "true");
    copyButton.append(value, copyIcon);
    const next = button("", "next", "journal-otp-next");
    const nextLabel = el("span");
    const nextValue = el("span", "journal-next-value");
    next.append(nextLabel, nextValue);
    codes.append(codeLabel, copyButton, next);
    const timing = el("div", "journal-expiry");
    const timingLabel = el("div", "journal-expiry-label");
    const timingTitle = el("span");
    const remaining = el("strong");
    timingLabel.append(timingTitle, remaining);
    const progress = el("div", "journal-progress");
    progress.setAttribute("aria-hidden", "true");
    const fill = el("span", "journal-progress-fill");
    progress.append(fill);
    timing.append(timingLabel, progress);
    node.append(cardHeader, codes, timing);
    return {
      node,
      icon,
      service,
      accountLabel,
      trigger,
      menu,
      menuActions,
      codeLabel,
      currentLabel,
      badge,
      copyButton,
      value,
      next,
      nextLabel,
      nextValue,
      timing,
      timingTitle,
      remaining,
      progress,
      fill,
      account,
      previous: null,
    };
  }
  // Shows the service icon once it has loaded. The letter stays when there is
  // no icon or it cannot load (the editor preview does not allow it).
  function setServiceMark(
    node,
    account,
    letter = Array.from(account.service.label)[0] || "•",
  ) {
    const url = account.service.iconURL || "";
    if (node.dataset.letter === letter && node.dataset.icon === url) return;
    node.dataset.letter = letter;
    node.dataset.icon = url;
    node.classList.remove("has-icon");
    node.textContent = letter;
    if (!url) return;
    const image = node.ownerDocument.createElement("img");
    image.alt = "";
    image.decoding = "async";
    image.addEventListener(
      "load",
      () => {
        if (node.dataset.icon !== url) return;
        node.replaceChildren(image);
        node.classList.add("has-icon");
      },
      { once: true },
    );
    image.src = url;
  }
  function updateCard(card, account) {
    card.account = account;
    card.service.textContent = account.service.label;
    card.service.title = account.service.label;
    card.accountLabel.textContent = account.accountLabel;
    card.accountLabel.title = account.accountLabel;
    card.accountLabel.hidden = !account.accountLabel;
    setServiceMark(card.icon, account);
    card.trigger.setAttribute(
      "aria-label",
      t("cardMenuAriaLabel", local("more")) + " · " + account.service.label,
    );
    const labels = [
      ["cardMenuQRCode", "QR"],
      ["cardMenuCopyURI", "Copy URI"],
      ["cardMenuCopyLink", "Copy link"],
      ["cardMenuEdit", "Edit"],
      ["cardMenuDelete", "Delete"],
    ];
    card.menuActions.forEach((node, index) => {
      node.textContent = t(...labels[index]);
    });
    card.currentLabel.textContent = local("current");
    card.currentLabel.classList.add("journal-sr-only");
    if (account.type === "HOTP") {
      card.badge.textContent = account.type;
      if (!card.badge.isConnected) card.codeLabel.append(card.badge);
    } else card.badge.remove();
    card.node.dataset.type = account.type;
    // TOTP needs no type, period, digits or algorithm; HOTP names its counter.
    if (account.type === "HOTP")
      card.copyButton.setAttribute(
        "aria-description",
        `${account.type}, ${t("counterLabel", "Counter").trim()} ${account.counter}`,
      );
    else card.copyButton.removeAttribute("aria-description");
    const value = account.otp.current?.value || "···";
    if (card.previous !== null && card.previous !== value) {
      cancelAnimation(account.ref.id);
      const effect = snapshot.preferences.otpAnimation;
      if (
        !snapshot.preferences.reducedMotion &&
        !window.matchMedia?.("(prefers-reduced-motion: reduce)").matches &&
        card.value.animate &&
        effect !== "none"
      ) {
        const frames =
          effect === "flip"
            ? [{ transform: "rotateX(75deg)" }, { transform: "rotateX(0)" }]
            : effect === "spotlight"
              ? [
                  { background: "var(--journal-selected)" },
                  { background: "transparent" },
                ]
              : [
                  { transform: "translateY(-5px)", opacity: 0.4 },
                  { transform: "translateY(0)", opacity: 1 },
                ];
        animations.set(
          account.ref.id,
          card.value.animate(frames, { duration: 180 }),
        );
      }
    }
    card.previous = value;
    card.value.textContent = value;
    card.value.dataset.digits = String(account.digits);
    card.copyButton.disabled =
      account.otp.current?.copyAvailability !== "ready";
    card.copyButton.title = card.copyButton.disabled
      ? account.otp.current?.copyAvailability === "offline"
        ? local("offline")
        : local("waiting")
      : t("copyOtpBtnTitle", "Copy code");
    card.copyButton.setAttribute(
      "aria-label",
      `${t("copyOtpBtnAriaLabel", "Copy current code")} · ${account.service.label} ${account.accountLabel}`,
    );
    card.next.hidden = account.type === "HOTP";
    card.next.disabled = account.otp.next?.copyAvailability !== "ready";
    card.nextLabel.textContent = t("otpNextLabel", "Next");
    card.nextValue.textContent = account.otp.next?.value || "···";
    card.next.setAttribute(
      "aria-label",
      `${t("copyNextOtpBtnTitle", "Copy next code")} · ${account.service.label}`,
    );
    card.next.title = t("copyNextOtpBtnTitle", "Copy next code");
    card.progress.hidden = account.type === "HOTP";
    card.timingTitle.textContent =
      account.type === "HOTP"
        ? t("counterLabel", "Counter")
        : `${account.period}${local("seconds")}`;
  }
  function renderTime() {
    if (!live) return;
    const now = sdk.clock?.now();
    for (const card of cards.values()) {
      const account = card.account;
      if (account.type === "HOTP") {
        card.remaining.textContent = String(account.counter);
        continue;
      }
      const current = account.otp.current;
      const seconds =
        typeof now === "number" && current
          ? Math.max(0, Math.ceil((current.validUntil - now) / 1000))
          : null;
      card.remaining.textContent =
        seconds === null ? local("waiting") : `${seconds}${local("seconds")}`;
      card.timing.dataset.expiring = String(seconds !== null && seconds <= 5);
      card.fill.style.setProperty(
        "--journal-progress",
        `${seconds === null ? 0 : Math.min(100, (seconds / account.period) * 100)}%`,
      );
      if (seconds === 0) card.copyButton.disabled = true;
    }
  }
  function syncChildren(parent, nodes) {
    nodes.forEach((node, index) => {
      if (parent.children[index] !== node)
        parent.insertBefore(node, parent.children[index] || null);
    });
    while (parent.children.length > nodes.length)
      parent.lastElementChild.remove();
  }
  function renderAccounts() {
    const view = snapshot.library.view;
    count.hidden = !view.query && !view.serviceFilter;
    overview.hidden =
      currentAppearance.settings?.showOverview === false || !count.hidden;
    const ids = new Set(
      snapshot.library.accounts.map((account) => account.ref.id),
    );
    for (const [id, card] of cards)
      if (!ids.has(id)) {
        if (menuId === id) closeMenu(false);
        cancelAnimation(id);
        card.node.remove();
        cards.delete(id);
      }
    for (const account of snapshot.library.accounts) {
      let card = cards.get(account.ref.id);
      if (!card) {
        card = createCard(account);
        cards.set(account.ref.id, card);
      }
      if (
        card.account.ref.generation !== account.ref.generation &&
        menuId === account.ref.id
      )
        closeMenu(false);
      updateCard(card, account);
    }
    const sections =
      view.mode === "grouped" && view.groups.length
        ? view.groups
        : [{ groupId: "journal-flat", label: "", ids: view.resultIds }];
    const structure = JSON.stringify([
      view.mode,
      sections.map((group) => [group.groupId, group.label, group.ids]),
    ]);
    if (structure !== lastStructure) {
      const liveGroups = new Set();
      const sectionsDOM = sections.map((group) => {
        liveGroups.add(group.groupId);
        let section = groups.get(group.groupId);
        if (!section) {
          section = {
            node: el("section", "journal-group"),
            title: el("h3", "journal-group-title"),
            label: el("span", "journal-group-label"),
            list: el("div", "journal-account-grid"),
          };
          section.title.append(section.label);
          section.node.append(section.title, section.list);
          groups.set(group.groupId, section);
        }
        section.label.textContent = group.label;
        section.title.hidden =
          !group.label || (sections.length === 1 && group.isOther);
        syncChildren(
          section.list,
          group.ids.map((id) => cards.get(id)?.node).filter(Boolean),
        );
        return section.node;
      });
      syncChildren(accountList, sectionsDOM);
      for (const id of groups.keys())
        if (!liveGroups.has(id)) groups.delete(id);
      lastStructure = structure;
    }
    if (menuId && !cards.get(menuId)?.node.isConnected) closeMenu(false);
    const unknownCount =
      snapshot.session.state !== "authenticated" ||
      !Number.isFinite(view.found) ||
      !Number.isFinite(view.total);
    count.textContent = unknownCount
      ? local("unknown")
      : t("searchFoundCount", `${view.found} / ${view.total}`, {
          found: view.found,
          total: view.total,
        });
    const filtered = Boolean(view.query || view.serviceFilter);
    const signedOut = snapshot.session.state === "logged-out";
    empty.hidden = view.found > 0 && !signedOut;
    accountList.hidden = signedOut;
    const loading = snapshot.library.state === "loading" || unknownCount;
    const failure = snapshot.library.state === "error";
    emptyTitle.textContent = signedOut
      ? t("loginSubmitBtn", "Sign in")
      : loading
        ? t("loadingSecrets", local("waiting"))
        : failure
          ? local("failed")
          : filtered
            ? t("searchNoMatch", "No matching accounts")
            : t("emptyTitle", "No accounts yet");
    emptyDescription.textContent =
      signedOut || loading
        ? ""
        : filtered
          ? t("searchNoMatchDesc", "Try a different search")
          : t("emptyDesc", "Add an account to generate verification codes.");
    emptyAction.textContent = signedOut
      ? t("loginSubmitBtn", "Sign in")
      : failure || loading
        ? t("retry", "Retry")
        : filtered
          ? t("searchClearAriaLabel", "Clear search")
          : t("emptyAddBtn", "Add account");
    emptyAction.dataset.action = signedOut
      ? "host"
      : failure || loading
        ? "refresh"
        : filtered
          ? "clear"
          : "host";
    emptyAction.dataset.value = signedOut ? "login" : "account-add";
    renderTime();
  }
  function renderStates() {
    const focused = states.contains(document.activeElement)
      ? document.activeElement
      : null;
    const children = [];
    const append = (key, text, action, value) => {
      let node = stateNodes.get(key);
      if (!node) {
        node = action
          ? button("", action, "journal-state journal-button", value)
          : el("p", "journal-state");
        stateNodes.set(key, node);
      }
      if (node.textContent !== text) node.textContent = text;
      children.push(node);
    };
    if (sdk.identity.mode === "preview")
      append("preview", t("appearancePreview", "Preview"));
    if (snapshot.session.state !== "authenticated")
      append("login", t("loginSubmitBtn", "Sign in"), "host", "login");
    if (snapshot.connectivity.onlineHint === false)
      append("offline", local("offline"));
    // Cached accounts show first on every load; name them only once the refresh is over,
    // and not beside a failed refresh, which already says so and offers a retry.
    if (
      snapshot.library.source === "local" &&
      !["refreshing", "error"].includes(snapshot.library.refreshState)
    )
      append("local", local("local"));
    if (snapshot.library.refreshState === "error")
      append("refresh", local("failed"), "refresh");
    if (
      // Only a clock that was never checked; a cached offset from an earlier check is fine.
      snapshot.clock.status === "local"
    )
      append("clock", t("clockWarningText", local("clock")));
    if (snapshot.library.hidden.count)
      append(
        "hidden",
        `${t("pageHiddenAccounts", "Hidden accounts")} · ${snapshot.library.hidden.count}`,
        "host",
        "hidden-accounts",
      );
    if (snapshot.host.updateAvailable || snapshot.host.versionMismatch)
      append("update", t("pwaUpdateBtn", "Update"), "reload", "update");
    if (snapshot.host.offlineReady === false)
      append(
        "offline-pending",
        local("offlineResources") + ": " + local("waiting"),
      );
    syncChildren(states, children);
    states.hidden = children.length === 0;
    restoreStatusFocus(focused);
  }
  function restoreStatusFocus(focused) {
    if (
      focused &&
      !snapshot.host.dialogOpen &&
      (!focused.isConnected || focused.closest("[hidden]"))
    )
      more.focus({ preventScroll: true });
  }
  function managementActionVisible(item) {
    if (
      [
        "hidden-accounts",
        "offline-queue",
        "offline-queue-status-retry",
        // Safe mode is offered by the host's error bar, not the menu.
        "recovery",
      ].includes(item.actionId)
    )
      return false;
    if (item.actionId === "login")
      return snapshot.session.state === "logged-out";
    if (item.actionId === "logout")
      return ["authenticated", "unconfirmed"].includes(snapshot.session.state);
    if (item.actionId === "pwa-install")
      return snapshot.host.installAvailable === true && item.enabled;
    return true;
  }
  function renderManagement() {
    const focused = document.activeElement;
    const focusedGroup = focused?.closest?.(".journal-management-group");
    const descriptors = sdk.host.listActions();
    const byId = new Map(
      descriptors
        .filter((item) => !item.requires)
        .map((item) => [item.actionId, item]),
    );
    const groups = managementActions(
      descriptors.filter(managementActionVisible),
    );
    const labels = {
      data: "navData",
      tools: "navTools",
      settings: "navSettings",
      application: "navMore",
    };
    let chapter = 0;
    const prefsDescriptor = byId.get("settings:preferences");
    hostPreferences.disabled = !prefsDescriptor?.enabled;
    for (const [key, items] of Object.entries(groups)) {
      const group = managementGroups[key];
      // Chapters the host offers nothing for are left out of the numbering.
      group.panel.hidden = !items.length && key !== "settings";
      if (!group.panel.hidden) chapter++;
      const number = chapterNumber(lang, chapter);
      if (group.number.textContent !== number)
        group.number.textContent = number;
      if (group.name.textContent !== local(labels[key]))
        group.name.textContent = local(labels[key]);
      const nodes = items.map((item) => {
        let entry = actionNodes.get(item.actionId);
        if (!entry) {
          const node =
            item.actionId === "settings:preferences"
              ? hostPreferences
              : button(
                  "",
                  "host",
                  "journal-button journal-feature",
                  item.actionId,
                );
          const label = el("span");
          const reason = el("small", "journal-muted");
          node.replaceChildren(label, reason);
          entry = { node, label, reason };
          actionNodes.set(item.actionId, entry);
        }
        const label =
          item.actionId === "appearance"
            ? local("appearance")
            : item.actionId === "quick-otp"
              ? t("quickOtpTitle", "Generate verification code")
              : t(item.labelKey, local("unavailable"));
        if (entry.label.textContent !== label) entry.label.textContent = label;
        entry.node.disabled = !item.enabled;
        entry.reason.hidden = Boolean(item.enabled);
        const reason = item.enabled ? "" : explain(item.reason);
        if (entry.reason.textContent !== reason)
          entry.reason.textContent = reason;
        return entry.node;
      });
      // The colour scheme opens the settings, as in the other themes.
      if (key === "settings") nodes.unshift(scheme);
      // The old preferences hash reuses the sole host-preferences control.
      syncChildren(
        group.body,
        nodes.filter(
          (node) => preferencesPage.hidden || node !== hostPreferences,
        ),
      );
    }
    if (!preferencesPage.hidden) {
      if (!prefsDescriptor) {
        const entry = actionNodes.get("settings:preferences");
        if (entry) {
          entry.label.textContent = local("preferences");
          entry.reason.textContent = local("unavailable");
          entry.reason.hidden = false;
        } else
          hostPreferences.textContent =
            local("preferences") + " · " + local("unavailable");
      }
      syncChildren(preferencesActions, [hostPreferences]);
    }
    if (
      focusedGroup?.isConnected &&
      !focused.isConnected &&
      !snapshot.host.dialogOpen
    )
      focusedGroup.querySelector("summary").focus({ preventScroll: true });
  }
  function renderOperations() {
    const records = (snapshot.host.operations || []).filter(
      (item) => item.type === "hotp" && !operationResolved(item),
    );
    operations.hidden = records.length === 0;
    operationsTitle.textContent = t(
      "coreHotpOperationTitle",
      "HOTP operation status",
    );
    const ids = new Set(records.map((operation) => operation.operationId));
    syncChildren(operations, [
      operationsTitle,
      ...records.map((operation) => {
        let row = operationRows.get(operation.operationId);
        if (!row) {
          row = {
            node: el("div", "journal-operation"),
            name: el("strong"),
            clipboard: el("span"),
            reservation: el("span"),
            attention: el("span"),
            reconcile: button(
              "",
              "reconcile",
              "journal-button",
              operation.operationId,
            ),
            recover: button("", "reload", "journal-button", "recovery"),
          };
          row.node.append(
            row.name,
            row.clipboard,
            row.reservation,
            row.attention,
            row.reconcile,
            row.recover,
          );
          operationRows.set(operation.operationId, row);
        }
        const account = currentAccount(String(operation.accountId));
        row.name.textContent = account?.service.label || "HOTP";
        const facts = operationFacts(operation);
        row.clipboard.textContent = facts.clipboard;
        row.reservation.textContent = facts.reservation;
        row.attention.textContent = facts.attention;
        row.attention.hidden = !facts.attention;
        row.reconcile.textContent = t(
          "coreHotpReconcile",
          "Check counter state",
        );
        row.reconcile.disabled = operation.reconciliation === "running";
        row.recover.textContent = t(
          "coreHotpRecoveryReload",
          "Recover in safe mode",
        );
        row.recover.hidden = operation.recovery !== "reload-required";
        return row.node;
      }),
    ]);
    for (const id of operationRows.keys())
      if (!ids.has(id)) operationRows.delete(id);
  }
  function renderQueue() {
    const focused = queue.contains(document.activeElement)
      ? document.activeElement
      : null;
    const records = snapshot.queue.operations || [];
    queue.hidden =
      records.length === 0 &&
      !snapshot.queue.unavailable &&
      !snapshot.queue.authRequired;
    queueTitle.textContent = local("queue");
    queueView.textContent = t("offlineQueueView", "View pending changes");
    queueRetry.textContent = t("restoreRefresh", "Refresh");
    queueRetry.hidden = !snapshot.queue.unavailable;
    const nodes = [queueTitle, queueView, queueRetry];
    const ids = new Set();
    records.forEach((item) => {
      const id = item.operationId || item.id;
      ids.add(id);
      let row = queueRows.get(id);
      if (!row) {
        row = {
          node: el("div", "journal-operation"),
          name: el("strong"),
          status: el("span"),
          actions: new Map(),
        };
        row.node.append(row.name, row.status);
        queueRows.set(id, row);
      }
      row.name.textContent = item.name || local("accounts");
      const status =
        item.status === "failed" || item.failureReason
          ? local("failed")
          : item.claimed || item.status === "sending"
            ? local("waiting")
            : local("queue");
      row.status.textContent = status;
      for (const [flag, kind, key, fallback] of [
        ["canEdit", "offline-queue-edit", "offlineQueueEditRetry", "Edit"],
        ["canRetry", "offline-queue-retry", "retry", "Retry"],
        [
          "canCancel",
          "offline-queue-cancel",
          "offlineQueueCancelChange",
          "Cancel",
        ],
      ]) {
        let action = row.actions.get(kind);
        if (!action) {
          action = button("", "queue", "journal-button", kind);
          row.actions.set(kind, action);
          row.node.append(action);
        }
        action.textContent = t(key, fallback);
        action.hidden = !item[flag];
        action.dataset.operation = id;
        action.disabled = Boolean(item.claimed || snapshot.queue.busy);
      }
      nodes.push(row.node);
    });
    syncChildren(queue, nodes);
    for (const id of queueRows.keys()) if (!ids.has(id)) queueRows.delete(id);
    restoreStatusFocus(focused);
  }
  function renderChrome() {
    skip.textContent = local("skip");
    accountTitle.textContent = local("accounts");
    overviewAccountsLabel.textContent = local("accounts");
    overviewServicesLabel.textContent = local("services");
    overviewCaption.textContent = local("notebook");
    const known =
      snapshot.session.state === "authenticated" &&
      Number.isFinite(snapshot.library.view.total) &&
      (snapshot.library.state === "ready" ||
        (snapshot.library.source === "local" &&
          snapshot.library.accounts.length > 0));
    overviewAccounts.textContent = known
      ? String(snapshot.library.view.total)
      : "—";
    overviewServices.textContent = known
      ? String(snapshot.library.view.services.length)
      : "—";
    overview.setAttribute("aria-label", local("notebook"));
    scheme.textContent = t(
      snapshot.preferences.resolvedTheme === "dark"
        ? "themeLight"
        : "themeDark",
      snapshot.preferences.resolvedTheme === "dark" ? "Light" : "Dark",
    );
    more.textContent = local("manage");
    search.placeholder = t(
      "searchInputPlaceholder",
      "Search service or account",
    );
    search.setAttribute(
      "aria-label",
      t("searchInputAriaLabel", "Search accounts"),
    );
    clear.setAttribute("aria-label", t("searchClearAriaLabel", "Clear search"));
    if (document.activeElement !== search)
      search.value = snapshot.library.view.query;
    modes.title.textContent = t("viewModeLabel", "View");
    viewSummary.textContent = local("view");
    options(
      modes.select,
      [
        ["grouped", t("viewModeGrouped", "Grouped")],
        ["flat", t("viewModeFlat", "Flat")],
      ],
      snapshot.library.view.mode,
    );
    sorting.title.textContent = t(
      snapshot.library.view.mode === "flat"
        ? "sortModeFlatLabel"
        : "sortModeLabel",
      "Sort",
    );
    const sorts = [
      ["oldest-first", "sortOldestFirst", "Oldest first"],
      ["newest-first", "sortNewestFirst", "Newest first"],
      ["name-asc", "sortServiceNameAsc", "Service A–Z"],
      ["name-desc", "sortServiceNameDesc", "Service Z–A"],
      ["account-asc", "sortAccountNameAsc", "Account A–Z"],
      ["account-desc", "sortAccountNameDesc", "Account Z–A"],
    ];
    options(
      sorting.select,
      sorts
        .filter(
          ([key]) =>
            snapshot.library.view.mode === "flat" || !key.startsWith("name-"),
        )
        .map(([value, key, fallback]) => [value, t(key, fallback)]),
      snapshot.library.view.mode === "flat"
        ? snapshot.library.view.flatSort
        : snapshot.library.view.groupedItemSort,
    );
    groupSort.label.hidden = snapshot.library.view.mode !== "grouped";
    groupSort.title.textContent = t("groupSortLabel", "Group sort");
    options(
      groupSort.select,
      [
        ["name-asc", t("groupSortNameAsc", "Name A–Z")],
        ["name-desc", t("groupSortNameDesc", "Name Z–A")],
      ],
      snapshot.library.view.groupSort,
    );
    services.title.textContent = local("service");
    options(
      services.select,
      [
        ["", local("all")],
        ...snapshot.library.view.services.map((service) => [
          service.groupId,
          `${service.label} ${Number.isFinite(service.count) ? service.count : "—"}`,
        ]),
      ],
      snapshot.library.view.serviceFilter || "",
    );
    services.select.setAttribute("aria-label", local("service"));
    renderIndex();
    prefBack.textContent = moreBack.textContent = local("back");
    prefTitle.textContent = local("preferences");
    moreTitle.textContent = local("manage");
    renderManagement();
  }
  function renderIndex() {
    const view = snapshot.library.view;
    const active = view.serviceFilter || "";
    indexTitle.textContent = local("service");
    indexNav.setAttribute("aria-label", local("service"));
    const tab = (node, label, count, value, tone) => {
      if (!node.firstChild) node.append(el("span"), el("small"));
      node.firstChild.textContent = label;
      node.lastChild.textContent = count;
      node.title = label;
      node.dataset.tone = String(tone);
      node.setAttribute("aria-pressed", String(active === value));
    };
    const known = Number.isFinite(view.total);
    tab(indexAll, local("all"), known ? String(view.total) : "—", "", 0);
    const live = new Set();
    const items = [indexAllItem];
    view.services.forEach((service, index) => {
      live.add(service.groupId);
      let entry = indexTabs.get(service.groupId);
      if (!entry) {
        const node = button("", "filter", "journal-index-tab", service.groupId);
        entry = { node, item: indexItem(node) };
        indexTabs.set(service.groupId, entry);
      }
      tab(
        entry.node,
        service.label,
        Number.isFinite(service.count) ? String(service.count) : "—",
        service.groupId,
        (index % 5) + 1,
      );
      items.push(entry.item);
    });
    for (const id of indexTabs.keys()) if (!live.has(id)) indexTabs.delete(id);
    syncChildren(indexList, items);
  }
  function applyAppearance(next) {
    currentAppearance = next || {};
    const settings = currentAppearance.settings || {};
    surface.dataset.density =
      settings.density === "compact" ? "compact" : "comfortable";
    surface.dataset.stampInk = ["postmark", "pine", "walnut"].includes(
      settings.stampInk,
    )
      ? settings.stampInk
      : "postmark";
    surface.dataset.handwriting = String(settings.handwriting !== false);
    surface.dataset.pageRuling =
      settings.pageRuling === "blank" ? "blank" : "dots";
    surface.dataset.paperDecorations = String(
      settings.paperDecorations !== false,
    );
    overview.hidden = settings.showOverview === false;
  }
  function route(focus = false) {
    const previousPage = [accountsPage, morePage, preferencesPage].find(
      (page) => page.contains(document.activeElement),
    );
    const routeHash = window.location.hash;
    if (focus || renderedRoute !== routeHash) clearNotice();
    renderedRoute = routeHash;
    const current =
      /^#\/theme\/journal\/(accounts|more|preferences)$/.exec(
        window.location.hash,
      )?.[1] || "accounts";
    accountsPage.hidden = current !== "accounts";
    morePage.hidden = current !== "more";
    more.setAttribute("aria-expanded", String(!morePage.hidden));
    preferencesPage.hidden = current !== "preferences";
    closeView(false);
    renderManagement();
    if (!snapshot.host.dialogOpen && (focus || previousPage?.hidden))
      ({
        accounts: search,
        more: moreTitle,
        preferences: prefTitle,
      })[current].focus({ preventScroll: true });
  }
  // Hosts before host.about have no version to show; the row stays hidden.
  function renderAbout() {
    const info = snapshot.host.about;
    about.hidden = !info;
    if (!info) return;
    aboutVersion.textContent = `2FA v${info.version}`;
    aboutUpdate.hidden = !(info.latestVersion && info.links.releases);
    if (!aboutUpdate.hidden) {
      aboutUpdate.href = info.links.releases;
      aboutUpdate.textContent = t(
        "versionUpdateAvailable",
        `New version available: v${info.latestVersion}`,
        { version: `v${info.latestVersion}` },
      );
    }
    const extension = sdk.host
      .listActions()
      .find((item) => item.actionId === "extension");
    for (const { key, labelKey, fallback, node } of aboutLinks) {
      node.textContent = t(labelKey, fallback);
      if (key === "extension") node.hidden = !extension?.enabled;
      else {
        node.hidden = !info.links[key];
        if (info.links[key]) node.href = info.links[key];
      }
    }
  }
  function render(next) {
    if (!live) return;
    if (snapshot.epochs.session !== next.epochs.session) {
      closeMenu(false);
      say("");
      cards.forEach((_, id) => cancelAnimation(id));
    }
    snapshot = next;
    lang = next.preferences.resolvedLanguage || "en";
    surface.lang = lang;
    surface.dataset.colorScheme =
      next.preferences.resolvedTheme === "dark" ? "dark" : "light";
    surface.dataset.reducedMotion = String(
      next.preferences.reducedMotion === true,
    );
    hostAppearance.update();
    if (next.host.dialogOpen) closeMenu(false);
    renderChrome();
    renderAccounts();
    renderStates();
    renderOperations();
    renderQueue();
    renderAbout();
  }
  // The whole card copies its current code; its buttons and menu keep their own actions.
  function copyFromCard(event) {
    const node = event.target.closest?.("[data-account]");
    const card = node && cards.get(node.dataset.account);
    if (!live || !card || card.node !== node || !surface.contains(node)) return;
    if (card.menu?.contains(event.target)) return;
    if (event.target.closest("a, button, input, select, textarea, label"))
      return;
    if (String(window.getSelection?.() || "")) return;
    if (!card.copyButton.disabled) card.copyButton.click();
  }
  function onClick(event) {
    const trigger = event.target.closest?.("[data-action]");
    if (!trigger) {
      copyFromCard(event);
      return;
    }
    if (!surface.contains(trigger) || trigger.disabled || !live) return;
    const action = trigger.dataset.action,
      value = trigger.dataset.value;
    const id = trigger.closest("[data-account]")?.dataset.account;
    if (action !== "menu" && !trigger.closest(".journal-menu-popover"))
      closeMenu(false);
    if (action === "host") host(descriptorRequest(value), trigger);
    else if (action === "queue")
      host({ kind: value, operationId: trigger.dataset.operation }, trigger);
    else if (["qr", "edit", "delete"].includes(action)) {
      const account = currentAccount(id);
      if (account)
        host(
          { kind: "account-" + action, account: account.ref },
          cards.get(id)?.trigger || trigger,
        );
    } else if (action === "uri" || action === "link") {
      const account = currentAccount(id);
      closeMenu();
      if (account)
        observe(
          action === "uri"
            ? sdk.accounts.copyURI(account.ref)
            : sdk.accounts.copyShareLink(account.ref),
          "copy",
        );
    } else if (action === "copy" || action === "next")
      copy(id, action === "next" ? "next" : "current");
    else if (action === "menu") openMenu(id);
    else if (action === "refresh") observe(sdk.accounts.refresh());
    else if (action === "clear") {
      clearNotice();
      search.value = "";
      sdk.view.setQuery("");
      sdk.view.setServiceFilter(null);
      search.focus();
    } else if (action === "filter") sdk.view.setServiceFilter(value || null);
    else if (action === "scheme")
      observe(
        sdk.preferences.set({
          theme:
            snapshot.preferences.resolvedTheme === "dark" ? "light" : "dark",
        }),
        "scheme",
      );
    else if (action === "reconcile")
      observe(sdk.otp.reconcile(value), "reconcile", value);
    else if (action === "reload") observe(sdk.lifecycle.requestReload(value));
    else if (action === "route" || action === "skip") {
      // The menu button also closes the management page it opened.
      const page =
        action === "skip" || (trigger === more && !morePage.hidden)
          ? "accounts"
          : value;
      window.location.hash = "/theme/journal/" + page;
      route(true);
    }
  }
  function onSearchSubmit(event) {
    event.preventDefault();
  }
  function onInput(event) {
    if (event.target === search && !event.isComposing)
      sdk.view.setQuery(search.value);
  }
  function onCompositionEnd(event) {
    if (event.target === search) sdk.view.setQuery(search.value);
  }
  function onChange(event) {
    const key = event.target.dataset.setting,
      value = event.target.value;
    if (key === "mode") sdk.view.setMode(value);
    else if (key === "sort")
      sdk.view.setSort({
        [snapshot.library.view.mode === "flat"
          ? "flatSort"
          : "groupedItemSort"]: value,
      });
    else if (key === "groupSort") sdk.view.setSort({ groupSort: value });
    else if (key === "service") sdk.view.setServiceFilter(value || null);
  }
  function onKey(event) {
    if (
      snapshot.host.dialogOpen ||
      event.isComposing ||
      event.altKey ||
      event.ctrlKey ||
      event.metaKey
    )
      return;
    const trigger = event.target;
    if (event.key === "Escape" && menuId) {
      event.preventDefault();
      closeMenu();
      return;
    }
    if (event.key === "Escape" && viewOptions.open) {
      event.preventDefault();
      closeView(true);
      return;
    }
    const disclosure = trigger.closest?.(".journal-management-group");
    if (event.key === "Escape" && disclosure?.open) {
      event.preventDefault();
      disclosure.open = false;
      disclosure.querySelector("summary").focus({ preventScroll: true });
      return;
    }
    if (
      trigger.dataset.action === "menu" &&
      ["ArrowDown", "ArrowUp"].includes(event.key)
    ) {
      event.preventDefault();
      openMenu(trigger.closest("[data-account]").dataset.account, true);
      return;
    }
    const menu = trigger.closest(".journal-menu-popover");
    if (menu && ["ArrowDown", "ArrowUp", "Home", "End"].includes(event.key)) {
      event.preventDefault();
      const items = [...menu.querySelectorAll("button:not(:disabled)")];
      const index = items.indexOf(trigger);
      const target =
        event.key === "Home"
          ? 0
          : event.key === "End"
            ? items.length - 1
            : (index + (event.key === "ArrowDown" ? 1 : -1) + items.length) %
              items.length;
      items[target]?.focus();
      return;
    }
    if (
      trigger.dataset.action !== "copy" ||
      ![
        "ArrowUp",
        "ArrowDown",
        "ArrowLeft",
        "ArrowRight",
        "Home",
        "End",
      ].includes(event.key)
    )
      return;
    const items = [
      ...accountList.querySelectorAll('[data-action="copy"]'),
    ].filter((item) => !item.disabled);
    if (!items.length) return;
    event.preventDefault();
    if (event.key === "Home" || event.key === "End") {
      items[event.key === "Home" ? 0 : items.length - 1].focus();
      return;
    }
    const current = trigger.getBoundingClientRect();
    const x = current.left + current.width / 2,
      y = current.top + current.height / 2;
    const horizontal = ["ArrowLeft", "ArrowRight"].includes(event.key);
    const sign = ["ArrowLeft", "ArrowUp"].includes(event.key) ? -1 : 1;
    const candidates = items
      .filter((item) => item !== trigger)
      .map((item) => {
        const rect = item.getBoundingClientRect();
        const dx = rect.left + rect.width / 2 - x,
          dy = rect.top + rect.height / 2 - y;
        return {
          item,
          forward: sign * (horizontal ? dx : dy),
          cross: Math.abs(horizontal ? dy : dx),
        };
      })
      .filter((item) => item.forward > 1)
      .sort((a, b) => a.cross * 4 + a.forward - (b.cross * 4 + b.forward));
    candidates[0]?.item.focus();
  }
  function outside(event) {
    if (viewOptions.open && !viewOptions.contains(event.target))
      closeView(false);
    if (menuId && !cards.get(menuId)?.node.contains(event.target))
      closeMenu(false);
  }
  function focusOutside(event) {
    if (viewOptions.open && !viewOptions.contains(event.target))
      closeView(false);
  }
  function hashChange() {
    route(false);
  }
  surface.addEventListener("click", onClick);
  searchForm.addEventListener("submit", onSearchSubmit);
  surface.addEventListener("input", onInput);
  surface.addEventListener("compositionend", onCompositionEnd);
  surface.addEventListener("change", onChange);
  surface.addEventListener("keydown", onKey);
  document.addEventListener("pointerdown", outside);
  document.addEventListener("focusin", focusOutside);
  window.addEventListener("hashchange", hashChange);
  applyAppearance(appearance);
  route();
  unsubscribe = sdk.subscribe(render);
  const timer = window.setInterval(renderTime, 250);
  function unmount() {
    if (!live) return;
    live = false;
    clearNotice();
    unsubscribe();
    hostAppearance.clear();
    window.clearInterval(timer);
    cards.forEach((_, id) => cancelAnimation(id));
    surface.removeEventListener("click", onClick);
    searchForm.removeEventListener("submit", onSearchSubmit);
    surface.removeEventListener("input", onInput);
    surface.removeEventListener("compositionend", onCompositionEnd);
    surface.removeEventListener("change", onChange);
    surface.removeEventListener("keydown", onKey);
    document.removeEventListener("pointerdown", outside);
    document.removeEventListener("focusin", focusOutside);
    viewOptions.removeEventListener("toggle", viewToggled);
    featureList.removeEventListener("toggle", managementToggled, true);
    window.removeEventListener("hashchange", hashChange);
    signal?.removeEventListener("abort", unmount);
    surface.remove();
    cards.clear();
    groups.clear();
  }
  signal?.addEventListener("abort", unmount, { once: true });
  return {
    update(nextAppearance) {
      if (!live) return;
      applyAppearance(nextAppearance);
      render(snapshot);
    },
    unmount,
  };
}
