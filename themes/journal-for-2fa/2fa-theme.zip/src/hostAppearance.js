// Mirrors tokens.css so host dialogs match the journal without reading computed styles.
// No computed-style reads are needed on OTP publications.
const palettes = {
  light: {
    leaf: "#fdf8ec",
    page: "#f7f0e1",
    ink: "#38271b",
    faded: "#5f4a3a",
    rule: "#b49c7e",
    pine: "#2d5b45",
    pineWash: "#e2ecdf",
    selected: "#f0e2c8",
    alert: "#93203d",
    alertWash: "#f8e1e1",
    ochre: "#85570f",
    ochreWash: "#f6e7bf",
    shadow: "#4a301a2e",
    accents: { postmark: "#a6322b", pine: "#2d5b45", walnut: "#6b4224" },
  },
  dark: {
    leaf: "#3a2e24",
    page: "#2f251d",
    ink: "#f3e8d6",
    faded: "#cdbca6",
    rule: "#8f7a65",
    pine: "#b3c99a",
    pineWash: "#353d2b",
    selected: "#4b3b2e",
    alert: "#f5a8bb",
    alertWash: "#4c2a31",
    ochre: "#ebc57f",
    ochreWash: "#4a3b22",
    shadow: "#0b070466",
    accents: { postmark: "#f29b6a", pine: "#b3c99a", walnut: "#e2bd96" },
  },
};
const systemFonts = [
  "system-ui",
  "-apple-system",
  "PingFang SC",
  "Microsoft YaHei",
  "sans-serif",
];

export function resolveHostAppearance({
  colorScheme = "light",
  stampInk = "postmark",
  handwriting = true,
} = {}) {
  const colors = palettes[colorScheme === "dark" ? "dark" : "light"];
  const accent = colors.accents[stampInk] || colors.accents.postmark;
  return {
    surface: colors.leaf,
    subtle: colors.page,
    hover: colors.selected,
    text: colors.ink,
    muted: colors.faded,
    line: colors.rule,
    stroke: colors.ink,
    accent,
    accentHover: accent,
    accentText: colors.leaf,
    selected: colors.selected,
    danger: colors.alert,
    dangerBackground: colors.alertWash,
    dangerFill: colors.alert,
    dangerFillHover: colors.alert,
    dangerText: colors.leaf,
    warning: colors.ochre,
    warningBackground: colors.ochreWash,
    success: colors.pine,
    successBackground: colors.pineWash,
    radius: 10,
    controlRadius: 3,
    borderWidth: 1,
    shadow: { x: 0, y: 8, blur: 22, spread: 0, color: colors.shadow },
    controlShadow: { x: 0, y: 1, blur: 2, spread: 0, color: colors.shadow },
    fontFamily:
      handwriting === false || handwriting === "false"
        ? [...systemFonts]
        : ["journal-hand", "journal-brush", ...systemFonts],
  };
}

export function createHostAppearanceSync(sdk, surface) {
  let signature = "";
  return {
    update() {
      if (typeof sdk.host?.setAppearance !== "function") return;
      const { colorScheme, stampInk, handwriting } = surface.dataset;
      const nextSignature = JSON.stringify([
        colorScheme,
        stampInk,
        handwriting,
      ]);
      if (nextSignature === signature) return;
      signature = nextSignature;
      sdk.host.setAppearance(
        resolveHostAppearance({ colorScheme, stampInk, handwriting }),
      );
    },
    clear() {
      if (!signature) return;
      signature = "";
      if (typeof sdk.host?.setAppearance === "function")
        sdk.host.setAppearance(null);
    },
  };
}
