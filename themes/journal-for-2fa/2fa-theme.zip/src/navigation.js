const toolChildren = new Set([
  "tool:qr-decode",
  "tool:qr-generate",
  "tool:base32",
  "tool:timestamp",
  "tool:key-check",
  "tool:key-generate",
]);
const syncChildren = new Set([
  "sync-provider:webdav",
  "sync-provider:s3",
  "sync-provider:onedrive",
  "sync-provider:gdrive",
]);
// Adding by hand is rare: it sits with the other ways to bring accounts in.
const dataActions = new Set([
  "account-add",
  "scan-import",
  "import",
  "export",
  "backup",
  "hidden-accounts",
]);
const settingsActions = new Set([
  "settings:security",
  "settings:preferences",
  "settings:sync",
  "settings:custom-code",
  "settings:about",
  "appearance",
]);
// Each chapter lists its known entries first, in this order; an action the
// theme does not know keeps the host order after them, before the closing
// entries (About after the theme settings, signing out last).
const chapterOrder = {
  data: [["scan-import", "account-add", "import", "export", "backup"], []],
  tools: [["tools", ...toolChildren, "quick-otp"], []],
  settings: [
    [
      "settings:security",
      "settings:sync",
      ...syncChildren,
      "settings:preferences",
      "settings:custom-code",
    ],
    ["appearance", "settings:about"],
  ],
  application: [
    ["extension", "pwa-install"],
    ["login", "logout"],
  ],
};

/** Only proven aggregate routes replace their exact known children. */
export function managementActions(descriptors) {
  const global = descriptors.filter((item) => !item.requires);
  const toolsAvailable = global.some(
    (item) => item.actionId === "tools" && item.enabled,
  );
  const syncAvailable = global.some(
    (item) => item.actionId === "settings:sync" && item.enabled,
  );
  const groups = { data: [], tools: [], settings: [], application: [] };
  for (const action of global) {
    const id = action.actionId;
    if (
      (toolsAvailable && toolChildren.has(id)) ||
      (syncAvailable && syncChildren.has(id))
    )
      continue;
    const group = dataActions.has(id)
      ? "data"
      : id === "tools" || id === "quick-otp" || toolChildren.has(id)
        ? "tools"
        : settingsActions.has(id) || syncChildren.has(id)
          ? "settings"
          : "application";
    groups[group].push(action);
  }
  for (const [key, items] of Object.entries(groups)) {
    const [head, tail] = chapterOrder[key];
    const rank = (id) =>
      head.includes(id)
        ? head.indexOf(id)
        : tail.includes(id)
          ? head.length + 1 + tail.indexOf(id)
          : head.length;
    items.sort((a, b) => rank(a.actionId) - rank(b.actionId));
  }
  return groups;
}
